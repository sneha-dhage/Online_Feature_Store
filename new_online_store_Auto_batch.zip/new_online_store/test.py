# Databricks notebook source
# MAGIC %md
# MAGIC ## before event

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.auto_insurance_features_new.auto_features_raw_events_log order by event_id

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.auto_insurance_features_new.auto_features_history;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.auto_insurance_features_new.auto_features_active;

# COMMAND ----------

# MAGIC %md
# MAGIC ## after event

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.auto_insurance_features_new.auto_features_raw_events_log order by received_at desc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.auto_insurance_features_new.auto_features_history

# COMMAND ----------

# MAGIC %sql
# MAGIC select last_login_time, login_count_24h, login_count_7d,  * from main.auto_insurance_features_new.auto_features_active;

# COMMAND ----------

# MAGIC
# MAGIC %sql
# MAGIC select login_count_24h, login_count_7d, * from main.auto_insurance_features_new.auto_features_active_online

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from main.auto_insurance_features_new.auto_policy_login_events

# COMMAND ----------

