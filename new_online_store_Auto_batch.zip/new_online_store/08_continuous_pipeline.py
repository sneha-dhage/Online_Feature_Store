# Databricks notebook source
# MAGIC %md
# MAGIC # 08 — Continuous Streaming Pipeline (Always-On)
# MAGIC
# MAGIC This notebook runs **indefinitely** as a deployed Databricks job.
# MAGIC It watches the landing Volume every 30 seconds, processes any new event files,
# MAGIC and keeps `auto_features_active` (and therefore the Lakebase online store) up to date.
# MAGIC
# MAGIC ## How to deploy (one-time setup)
# MAGIC
# MAGIC **Option A — Databricks UI**
# MAGIC 1. Workflows → Create Job
# MAGIC 2. Task type: Notebook → pick this notebook
# MAGIC 3. Cluster: any cluster with DBR 13+ / Unity Catalog enabled
# MAGIC 4. Schedule: set to **Continuous** (not scheduled)
# MAGIC 5. Click Create → Run Now
# MAGIC
# MAGIC **Option B — Databricks CLI (bundle)**
# MAGIC ```bash
# MAGIC databricks bundle deploy   # from the project root
# MAGIC databricks bundle run auto_insurance_streaming_pipeline
# MAGIC ```
# MAGIC
# MAGIC ## What it does each 30-second micro-batch
# MAGIC ```
# MAGIC New file in /Volumes/.../landing/
# MAGIC   ├─ auto_features_raw_events_log   (bronze — every event, full replay)
# MAGIC   ├─ vehicle_event / driver_event
# MAGIC   │     effective_date = null or past → immediate MERGE → auto_features_active
# MAGIC   │     effective_date = future       → auto_features_pending (applied by Job 03)
# MAGIC   ├─ login_event → auto_policy_login_events + immediate active update
# MAGIC   ├─ unknown event_type → auto_features_dead_letter
# MAGIC   └─ auto_features_history (SCD Type 2 snapshot after every MERGE)
# MAGIC          ↓
# MAGIC   Lakebase online store (CDF sync, automatic, ~5-10s lag)
# MAGIC          ↓
# MAGIC   REST endpoint — 11 features in < 50ms
# MAGIC ```
# MAGIC
# MAGIC ## Stop
# MAGIC Databricks UI → Workflows → Jobs → this job → Actions → Stop
# MAGIC Or cancel the active run.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

dbutils.widgets.text("catalog",          "main")
dbutils.widgets.text("schema",           "auto_insurance_features_new")
dbutils.widgets.text("source_path",      "/Volumes/main/auto_insurance_features_new/landing")
dbutils.widgets.text("checkpoint_path",  "/Volumes/main/auto_insurance_features_new/streaming")
dbutils.widgets.text("sync_pipeline_id", "")   # Catalog → auto_features_active_online → Data Ingest → Pipeline id

CATALOG          = dbutils.widgets.get("catalog")
SCHEMA           = dbutils.widgets.get("schema")
SOURCE_PATH      = dbutils.widgets.get("source_path")
CHECKPOINT_PATH  = dbutils.widgets.get("checkpoint_path")
SYNC_PIPELINE_ID = dbutils.widgets.get("sync_pipeline_id")

ACTIVE         = f"{CATALOG}.{SCHEMA}.auto_features_active"
PENDING        = f"{CATALOG}.{SCHEMA}.auto_features_pending"
HISTORY        = f"{CATALOG}.{SCHEMA}.auto_features_history"
LOGIN_EVENTS   = f"{CATALOG}.{SCHEMA}.auto_policy_login_events"
REGISTRY       = f"{CATALOG}.{SCHEMA}.feature_group_registry"
DEAD_LETTER    = f"{CATALOG}.{SCHEMA}.auto_features_dead_letter"
RAW_EVENTS_LOG = f"{CATALOG}.{SCHEMA}.auto_features_raw_events_log"
ONLINE_TABLE   = f"{CATALOG}.{SCHEMA}.auto_features_active_online"

HOST  = spark.conf.get("spark.databricks.workspaceUrl")
TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

print(f"Catalog        : {CATALOG}.{SCHEMA}")
print(f"Landing volume : {SOURCE_PATH}")
print(f"Checkpoint     : {CHECKPOINT_PATH}")
print(f"Online table   : {ONLINE_TABLE}")
print(f"Detection mode : event-driven (cloudFiles.useNotifications)")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Event schema

# COMMAND ----------

EVENT_SCHEMA = T.StructType([
    T.StructField("event_id",            T.StringType(),    False),
    T.StructField("event_type",          T.StringType(),    False),
    T.StructField("auto_policy_id",      T.StringType(),    False),
    T.StructField("policyholder_id",     T.StringType(),    True),
    T.StructField("effective_date",      T.DateType(),      True),
    T.StructField("no_of_vehicles",      T.IntegerType(),   True),
    T.StructField("newest_vehicle_age",  T.IntegerType(),   True),
    T.StructField("oldest_vehicle_age",  T.IntegerType(),   True),
    T.StructField("avg_vehicle_age",     T.DoubleType(),    True),
    T.StructField("no_of_drivers",       T.IntegerType(),   True),
    T.StructField("avg_driver_age",      T.DoubleType(),    True),
    T.StructField("youngest_driver_age", T.IntegerType(),   True),
    T.StructField("oldest_driver_age",   T.IntegerType(),   True),
    T.StructField("login_timestamp",     T.TimestampType(), True),
    T.StructField("event_source",        T.StringType(),    True),
    T.StructField("event_timestamp",     T.TimestampType(), True),
    T.StructField("event_received_at",   T.TimestampType(), True),
])

# COMMAND ----------
# MAGIC %md
# MAGIC ## Registry loader — reads fresh every micro-batch

# COMMAND ----------

def load_registry():
    rows = spark.table(REGISTRY).collect()
    event_to_groups    = {}
    group_to_columns   = {}
    group_to_mechanism = {}
    for row in rows:
        group     = row["feature_group"]
        mechanism = row["update_mechanism"]
        columns   = row["owned_columns"]
        events    = row["event_types"]
        group_to_columns[group]   = columns
        group_to_mechanism[group] = mechanism
        for event_type in events:
            event_to_groups.setdefault(event_type, []).append(group)
    return event_to_groups, group_to_columns, group_to_mechanism

_evt, _grp, _mech = load_registry()
print("Registry loaded:")
for et, groups in _evt.items():
    print(f"  {et:25s} → {groups}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## History helpers

# COMMAND ----------

def _close_history(policy_ids_view):
    spark.sql(f"""
        MERGE INTO {HISTORY} AS h
        USING {policy_ids_view} AS p
        ON h.auto_policy_id = p.auto_policy_id AND h.is_current = true
        WHEN MATCHED THEN UPDATE SET
            h.is_current = false,
            h.valid_to   = current_timestamp()
    """)

def _snapshot_active_to_history(policy_ids_view, event_id_col, group, reason):
    spark.sql(f"""
        INSERT INTO {HISTORY}
        SELECT
            a.auto_policy_id, a.policyholder_id,
            a.no_of_vehicles, a.newest_vehicle_age, a.oldest_vehicle_age, a.avg_vehicle_age,
            a.no_of_drivers,  a.avg_driver_age, a.youngest_driver_age, a.oldest_driver_age,
            a.login_count_24h, a.login_count_7d, a.last_login_time,
            a.feature_updated_at, a.vehicle_features_updated_at,
            a.driver_features_updated_at, a.login_features_updated_at,
            a.last_source_event_id,
            current_timestamp() AS snapshot_at,
            '{reason}'          AS reason,
            {event_id_col}      AS event_id,
            '{group}'           AS changed_feature_group,
            current_timestamp() AS valid_from,
            NULL                AS valid_to,
            true                AS is_current
        FROM {ACTIVE} a
        INNER JOIN {policy_ids_view} p ON a.auto_policy_id = p.auto_policy_id
    """)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Route helpers

# COMMAND ----------

def append_to_raw_events_log(df, batch_id):
    (
        df.withColumn("raw_payload", F.to_json(F.struct(*df.columns)))
          .withColumn("received_at",
                      F.coalesce(F.col("event_received_at"),
                                 F.col("event_timestamp"),
                                 F.current_timestamp()))
          .withColumn("batch_id", F.lit(batch_id).cast(T.LongType()))
          .select("event_id", "event_type", "auto_policy_id",
                  "raw_payload", "received_at", "batch_id")
          .createOrReplaceTempView("_raw_events_to_write")
    )
    spark.sql(f"""
        INSERT INTO {RAW_EVENTS_LOG}
        SELECT event_id, event_type, auto_policy_id, raw_payload, received_at, batch_id
        FROM _raw_events_to_write
    """)


def append_to_login_events(df):
    df.createOrReplaceTempView("_login_batch_all")
    spark.sql(f"""
        MERGE INTO {LOGIN_EVENTS} AS t
        USING _login_batch_all AS s
        ON t.event_id = s.event_id
        WHEN NOT MATCHED THEN INSERT (
            event_id, auto_policy_id, policyholder_id,
            login_timestamp, event_received_at
        ) VALUES (
            s.event_id, s.auto_policy_id, s.policyholder_id,
            s.login_timestamp,
            COALESCE(s.event_received_at, s.event_timestamp, current_timestamp())
        )
    """)

    batch_counts = spark.sql("""
        SELECT
            auto_policy_id,
            COUNT_IF(login_timestamp > current_timestamp() - INTERVAL 24 HOURS
                     AND login_timestamp <= current_timestamp()) AS new_24h,
            COUNT_IF(login_timestamp > current_timestamp() - INTERVAL 7 DAYS
                     AND login_timestamp <= current_timestamp())  AS new_7d
        FROM _login_batch_all
        WHERE login_timestamp IS NOT NULL
        GROUP BY auto_policy_id
        HAVING new_24h > 0 OR new_7d > 0
    """)
    batch_counts.createOrReplaceTempView("_batch_login_counts")

    if batch_counts.limit(1).count() == 0:
        return

    deduped = (
        df.withColumn("_rn", F.row_number().over(
            Window.partitionBy("auto_policy_id")
                  .orderBy(F.col("login_timestamp").desc_nulls_last())
        ))
        .filter("_rn = 1")
        .drop("_rn")
    )
    deduped.createOrReplaceTempView("_login_latest")
    batch_counts.select("auto_policy_id").createOrReplaceTempView("_login_affected_policies")

    _close_history("_login_affected_policies")

    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING (
            SELECT l.auto_policy_id, l.event_id, l.login_timestamp, c.new_24h, c.new_7d
            FROM _login_latest l
            LEFT JOIN _batch_login_counts c ON l.auto_policy_id = c.auto_policy_id
        ) AS s
        ON t.auto_policy_id = s.auto_policy_id
        WHEN MATCHED THEN UPDATE SET
            t.last_login_time           = CASE
                                              WHEN s.login_timestamp > t.last_login_time
                                                OR t.last_login_time IS NULL
                                              THEN s.login_timestamp
                                              ELSE t.last_login_time
                                          END,
            t.login_count_24h           = COALESCE(t.login_count_24h, 0) + COALESCE(s.new_24h, 0),
            t.login_count_7d            = COALESCE(t.login_count_7d, 0)  + COALESCE(s.new_7d, 0),
            t.login_features_updated_at = current_timestamp(),
            t.feature_updated_at        = current_timestamp(),
            t.last_source_event_id      = s.event_id
    """)

    _snapshot_active_to_history("_login_affected_policies", "a.last_source_event_id",
                                 "login", "immediate:login_event")
    print("  [login] update done.")


def write_to_dead_letter(df, reason, batch_id):
    (
        df.withColumn("raw_payload", F.to_json(F.struct(*df.columns)))
          .withColumn("reason", F.lit(reason))
          .withColumn("received_at",
                      F.coalesce(F.col("event_received_at"),
                                 F.col("event_timestamp"),
                                 F.current_timestamp()))
          .withColumn("batch_id", F.lit(batch_id).cast(T.LongType()))
          .select("event_id", "event_type", "auto_policy_id",
                  "raw_payload", "reason", "received_at", "batch_id")
          .createOrReplaceTempView("_dead_letter_to_write")
    )
    spark.sql(f"""
        INSERT INTO {DEAD_LETTER}
        SELECT event_id, event_type, auto_policy_id, raw_payload, reason, received_at, batch_id
        FROM _dead_letter_to_write
    """)


def insert_to_pending(df, event_to_groups):
    group_label_map = {}
    for event_type, groups in event_to_groups.items():
        business_groups = [g for g in groups if g != "metadata"]
        group_label_map[event_type] = business_groups[0] if len(business_groups) == 1 else "multiple"

    mapping_expr = F.create_map(
        *[item for k, v in group_label_map.items()
          for item in (F.lit(k), F.lit(v))]
    )

    pending_df = df.withColumn(
        "changed_feature_group", mapping_expr[F.col("event_type")]
    ).withColumn(
        "event_received_at",
        F.coalesce(F.col("event_received_at"), F.col("event_timestamp"), F.current_timestamp())
    )

    pending_df.createOrReplaceTempView("_pending_batch")
    spark.sql(f"""
        MERGE INTO {PENDING} AS t
        USING _pending_batch AS s
        ON  t.auto_policy_id  = s.auto_policy_id
        AND t.effective_date  = s.effective_date
        AND t.source_event_id = s.event_id
        WHEN MATCHED THEN UPDATE SET
            t.no_of_vehicles = s.no_of_vehicles, t.newest_vehicle_age = s.newest_vehicle_age,
            t.oldest_vehicle_age = s.oldest_vehicle_age, t.avg_vehicle_age = s.avg_vehicle_age,
            t.no_of_drivers = s.no_of_drivers, t.avg_driver_age = s.avg_driver_age,
            t.youngest_driver_age = s.youngest_driver_age, t.oldest_driver_age = s.oldest_driver_age,
            t.changed_feature_group = s.changed_feature_group, t.event_received_at = s.event_received_at
        WHEN NOT MATCHED THEN INSERT (
            auto_policy_id, policyholder_id,
            no_of_vehicles, newest_vehicle_age, oldest_vehicle_age, avg_vehicle_age,
            no_of_drivers,  avg_driver_age, youngest_driver_age, oldest_driver_age,
            effective_date, changed_feature_group, source_event_id, event_received_at
        ) VALUES (
            s.auto_policy_id, s.policyholder_id,
            s.no_of_vehicles, s.newest_vehicle_age, s.oldest_vehicle_age, s.avg_vehicle_age,
            s.no_of_drivers,  s.avg_driver_age, s.youngest_driver_age, s.oldest_driver_age,
            s.effective_date, s.changed_feature_group, s.event_id, s.event_received_at
        )
    """)


def _dedup_latest_per_policy(df):
    return (
        df.withColumn("_rn", F.row_number().over(
            Window.partitionBy("auto_policy_id")
                  .orderBy(F.coalesce(F.col("event_received_at"), F.col("event_timestamp")).desc())
        ))
        .filter("_rn = 1")
        .drop("_rn")
    )


def _process_group_pass(df, group_name, owned_columns, event_to_groups):
    triggering_event_types = [
        et for et, groups in event_to_groups.items() if group_name in groups
    ]
    group_df = df.filter(F.col("event_type").isin(triggering_event_types))
    if group_df.limit(1).count() == 0:
        return

    deduped  = _dedup_latest_per_policy(group_df)
    view     = f"_batch_{group_name}"
    pol_view = f"_policies_{group_name}"
    deduped.createOrReplaceTempView(view)
    deduped.select("auto_policy_id").distinct().createOrReplaceTempView(pol_view)

    _close_history(pol_view)

    metadata_ts_col = f"{group_name}_features_updated_at"
    set_clauses     = [f"t.{col} = COALESCE(s.{col}, t.{col})" for col in owned_columns]
    set_clauses    += [
        f"t.{metadata_ts_col}   = current_timestamp()",
        "t.feature_updated_at   = current_timestamp()",
        "t.last_source_event_id = s.event_id",
    ]
    set_sql = ",\n            ".join(set_clauses)

    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING {view} AS s
        ON t.auto_policy_id = s.auto_policy_id
        WHEN MATCHED THEN UPDATE SET
            {set_sql}
        WHEN NOT MATCHED THEN INSERT (
            auto_policy_id, policyholder_id,
            no_of_vehicles, newest_vehicle_age, oldest_vehicle_age, avg_vehicle_age,
            no_of_drivers,  avg_driver_age, youngest_driver_age, oldest_driver_age,
            login_count_24h, login_count_7d, last_login_time,
            feature_updated_at, vehicle_features_updated_at,
            driver_features_updated_at, login_features_updated_at,
            last_source_event_id
        ) VALUES (
            s.auto_policy_id, s.policyholder_id,
            s.no_of_vehicles, s.newest_vehicle_age, s.oldest_vehicle_age, s.avg_vehicle_age,
            s.no_of_drivers,  s.avg_driver_age, s.youngest_driver_age, s.oldest_driver_age,
            0, 0, NULL,
            current_timestamp(), current_timestamp(), current_timestamp(), NULL, s.event_id
        )
    """)

    _snapshot_active_to_history(pol_view, "a.last_source_event_id",
                                 group_name, f"immediate:{group_name}_event")
    print(f"  [{group_name}] pass done.")


def archive_and_merge_immediate(df, event_to_groups, group_to_columns, group_to_mechanism):
    streaming_groups = [
        g for g, mech in group_to_mechanism.items()
        if mech == "streaming_immediate_or_pending"
    ]
    for group in streaming_groups:
        _process_group_pass(df, group, group_to_columns[group], event_to_groups)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Online table sync trigger
# MAGIC
# MAGIC After each MERGE into `auto_features_active`, kick off the Lakebase CDF sync pipeline
# MAGIC so `auto_features_active_online` is updated in the same job run.
# MAGIC No second job needed.

# COMMAND ----------

import requests as _http

def trigger_online_sync():
    """
    Wakes up the Lakebase DLT sync pipeline so CDF changes from auto_features_active
    are pushed to auto_features_active_online right after the MERGE.

    Pipeline ID comes from:
      Catalog → auto_features_active_online → Data Ingest → Pipeline id
    Set it in the sync_pipeline_id widget when deploying this notebook as a job.
    """
    if not SYNC_PIPELINE_ID:
        print("  [online sync] sync_pipeline_id not set — skipping (set widget to enable)")
        return

    _headers = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
    resp = _http.post(
        f"https://{HOST}/api/2.0/pipelines/{SYNC_PIPELINE_ID}/updates",
        headers=_headers,
        json={"cause": "USER_ACTION", "full_refresh": False},
        timeout=15
    )
    if resp.status_code in (200, 202):
        print(f"  [online sync] sync triggered (pipeline={SYNC_PIPELINE_ID[:8]}...)")
    else:
        print(f"  [online sync] {resp.status_code}: {resp.text[:150]}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Micro-batch processor

# COMMAND ----------

def process_micro_batch(df, batch_id):
    import traceback
    try:
        count = df.count()
        if count == 0:
            return
        print(f"\n[batch {batch_id}] {count} event(s)")

        append_to_raw_events_log(df, batch_id)

        event_to_groups, group_to_columns, group_to_mechanism = load_registry()
        today = spark.sql("SELECT current_date()").first()[0]

        batch_event_types  = [r["event_type"] for r in df.select("event_type").distinct().collect()]
        hourly_batch_events   = [et for et in batch_event_types
                                 if any(group_to_mechanism.get(g) == "hourly_batch"
                                        for g in event_to_groups.get(et, []))]
        streaming_event_types = [et for et in batch_event_types
                                 if any(group_to_mechanism.get(g) == "streaming_immediate_or_pending"
                                        for g in event_to_groups.get(et, []))]
        unknown_event_types   = [et for et in batch_event_types if et not in event_to_groups]

        print(f"  event types   : {batch_event_types}")
        if unknown_event_types:
            print(f"  dead-letter   : {unknown_event_types}")

        login_df     = df.filter(F.col("event_type").isin(hourly_batch_events)) \
                       if hourly_batch_events else df.filter(F.lit(False))
        streaming_df = df.filter(F.col("event_type").isin(streaming_event_types)) \
                       if streaming_event_types else df.filter(F.lit(False))
        unknown_df   = df.filter(F.col("event_type").isin(unknown_event_types)) \
                       if unknown_event_types else df.filter(F.lit(False))

        future_df    = streaming_df.filter(
            F.col("effective_date").isNotNull() & (F.col("effective_date") > F.lit(today))
        )
        immediate_df = streaming_df.filter(
            F.col("effective_date").isNull() | (F.col("effective_date") <= F.lit(today))
        )

        if unknown_df.limit(1).count() > 0:
            write_to_dead_letter(unknown_df, "unknown_event_type", batch_id)
        if login_df.limit(1).count() > 0:
            append_to_login_events(login_df)
        if future_df.limit(1).count() > 0:
            insert_to_pending(future_df, event_to_groups)
            print(f"  [pending] {future_df.count()} future-dated event(s) queued.")
        if immediate_df.limit(1).count() > 0:
            archive_and_merge_immediate(immediate_df, event_to_groups,
                                        group_to_columns, group_to_mechanism)

        trigger_online_sync()
        print(f"[batch {batch_id}] done.")

    except Exception as e:
        print(f"\n[ERROR] batch_id={batch_id}: {e}")
        traceback.print_exc()
        raise

# COMMAND ----------
# MAGIC %md
# MAGIC ## Start pipeline (availableNow — Serverless compatible)
# MAGIC
# MAGIC Processes all new files in the landing volume since the last checkpoint, then exits.
# MAGIC Designed to run on Databricks Serverless compute via a scheduled job (every 1 minute).
# MAGIC Each run picks up exactly the files that arrived since the previous run — no duplicates
# MAGIC thanks to the checkpoint. New events from `run_e2e.py` are picked up within ~60s.

# COMMAND ----------

print(f"Starting pipeline (availableNow trigger — Serverless compatible) ...")
print(f"Watching  : {SOURCE_PATH}")
print(f"Checkpoint: {CHECKPOINT_PATH}")
print("Processing all new files since last checkpoint, then exiting.\n")

query = (
    spark.readStream
         .format("cloudFiles")
         .option("cloudFiles.format",           "json")
         .option("cloudFiles.inferColumnTypes", "false")
         .schema(EVENT_SCHEMA)
         .load(SOURCE_PATH)
         .writeStream
         .foreachBatch(process_micro_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)   # process all pending files then exit (Serverless-safe)
         .start()
)

query.awaitTermination()
