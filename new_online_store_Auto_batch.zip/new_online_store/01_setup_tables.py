# Databricks notebook source
# MAGIC %md
# MAGIC # 01 — Setup Tables
# MAGIC
# MAGIC Creates all 7 Delta tables for the auto-insurance online feature store and seeds
# MAGIC initial active records. Run once with `reset = false`. Set `reset = true` to
# MAGIC drop and recreate everything (useful during development).
# MAGIC
# MAGIC | Table | Role |
# MAGIC |---|---|
# MAGIC | `auto_features_active` | Live feature store — one row per policy |
# MAGIC | `auto_features_pending` | Future-dated events waiting for effective_date |
# MAGIC | `auto_features_history` | Full-row snapshots (SCD Type 2) before every update |
# MAGIC | `auto_policy_login_events` | Append-only raw login log |
# MAGIC | `auto_features_dead_letter` | Unrecognized event_types — visibility instead of silent drop |
# MAGIC | `auto_features_raw_events_log` | Bronze: every raw event appended before any processing |
# MAGIC | `feature_group_registry` | Metadata: columns per feature group |

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VOLUME IF NOT EXISTS main.auto_insurance_features_new.landing;
# MAGIC CREATE VOLUME IF NOT EXISTS main.auto_insurance_features_new.streaming;
# MAGIC

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema", "auto_insurance_features_new")
dbutils.widgets.dropdown("reset", "false", ["false", "true"])

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")
RESET   = dbutils.widgets.get("reset") == "true"

ACTIVE          = f"{CATALOG}.{SCHEMA}.auto_features_active"
PENDING         = f"{CATALOG}.{SCHEMA}.auto_features_pending"
HISTORY         = f"{CATALOG}.{SCHEMA}.auto_features_history"
LOGIN_EVENTS    = f"{CATALOG}.{SCHEMA}.auto_policy_login_events"
REGISTRY        = f"{CATALOG}.{SCHEMA}.feature_group_registry"
DEAD_LETTER     = f"{CATALOG}.{SCHEMA}.auto_features_dead_letter"
RAW_EVENTS_LOG  = f"{CATALOG}.{SCHEMA}.auto_features_raw_events_log"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Use existing catalog and schema

# COMMAND ----------

# Catalog and schema already exist — just set the context
spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Using catalog: {CATALOG}, schema: {SCHEMA}")

if RESET:
    for tbl in [ACTIVE, PENDING, HISTORY, LOGIN_EVENTS, REGISTRY, DEAD_LETTER, RAW_EVENTS_LOG]:
        spark.sql(f"DROP TABLE IF EXISTS {tbl}")
    print("All tables dropped — will recreate.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. auto_features_active
# MAGIC One row per policy. CDF enabled so Databricks Online Table can sync continuously.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {ACTIVE} (
    auto_policy_id              STRING    NOT NULL,
    policyholder_id             STRING,
    -- vehicle features
    no_of_vehicles              INT,
    newest_vehicle_age          INT,
    oldest_vehicle_age          INT,
    avg_vehicle_age             DOUBLE,
    -- driver features
    no_of_drivers               INT,
    avg_driver_age              DOUBLE,
    youngest_driver_age         INT,
    oldest_driver_age           INT,
    -- login features
    login_count_24h             BIGINT,
    login_count_7d              BIGINT,
    last_login_time             TIMESTAMP,
    -- metadata
    feature_updated_at          TIMESTAMP,
    vehicle_features_updated_at TIMESTAMP,
    driver_features_updated_at  TIMESTAMP,
    login_features_updated_at   TIMESTAMP,
    last_source_event_id        STRING,
    CONSTRAINT auto_features_active_pk PRIMARY KEY (auto_policy_id)
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. auto_features_pending
# MAGIC Future-dated vehicle / driver events. `changed_feature_group` = "vehicle" or "driver".

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {PENDING} (
    auto_policy_id        STRING  NOT NULL,
    policyholder_id       STRING,
    -- vehicle future values (NULL when group is driver-only)
    no_of_vehicles        INT,
    newest_vehicle_age    INT,
    oldest_vehicle_age    INT,
    avg_vehicle_age       DOUBLE,
    -- driver future values (NULL when group is vehicle-only)
    no_of_drivers         INT,
    avg_driver_age        DOUBLE,
    youngest_driver_age   INT,
    oldest_driver_age     INT,
    -- scheduling
    effective_date        DATE    NOT NULL,
    changed_feature_group STRING,
    source_event_id       STRING,
    event_received_at     TIMESTAMP
)
USING DELTA
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. auto_features_history
# MAGIC Full-row snapshot archived BEFORE every partial MERGE (SCD Type 2).
# MAGIC - `is_current = true` → version currently in the active table
# MAGIC - `is_current = false` → superseded / historical version

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {HISTORY} (
    auto_policy_id              STRING    NOT NULL,
    policyholder_id             STRING,
    -- vehicle features
    no_of_vehicles              INT,
    newest_vehicle_age          INT,
    oldest_vehicle_age          INT,
    avg_vehicle_age             DOUBLE,
    -- driver features
    no_of_drivers               INT,
    avg_driver_age              DOUBLE,
    youngest_driver_age         INT,
    oldest_driver_age           INT,
    -- login features
    login_count_24h             BIGINT,
    login_count_7d              BIGINT,
    last_login_time             TIMESTAMP,
    -- metadata
    feature_updated_at          TIMESTAMP,
    vehicle_features_updated_at TIMESTAMP,
    driver_features_updated_at  TIMESTAMP,
    login_features_updated_at   TIMESTAMP,
    last_source_event_id        STRING,
    -- history metadata
    snapshot_at                 TIMESTAMP NOT NULL,
    reason                      STRING,
    event_id                    STRING,
    changed_feature_group       STRING,
    valid_from                  TIMESTAMP NOT NULL,
    valid_to                    TIMESTAMP,
    is_current                  BOOLEAN   NOT NULL
)
USING DELTA
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. auto_policy_login_events
# MAGIC Append-only raw login log. Hourly Job 2 reads this to recompute login features.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {LOGIN_EVENTS} (
    event_id          STRING    NOT NULL,
    auto_policy_id    STRING    NOT NULL,
    policyholder_id   STRING,
    login_timestamp   TIMESTAMP NOT NULL,
    event_received_at TIMESTAMP NOT NULL
)
USING DELTA
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. auto_features_dead_letter
# MAGIC Captures events whose `event_type` is not recognized by `feature_group_registry`.
# MAGIC Prevents silent data loss — unrecognized events are visible here for debugging/replay
# MAGIC instead of being dropped invisibly by the streaming pipeline.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DEAD_LETTER} (
    event_id        STRING,
    event_type      STRING,
    auto_policy_id  STRING,
    raw_payload     STRING,
    reason          STRING,
    received_at     TIMESTAMP,
    batch_id        BIGINT
)
USING DELTA
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. auto_features_raw_events_log
# MAGIC Bronze-layer append-only log. Every event from every batch is written here BEFORE
# MAGIC any routing or processing. Enables full replay and debugging — the raw payload is
# MAGIC stored as JSON so nothing is lost even if the schema evolves.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {RAW_EVENTS_LOG} (
    event_id        STRING,
    event_type      STRING,
    auto_policy_id  STRING,
    raw_payload     STRING,
    received_at     TIMESTAMP NOT NULL,
    batch_id        BIGINT    NOT NULL
)
USING DELTA
""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. feature_group_registry
# MAGIC Read at runtime by the streaming pipeline and jobs. Add a row here to extend the system.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {REGISTRY} (
    feature_group    STRING        NOT NULL,
    owned_columns    ARRAY<STRING> NOT NULL,
    event_types      ARRAY<STRING> NOT NULL,
    update_mechanism STRING        NOT NULL,
    description      STRING,
    CONSTRAINT feature_group_registry_pk PRIMARY KEY (feature_group)
)
USING DELTA
""")

if spark.table(REGISTRY).limit(1).count() == 0:
    spark.sql(f"""
    INSERT INTO {REGISTRY} VALUES
    (
        'vehicle',
        ARRAY('no_of_vehicles','newest_vehicle_age','oldest_vehicle_age','avg_vehicle_age'),
        ARRAY('vehicle_event'),
        'streaming_immediate_or_pending',
        'Vehicle-level aggregated features per policy'
    ),
    (
        'driver',
        ARRAY('no_of_drivers','avg_driver_age','youngest_driver_age','oldest_driver_age'),
        ARRAY('driver_event'),
        'streaming_immediate_or_pending',
        'Driver-level aggregated features per policy'
    ),
    (
        'login',
        ARRAY('login_count_24h','login_count_7d','last_login_time'),
        ARRAY('login_event'),
        'hourly_batch',
        'Time-windowed login features recomputed hourly from raw events'
    ),
    (
        'metadata',
        ARRAY('feature_updated_at','vehicle_features_updated_at','driver_features_updated_at','login_features_updated_at','last_source_event_id'),
        ARRAY('vehicle_event','driver_event','login_event'),
        'updated_with_respective_group',
        'Timestamps and event IDs tracking when each feature group was last updated'
    )
    """)
    print("Registry seeded with 4 feature groups.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Seed initial active records (3 sample policies)

# COMMAND ----------

if spark.table(ACTIVE).limit(1).count() == 0:
    spark.sql(f"""
    INSERT INTO {ACTIVE} VALUES
    ('POL001', 'CUS001',
     2, 1, 8, 4.5,
     2, 35.0, 28, 42,
     0, 0, NULL,
     current_timestamp(), current_timestamp(), current_timestamp(), NULL, 'seed_load'),
    ('POL002', 'CUS002',
     1, 3, 3, 3.0,
     1, 45.0, 45, 45,
     0, 0, NULL,
     current_timestamp(), current_timestamp(), current_timestamp(), NULL, 'seed_load'),
    ('POL003', 'CUS003',
     3, 0, 12, 5.3,
     3, 38.0, 25, 52,
     0, 0, NULL,
     current_timestamp(), current_timestamp(), current_timestamp(), NULL, 'seed_load')
    """)

    # Mirror initial active state into history as is_current = true
    spark.sql(f"""
    INSERT INTO {HISTORY}
    SELECT
        auto_policy_id, policyholder_id,
        no_of_vehicles, newest_vehicle_age, oldest_vehicle_age, avg_vehicle_age,
        no_of_drivers, avg_driver_age, youngest_driver_age, oldest_driver_age,
        login_count_24h, login_count_7d, last_login_time,
        feature_updated_at, vehicle_features_updated_at, driver_features_updated_at,
        login_features_updated_at, last_source_event_id,
        current_timestamp() AS snapshot_at,
        'initial_load'      AS reason,
        NULL                AS event_id,
        NULL                AS changed_feature_group,
        feature_updated_at  AS valid_from,
        NULL                AS valid_to,
        true                AS is_current
    FROM {ACTIVE}
    """)
    print("Seeded 3 policies into active and history.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== auto_features_active ===")
display(spark.table(ACTIVE))

print("=== auto_features_history ===")
display(spark.table(HISTORY))

print("=== feature_group_registry ===")
display(spark.table(REGISTRY))

print("=== auto_features_dead_letter ===")
display(spark.table(DEAD_LETTER))

print("=== auto_features_raw_events_log ===")
display(spark.table(RAW_EVENTS_LOG))

# COMMAND ----------

