# Databricks notebook source
# MAGIC %md
# MAGIC # 05 — Job: Hourly Pending Promotion
# MAGIC
# MAGIC Runs every hour via Databricks Workflows.
# MAGIC Finds pending rows whose EFFECTIVE_DATE has arrived and promotes
# MAGIC them to AUTO_FEATURES_ACTIVE.
# MAGIC
# MAGIC Hourly (not midnight) so effective timestamps like
# MAGIC `2026-06-29 09:30:00` are promoted within the hour — not next day.
# MAGIC
# MAGIC ## Steps per due policy
# MAGIC 1. Find pending rows where EFFECTIVE_DATE <= current_timestamp()
# MAGIC 2. Deduplicate — keep latest per policy if multiple pending rows due
# MAGIC 3. Close existing IS_CURRENT = true history row
# MAGIC    (VALID_TRANSACTION_TO = EFFECTIVE_DATE - 1 millisecond)
# MAGIC 4. MERGE vehicle features into AUTO_FEATURES_ACTIVE
# MAGIC    (COALESCE preserves transaction features already in ACTIVE)
# MAGIC 5. Snapshot updated ACTIVE → AUTO_FEATURES_HISTORY (IS_CURRENT = true)
# MAGIC 6. DELETE promoted rows from AUTO_FEATURES_PENDING
# MAGIC
# MAGIC Leave `run_date` blank in production (uses current_timestamp).
# MAGIC Set e.g. `2026-06-29 00:00:00` to simulate a future date in testing.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from datetime import datetime

dbutils.widgets.text("catalog",  "main")
dbutils.widgets.text("schema",   "model")
dbutils.widgets.text("run_date", "")  # format: YYYY-MM-DD HH:MM:SS

CATALOG     = dbutils.widgets.get("catalog")
SCHEMA      = dbutils.widgets.get("schema")
_date_input = dbutils.widgets.get("run_date").strip()

if _date_input:
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m-%d-%Y", "%m/%d/%Y"):
        try:
            run_ts = datetime.strptime(_date_input, fmt).strftime("%Y-%m-%d %H:%M:%S")
            break
        except ValueError:
            continue
    else:
        raise ValueError(f"Cannot parse run_date '{_date_input}'. Use YYYY-MM-DD HH:MM:SS.")
else:
    run_ts = str(spark.sql("SELECT current_timestamp()").first()[0])

print(f"Run timestamp: {run_ts}")

ACTIVE   = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
PENDING  = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_PENDING"
HISTORY  = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Apply Due Pending Changes

# COMMAND ----------

def apply_due_pending():
    due_df = spark.sql(f"""
        SELECT * FROM {PENDING}
        WHERE EFFECTIVE_DATE <= TIMESTAMP '{run_ts}'
    """)

    if due_df.limit(1).count() == 0:
        print(f"No pending changes due on or before {run_ts}. Nothing to do.")
        return

    # Deduplicate — if same policy has multiple due rows, keep latest
    deduped = (
        due_df
        .withColumn("_rn", F.row_number().over(
            Window.partitionBy("AUTO_POLICY_ID")
                  .orderBy(F.col("EFFECTIVE_DATE").desc(),
                           F.col("EVENT_RECEIVED_AT").desc())
        ))
        .filter("_rn = 1")
        .drop("_rn")
    )

    count = deduped.count()
    print(f"Promoting {count} pending row(s) with EFFECTIVE_DATE <= {run_ts}")

    deduped.createOrReplaceTempView("_due_pending")
    deduped.select("AUTO_POLICY_ID").distinct() \
           .createOrReplaceTempView("_due_policies")

    # Step 1 — Close existing IS_CURRENT = true history rows
    # VALID_TRANSACTION_TO = EFFECTIVE_DATE - 1 millisecond (no overlap)
    spark.sql(f"""
        MERGE INTO {HISTORY} AS h
        USING (
            SELECT
                p.AUTO_POLICY_ID,
                d.EFFECTIVE_DATE - INTERVAL 1 MILLISECOND AS CLOSE_TS
            FROM _due_policies p
            JOIN _due_pending d ON d.AUTO_POLICY_ID = p.AUTO_POLICY_ID
        ) AS s
        ON h.AUTO_POLICY_ID = s.AUTO_POLICY_ID AND h.IS_CURRENT = true
        WHEN MATCHED THEN UPDATE SET
            h.IS_CURRENT           = false,
            h.VALID_TRANSACTION_TO = s.CLOSE_TS
    """)
    print("  Step 1: Closed IS_CURRENT history rows.")

    # Step 2 — MERGE vehicle features into ACTIVE
    # COALESCE preserves NO_OF_TRANSACTIONS already in ACTIVE
    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING _due_pending AS s
        ON t.AUTO_POLICY_ID = s.AUTO_POLICY_ID
        WHEN MATCHED THEN UPDATE SET
            t.NO_OF_VEHICLES              = COALESCE(s.NO_OF_VEHICLES, t.NO_OF_VEHICLES),
            t.VEHICLE_FEATURES_UPDATED_AT = current_timestamp(),
            t.FEATURE_UPDATED_AT          = current_timestamp(),
            t.LAST_SOURCE_EVENT_ID        = s.SOURCE_EVENT_ID
        WHEN NOT MATCHED THEN INSERT (
            AUTO_POLICY_ID, HISTORY_ID,
            NO_OF_TRANSACTIONS, TXN_FEATURES_UPDATED_AT,
            NO_OF_VEHICLES, VEHICLE_FEATURES_UPDATED_AT,
            FEATURE_UPDATED_AT, LAST_SOURCE_EVENT_ID
        ) VALUES (
            s.AUTO_POLICY_ID, s.HISTORY_ID,
            NULL, NULL,
            s.NO_OF_VEHICLES, current_timestamp(),
            current_timestamp(), s.SOURCE_EVENT_ID
        )
    """)
    print("  Step 2: Merged vehicle features into AUTO_FEATURES_ACTIVE.")

    # Step 3 — Snapshot updated ACTIVE → HISTORY as IS_CURRENT = true
    spark.sql(f"""
        INSERT INTO {HISTORY}
        SELECT
            a.AUTO_POLICY_ID,
            a.HISTORY_ID,
            a.NO_OF_TRANSACTIONS,
            a.TXN_FEATURES_UPDATED_AT,
            a.NO_OF_VEHICLES,
            a.VEHICLE_FEATURES_UPDATED_AT,
            a.FEATURE_UPDATED_AT,
            a.LAST_SOURCE_EVENT_ID,
            current_timestamp()                             AS SNAPSHOT_AT,
            CONCAT('pending_promoted:', p.SOURCE_EVENT_ID) AS REASON,
            p.SOURCE_EVENT_ID                              AS EVENT_ID,
            p.CHANGED_FEATURE_GROUP                        AS CHANGED_FEATURE_GROUP,
            p.EFFECTIVE_DATE                               AS VALID_TRANSACTION_FROM,
            NULL                                           AS VALID_TRANSACTION_TO,
            true                                           AS IS_CURRENT
        FROM {ACTIVE} a
        JOIN _due_pending p ON a.AUTO_POLICY_ID = p.AUTO_POLICY_ID
    """)
    print("  Step 3: Snapshotted to AUTO_FEATURES_HISTORY (IS_CURRENT=true).")

    # Step 4 — Delete promoted rows from PENDING
    spark.sql(f"""
        DELETE FROM {PENDING}
        WHERE EFFECTIVE_DATE <= TIMESTAMP '{run_ts}'
    """)
    print(f"  Step 4: Deleted {count} promoted row(s) from AUTO_FEATURES_PENDING.")
    print(f"\nDone. {count} pending row(s) promoted.")


apply_due_pending()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== AUTO_FEATURES_ACTIVE ===")
display(spark.table(ACTIVE).orderBy("AUTO_POLICY_ID"))

print("=== AUTO_FEATURES_PENDING (remaining) ===")
display(spark.table(PENDING).orderBy("EFFECTIVE_DATE"))

print("=== AUTO_FEATURES_HISTORY (all snapshots) ===")
display(spark.table(HISTORY).orderBy("AUTO_POLICY_ID", "VALID_TRANSACTION_FROM"))
