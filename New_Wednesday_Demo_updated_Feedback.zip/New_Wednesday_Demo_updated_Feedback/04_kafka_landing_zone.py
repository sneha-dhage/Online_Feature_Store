# Databricks notebook source
# MAGIC %md
# MAGIC # 04 — Kafka Landing Zone (Auto Loader)
# MAGIC
# MAGIC Reads XML files from the Volume (Kafka landing zone) and lands them into `RAW_POLICY_EVENTS`.
# MAGIC
# MAGIC ## What happens per XML file
# MAGIC ```
# MAGIC 03_test_event drops XML → /Volumes/.../incoming_xml/
# MAGIC       ↓
# MAGIC Auto Loader detects new file (one file = one Kafka message)
# MAGIC       ↓
# MAGIC Extract: HISTORY_ID, POLICY_NUMBER, POLICY_EFFECTIVE_DATE from XML header
# MAGIC       ↓
# MAGIC INSERT → RAW_POLICY_EVENTS (Bronze — full XML stored as RAW_PAYLOAD)
# MAGIC       ↓
# MAGIC CDF on RAW_POLICY_EVENTS triggers 05_sp_compute_features
# MAGIC ```
# MAGIC
# MAGIC ## XML Structure expected
# MAGIC ```xml
# MAGIC <PolicyChangeEvent>
# MAGIC     <HISTORY_ID>HIS-001</HISTORY_ID>
# MAGIC     <PolicyNumber>POL-1234</PolicyNumber>
# MAGIC     <PolicyEffectiveDate>2026-07-07T00:00:00</PolicyEffectiveDate>
# MAGIC     <Transactions>
# MAGIC         <Transaction id="001">
# MAGIC             <TransactionSequence>1</TransactionSequence>
# MAGIC             <IsDeleted>0</IsDeleted>
# MAGIC             <Vehicles>...</Vehicles>
# MAGIC         </Transaction>
# MAGIC     </Transactions>
# MAGIC </PolicyChangeEvent>
# MAGIC ```

# COMMAND ----------

import xml.etree.ElementTree as ET

dbutils.widgets.text("catalog",         "project")
dbutils.widgets.text("schema",          "kafka_feedback")
dbutils.widgets.text("checkpoint_path", "/Volumes/project/kafka_feedback/checkpoints/kafka_landing")

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")

KAFKA_LANDING = f"/Volumes/{CATALOG}/{SCHEMA}/incoming_xml"
RAW_EVENTS    = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
DLQ           = f"{CATALOG}.{SCHEMA}.RAW_EVENTS_DLQ"

print(f"Watching : {KAFKA_LANDING}")
print(f"Landing  : {RAW_EVENTS}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Process Each XML File

# COMMAND ----------

def _clean_ts(ts):
    return ts.strip().replace("T", " ").split(".")[0]


def process_kafka_batch(df, batch_id):
    files = df.collect()
    print(f"\n[batch {batch_id}] {len(files)} XML file(s)")

    for row in files:
        source_file = row["path"]
        try:
            raw_payload = row["content"].decode("utf-8")
            root        = ET.fromstring(raw_payload)

            history_id            = root.findtext("HISTORY_ID", "").strip()
            policy_number         = root.findtext("PolicyNumber", "").strip()
            policy_effective_date = root.findtext("PolicyEffectiveDate", "").strip()

            missing = [f for f, v in {
                "HISTORY_ID":          history_id,
                "PolicyNumber":        policy_number,
                "PolicyEffectiveDate": policy_effective_date,
            }.items() if not v]

            if missing:
                raise ValueError(f"Missing XML header fields: {missing}")

            txns = root.findall("Transactions/Transaction")
            if not txns:
                raise ValueError("No <Transaction> nodes found inside <Transactions>")

            active_txns = [t for t in txns if t.findtext("IsDeleted", "0").strip() == "0"]
            if not active_txns:
                raise ValueError("All transactions are deleted — nothing to process")

            latest_txn = max(active_txns, key=lambda t: int(t.findtext("TransactionSequence", "0")))
            latest_seq = latest_txn.findtext("TransactionSequence")

            # Idempotency — skip if same HISTORY_ID + same transaction count already landed
            existing = spark.sql(f"""
                SELECT COUNT(*) AS cnt FROM {RAW_EVENTS}
                WHERE HISTORY_ID         = '{history_id}'
                  AND TOTAL_TRANSACTIONS = {len(txns)}
            """).first()["cnt"]

            if existing > 0:
                print(f"  [{history_id}] same version already in RAW_POLICY_EVENTS — skipping")
                continue

            escaped_xml = raw_payload.replace("'", "''")

            spark.sql(f"""
                INSERT INTO {RAW_EVENTS}
                (HISTORY_ID, POLICY_NUMBER, POLICY_EFFECTIVE_DATE,
                 TOTAL_TRANSACTIONS, LATEST_TXN_SEQUENCE,
                 RAW_PAYLOAD, INGESTED_AT)
                VALUES (
                    '{history_id}',
                    '{policy_number}',
                    TIMESTAMP '{_clean_ts(policy_effective_date)}',
                    {len(txns)},
                    {latest_seq},
                    '{escaped_xml}',
                    current_timestamp()
                )
            """)

            print(f"  [{history_id}] landed | transactions={len(txns)} | active={len(active_txns)} | latest_seq={latest_seq}")

        except Exception as e:
            spark.sql(f"""
                INSERT INTO {DLQ}
                (RAW_PAYLOAD, ERROR_MESSAGE, FAILED_AT, KAFKA_TOPIC)
                VALUES (
                    '{source_file.replace("'","''")}',
                    '{str(e).replace("'","''")}',
                    current_timestamp(),
                    'pc.policy.change.events'
                )
            """)
            print(f"  [DLQ] {source_file} — {e}")

    print(f"\n[batch {batch_id}] done.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Start Auto Loader

# COMMAND ----------

query = (
    spark.readStream
         .format("cloudFiles")
         .option("cloudFiles.format",        "binaryFile")
         .option("pathGlobFilter",            "*.xml")
         .option("cloudFiles.schemaLocation", CHECKPOINT_PATH + "/schema")
         .load(KAFKA_LANDING)
         .writeStream
         .foreachBatch(process_kafka_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nKafka landing — batch complete.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== RAW_POLICY_EVENTS ===")
display(spark.table(RAW_EVENTS).orderBy("INGESTED_AT"))

print("=== DLQ ===")
display(spark.sql(f"SELECT * FROM {DLQ} ORDER BY FAILED_AT DESC"))

print("\n>>> Next: Run 05_sp_compute_features <<<")
