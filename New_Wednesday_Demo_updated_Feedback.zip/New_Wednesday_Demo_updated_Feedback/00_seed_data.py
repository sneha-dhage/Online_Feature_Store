# Databricks notebook source
# MAGIC %md
# MAGIC # 00 — Seed Data
# MAGIC
# MAGIC Inserts the initial **new business** event (HIST-001) for POL-1234
# MAGIC across all layers so the demo has a valid starting state.
# MAGIC
# MAGIC Run this **once** after 01_setup_tables and **before** 02a_test_event.
# MAGIC
# MAGIC | Layer | Table | Seed value |
# MAGIC |---|---|---|
# MAGIC | Source | POLICY_TXN_HISTORY | HIST-001, new business, IS_DELETED=false |
# MAGIC | Feature Store | AUTO_FEATURES_ACTIVE | POL-1234 — (NO_OF_TRANSACTIONS=1, NO_OF_VEHICLES=2) |
# MAGIC | Feature Store | AUTO_FEATURES_HISTORY | POL-1234 — (1, 2) IS_CURRENT=true |
# MAGIC
# MAGIC `RAW_POLICY_EVENTS` is NOT seeded — XML arrives via `02a_test_event` → `01b_kafka_landing_zone` (Auto Loader).
# MAGIC `COMPUTED_FEATURE_EVENTS` is NOT seeded — only receives rows written by SP (03).
# MAGIC
# MAGIC ## Why both effective dates are the same for new business
# MAGIC New business goes into effect immediately — TRANSACTION_DATE = POLICY_EFFECTIVE_DATE = 2026-06-21.
# MAGIC So TXN_FEATURES and VEHICLE_FEATURES both route to ACTIVE (not PENDING).

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "model")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

TXN_HISTORY = f"{CATALOG}.{SCHEMA}.POLICY_TXN_HISTORY"
ACTIVE      = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
HISTORY     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Source: POLICY_TXN_HISTORY
# MAGIC
# MAGIC HIST-001: new business — IS_DELETED=false, both dates = 2026-06-21 (immediate)

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {TXN_HISTORY} WHERE HISTORY_ID = 'HIST-001'").first()["cnt"] == 0:
    spark.sql(f"""
        INSERT INTO {TXN_HISTORY}
        (HISTORY_ID, POLICY_NUMBER, TRANSACTION_TYPE,
         TRANSACTION_DATE, POLICY_EFFECTIVE_DATE, TXN_EFFECTIVE_DATE,
         IS_DELETED, CREATED_AT)
        VALUES (
            'HIST-001', 'POL-1234', 'new business',
            TIMESTAMP '2026-06-21 00:00:00',
            TIMESTAMP '2026-06-21 00:00:00',
            TIMESTAMP '2026-06-21 00:00:00',
            false,
            TIMESTAMP '2026-06-21 00:00:00'
        )
    """)
    print("Seeded POLICY_TXN_HISTORY: HIST-001 — new business, IS_DELETED=false")
else:
    print("POLICY_TXN_HISTORY already has HIST-001 — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Feature Store: AUTO_FEATURES_ACTIVE

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {ACTIVE} WHERE AUTO_POLICY_ID = 'POL-1234'").first()["cnt"] == 0:

    spark.sql(f"""
        INSERT INTO {ACTIVE}
        (AUTO_POLICY_ID, HISTORY_ID,
         NO_OF_TRANSACTIONS, TXN_FEATURES_UPDATED_AT,
         NO_OF_VEHICLES, VEHICLE_FEATURES_UPDATED_AT,
         FEATURE_UPDATED_AT, LAST_SOURCE_EVENT_ID)
        VALUES (
            'POL-1234', 'HIST-001',
            1, TIMESTAMP '2026-06-21 00:00:00',
            2, TIMESTAMP '2026-06-21 00:00:00',
            TIMESTAMP '2026-06-21 00:00:00', 'HIST-001'
        )
    """)
    print("Seeded AUTO_FEATURES_ACTIVE: POL-1234 — (NO_OF_TRANSACTIONS=1, NO_OF_VEHICLES=2)")

else:
    print("AUTO_FEATURES_ACTIVE already has POL-1234 — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 3 — Feature Store: AUTO_FEATURES_HISTORY
# MAGIC
# MAGIC Initial snapshot — IS_CURRENT=true, VALID_TRANSACTION_FROM=2026-06-21, VALID_TRANSACTION_TO=NULL

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {HISTORY} WHERE AUTO_POLICY_ID = 'POL-1234'").first()["cnt"] == 0:

    spark.sql(f"""
        INSERT INTO {HISTORY}
        (AUTO_POLICY_ID, HISTORY_ID,
         NO_OF_TRANSACTIONS, TXN_FEATURES_UPDATED_AT,
         NO_OF_VEHICLES, VEHICLE_FEATURES_UPDATED_AT,
         FEATURE_UPDATED_AT, LAST_SOURCE_EVENT_ID,
         SNAPSHOT_AT, REASON, EVENT_ID, CHANGED_FEATURE_GROUP,
         VALID_TRANSACTION_FROM, VALID_TRANSACTION_TO, IS_CURRENT)
        VALUES (
            'POL-1234', 'HIST-001',
            1, TIMESTAMP '2026-06-21 00:00:00',
            2, TIMESTAMP '2026-06-21 00:00:00',
            TIMESTAMP '2026-06-21 00:00:00', 'HIST-001',
            TIMESTAMP '2026-06-21 00:00:00',
            'new_business_seed',
            'HIST-001',
            'TXN_FEATURES,VEHICLE_FEATURES',
            TIMESTAMP '2026-06-21 00:00:00',
            NULL,
            true
        )
    """)
    print("Seeded AUTO_FEATURES_HISTORY: POL-1234 — IS_CURRENT=true, VALID_TRANSACTION_FROM=2026-06-21")

else:
    print("AUTO_FEATURES_HISTORY already has POL-1234 — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== POLICY_TXN_HISTORY ===")
display(spark.table(TXN_HISTORY))

print("=== AUTO_FEATURES_ACTIVE ===")
display(spark.table(ACTIVE))

print("=== AUTO_FEATURES_HISTORY ===")
display(spark.table(HISTORY))

print("\n>>> Next: Edit 02a_test_event → run 02a_test_event → run 01b_kafka_landing_zone <<<")
