# Databricks notebook source
# MAGIC %md
# MAGIC # 01 — Setup Tables
# MAGIC
# MAGIC | Table | Type | Role |
# MAGIC |---|---|---|
# MAGIC | `RAW_POLICY_EVENTS` | Bronze | Raw events from Kafka — append only |
# MAGIC | `RAW_EVENTS_DLQ` | Bronze | Dead letter queue for malformed events |
# MAGIC | `COMPUTED_FEATURE_EVENTS` | Silver | SP-computed features with per-feature effective dates |
# MAGIC | `AUTO_FEATURES_ACTIVE` | Feature Store | Live features — one row per policy |
# MAGIC | `AUTO_FEATURES_PENDING` | Feature Store | Future-dated features waiting for effective date |
# MAGIC | `AUTO_FEATURES_HISTORY` | Feature Store | SCD Type 2 full-row snapshots |
# MAGIC | `FEATURE_GROUP_REGISTRY` | Feature Store | Registry — routing type per feature group |
# MAGIC
# MAGIC ## Key Design Decisions
# MAGIC
# MAGIC - `RAW_POLICY_EVENTS` is append-only Bronze — never updated, never deleted
# MAGIC - `COMPUTED_FEATURE_EVENTS` has CDF enabled — routing pipeline reads via CDF stream
# MAGIC - `AUTO_FEATURES_ACTIVE` has CDF enabled — Lakebase / Online Store syncs via CDF
# MAGIC - Each feature group has its OWN effective date in `COMPUTED_FEATURE_EVENTS`
# MAGIC - `VALID_TRANSACTION_FROM` / `VALID_TRANSACTION_TO` use TIMESTAMP — minute precision, no overlap

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "model")
dbutils.widgets.dropdown("reset", "false", ["false", "true"])

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")
RESET   = dbutils.widgets.get("reset") == "true"

# Bronze
RAW_EVENTS  = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
DLQ         = f"{CATALOG}.{SCHEMA}.RAW_EVENTS_DLQ"

# Silver
COMPUTED    = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"

# Feature Store
ACTIVE      = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
PENDING     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_PENDING"
HISTORY     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"
REGISTRY    = f"{CATALOG}.{SCHEMA}.FEATURE_GROUP_REGISTRY"

# COMMAND ----------
# MAGIC %md
# MAGIC ## PRE-FLIGHT CHECKS
# MAGIC
# MAGIC Validates the environment before creating any tables.
# MAGIC All checks must pass (✅) before proceeding.
# MAGIC Any failure (❌) will raise an exception and stop the notebook.

# COMMAND ----------

import re

print("=" * 60)
print("  PRE-FLIGHT VALIDATION")
print("=" * 60)

errors   = []
warnings = []

# ── CHECK 1: Databricks Runtime Version ─────────────────────────
try:
    dbr_version = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion", "")
    if not dbr_version:
        dbr_version = spark.version  # fallback to Spark version
    major = int(re.search(r"(\d+)\.", dbr_version).group(1))
    if major >= 12:
        print(f"✅  CHECK 1 — Databricks Runtime : {dbr_version} (>= 12.0 required)")
    else:
        errors.append(f"DBR {dbr_version} is below 12.0. CDF and ARRAY<STRING> require DBR 12.0+.")
        print(f"❌  CHECK 1 — Databricks Runtime : {dbr_version} — UPGRADE REQUIRED (need >= 12.0)")
except Exception as e:
    warnings.append(f"Could not determine DBR version: {e}")
    print(f"⚠️   CHECK 1 — Databricks Runtime : Could not verify — proceeding with caution")

# ── CHECK 2: Unity Catalog Enabled ──────────────────────────────
try:
    spark.sql("SHOW CATALOGS").collect()
    print(f"✅  CHECK 2 — Unity Catalog       : Enabled")
except Exception as e:
    errors.append("Unity Catalog is not enabled. 3-level namespace (catalog.schema.table) will not work.")
    print(f"❌  CHECK 2 — Unity Catalog       : NOT ENABLED — required for {CATALOG}.{SCHEMA}.*")

# ── CHECK 3: Catalog Exists ──────────────────────────────────────
try:
    catalogs = [r[0] for r in spark.sql("SHOW CATALOGS").collect()]
    if CATALOG in catalogs:
        print(f"✅  CHECK 3 — Catalog '{CATALOG}'    : Exists")
    else:
        errors.append(f"Catalog '{CATALOG}' does not exist. Create it or change the catalog widget.")
        print(f"❌  CHECK 3 — Catalog '{CATALOG}'    : NOT FOUND")
        print(f"    Available catalogs: {catalogs}")
        print(f"    Fix: CREATE CATALOG {CATALOG};  OR change the catalog widget value.")
except Exception as e:
    errors.append(f"Could not check catalog: {e}")
    print(f"❌  CHECK 3 — Catalog check failed : {e}")

# ── CHECK 4: Schema Exists ───────────────────────────────────────
try:
    schemas = [r[0] for r in spark.sql(f"SHOW SCHEMAS IN {CATALOG}").collect()]
    if SCHEMA in schemas:
        print(f"✅  CHECK 4 — Schema '{SCHEMA}'     : Exists in {CATALOG}")
    else:
        errors.append(f"Schema '{SCHEMA}' does not exist in catalog '{CATALOG}'.")
        print(f"❌  CHECK 4 — Schema '{SCHEMA}'     : NOT FOUND in {CATALOG}")
        print(f"    Fix: CREATE SCHEMA {CATALOG}.{SCHEMA};  OR change the schema widget value.")
except Exception as e:
    errors.append(f"Could not check schema: {e}")
    print(f"❌  CHECK 4 — Schema check failed  : {e}")

# ── CHECK 5: Write Permission on Schema ──────────────────────────
try:
    _test_tbl = f"{CATALOG}.{SCHEMA}._preflight_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"CREATE TABLE IF NOT EXISTS {_test_tbl} (x INT) USING DELTA")
    spark.sql(f"DROP TABLE IF EXISTS {_test_tbl}")
    print(f"✅  CHECK 5 — Write Permission    : Can create/drop tables in {CATALOG}.{SCHEMA}")
except Exception as e:
    errors.append(f"No write permission on {CATALOG}.{SCHEMA}: {e}")
    print(f"❌  CHECK 5 — Write Permission    : FAILED — {e}")

# ── CHECK 6: CDF Supported ───────────────────────────────────────
try:
    _cdf_test = f"{CATALOG}.{SCHEMA}._cdf_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {_cdf_test} (x INT)
        USING DELTA
        TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
    """)
    spark.sql(f"DROP TABLE IF EXISTS {_cdf_test}")
    print(f"✅  CHECK 6 — CDF Support         : Change Data Feed supported")
except Exception as e:
    errors.append(f"CDF (Change Data Feed) not supported: {e}")
    print(f"❌  CHECK 6 — CDF Support         : FAILED — {e}")

# ── CHECK 7: Volume Support (for checkpoints) ────────────────────
try:
    spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}._preflight_vol_check")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}._preflight_vol_check")
    print(f"✅  CHECK 7 — Volume Support      : Can create Volumes in {CATALOG}.{SCHEMA}")
except Exception as e:
    warnings.append(f"Volume creation failed — checkpoint path may not work: {e}")
    print(f"⚠️   CHECK 7 — Volume Support      : WARNING — {e}")
    print(f"    Notebooks will still work but checkpoint path for streaming must be an existing path.")

# ── CHECK 8: Existing Tables (warn if RESET=false) ───────────────
try:
    existing_tables = [r[1] for r in spark.sql(f"SHOW TABLES IN {CATALOG}.{SCHEMA}").collect()]
    feature_tables  = ["RAW_POLICY_EVENTS","RAW_EVENTS_DLQ","COMPUTED_FEATURE_EVENTS",
                       "AUTO_FEATURES_ACTIVE","AUTO_FEATURES_PENDING",
                       "AUTO_FEATURES_HISTORY","FEATURE_GROUP_REGISTRY",
                       "POLICY_TXN_HISTORY"]
    already_exist   = [t for t in feature_tables if t in existing_tables]
    if already_exist and not RESET:
        warnings.append(f"Tables already exist: {already_exist}. Using CREATE IF NOT EXISTS — no data will be lost. Set reset=true to drop and recreate.")
        print(f"⚠️   CHECK 8 — Existing Tables    : {len(already_exist)} table(s) already exist — will be skipped (reset=false)")
        for t in already_exist:
            print(f"    → {t}")
    elif already_exist and RESET:
        print(f"⚠️   CHECK 8 — Existing Tables    : {len(already_exist)} table(s) will be DROPPED (reset=true)")
        for t in already_exist:
            print(f"    → {t}")
    else:
        print(f"✅  CHECK 8 — Existing Tables    : No conflicts — fresh setup")
except Exception as e:
    warnings.append(f"Could not check existing tables: {e}")
    print(f"⚠️   CHECK 8 — Existing Tables    : Could not verify — {e}")

# ── SUMMARY ─────────────────────────────────────────────────────
print()
print("=" * 60)
if errors:
    print(f"  RESULT: ❌  {len(errors)} ERROR(S) — CANNOT PROCEED")
    print("=" * 60)
    for i, err in enumerate(errors, 1):
        print(f"  [{i}] {err}")
    print()
    raise Exception(
        f"Pre-flight failed with {len(errors)} error(s). "
        f"Fix the issues above before running this notebook."
    )
elif warnings:
    print(f"  RESULT: ⚠️   PASSED WITH {len(warnings)} WARNING(S) — proceeding")
    print("=" * 60)
    for i, w in enumerate(warnings, 1):
        print(f"  [{i}] {w}")
    print()
    print("  Proceeding to table creation...")
else:
    print("  RESULT: ✅  ALL CHECKS PASSED — proceeding")
    print("=" * 60)
    print()
    print("  Proceeding to table creation...")

# COMMAND ----------

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Using: {CATALOG}.{SCHEMA}")

if RESET:
    for tbl in [RAW_EVENTS, DLQ, COMPUTED, ACTIVE, PENDING, HISTORY, REGISTRY]:
        spark.sql(f"DROP TABLE IF EXISTS {tbl}")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}.checkpoints")
    print("All tables dropped — will recreate.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 0. Create Checkpoint Volume

# COMMAND ----------

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.checkpoints")
print(f"Volume ready: /Volumes/{CATALOG}/{SCHEMA}/checkpoints")

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.incoming_xml")
print(f"Volume ready: /Volumes/{CATALOG}/{SCHEMA}/incoming_xml  ← drop XML files here (Kafka landing zone)")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 1. RAW_POLICY_EVENTS (Bronze)
# MAGIC
# MAGIC Append-only. One row per Kafka message received.
# MAGIC Malformed events go to RAW_EVENTS_DLQ instead.
# MAGIC
# MAGIC `RAW_PAYLOAD` stores the full Guidewire XML string exactly as received from Kafka — no transformation.
# MAGIC Flat fields (POLICY_NUMBER, TRANSACTION_DATE, POLICY_EFFECTIVE_DATE) are extracted at ingestion
# MAGIC so SQL queries (e.g. 14-day transaction count) work without parsing XML every time.
# MAGIC SP parses RAW_PAYLOAD to extract vehicle data.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {RAW_EVENTS} (
    HISTORY_ID            STRING    NOT NULL,
    POLICY_NUMBER         STRING    NOT NULL,
    POLICY_EFFECTIVE_DATE TIMESTAMP NOT NULL,
    TOTAL_TRANSACTIONS    INT       NOT NULL,
    LATEST_TXN_SEQUENCE   INT       NOT NULL,
    RAW_PAYLOAD           STRING    NOT NULL,
    INGESTED_AT           TIMESTAMP NOT NULL
)
USING DELTA
TBLPROPERTIES (
    'delta.appendOnly'           = 'true',
    'delta.enableChangeDataFeed' = 'true'
)
""")
print(f"Created: {RAW_EVENTS}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 2. RAW_EVENTS_DLQ (Dead Letter Queue)
# MAGIC
# MAGIC Catches malformed or unparseable Kafka messages.
# MAGIC Prevents bad events from stalling the pipeline.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DLQ} (
    RAW_PAYLOAD           STRING,
    ERROR_MESSAGE         STRING,
    FAILED_AT             TIMESTAMP NOT NULL,
    KAFKA_TOPIC           STRING,
    KAFKA_OFFSET          BIGINT,
    KAFKA_PARTITION       INT
)
USING DELTA
""")
print(f"Created: {DLQ}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 3. COMPUTED_FEATURE_EVENTS (Silver)
# MAGIC
# MAGIC Written by SP after computing features from RAW_POLICY_EVENTS.
# MAGIC CDF enabled — routing pipeline reads this via CDF stream.
# MAGIC
# MAGIC Key design: each feature group has its OWN effective date.
# MAGIC - `TXN_EFFECTIVE_DATE`    = TRANSACTION_DATE (always today — immediate)
# MAGIC - `POLICY_EFFECTIVE_DATE` = POLICY_EFFECTIVE_DATE from raw event (may be future)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {COMPUTED} (
    HISTORY_ID              STRING    NOT NULL,
    POLICY_NUMBER           STRING    NOT NULL,
    TRANSACTION_DATE        TIMESTAMP NOT NULL,

    -- Transaction features + their effective date
    NO_OF_TRANSACTIONS      INT,
    TXN_EFFECTIVE_DATE      TIMESTAMP NOT NULL,

    -- Vehicle features + their effective date
    NO_OF_VEHICLES          INT,
    POLICY_EFFECTIVE_DATE   TIMESTAMP NOT NULL,

    -- XML metadata
    TOTAL_TRANSACTIONS      INT,
    LATEST_TXN_SEQUENCE     INT,

    COMPUTED_AT             TIMESTAMP NOT NULL
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {COMPUTED}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 4. AUTO_FEATURES_ACTIVE (Feature Store)
# MAGIC
# MAGIC Live feature store — one row per policy.
# MAGIC CDF enabled for Lakebase / Online Store sync.
# MAGIC Each feature group has its own `_UPDATED_AT` timestamp
# MAGIC so you can tell exactly when each group was last refreshed.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {ACTIVE} (
    -- Identity
    AUTO_POLICY_ID               STRING    NOT NULL,
    HISTORY_ID                   STRING,

    -- Transaction features (routing_type = immediate)
    NO_OF_TRANSACTIONS           INT,
    TXN_FEATURES_UPDATED_AT      TIMESTAMP,

    -- Vehicle features (routing_type = effective_date)
    NO_OF_VEHICLES               INT,
    VEHICLE_FEATURES_UPDATED_AT  TIMESTAMP,

    -- Metadata
    FEATURE_UPDATED_AT           TIMESTAMP,
    LAST_SOURCE_EVENT_ID         STRING,

    CONSTRAINT AUTO_FEATURES_ACTIVE_PK PRIMARY KEY (AUTO_POLICY_ID)
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {ACTIVE}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 5. AUTO_FEATURES_PENDING (Feature Store)
# MAGIC
# MAGIC Future-dated features waiting for EFFECTIVE_DATE to arrive.
# MAGIC Only effective_date-driven feature groups land here.
# MAGIC Transaction features are always immediate — never go to pending.
# MAGIC Promotion job runs HOURLY — checks EFFECTIVE_DATE <= current_timestamp().

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {PENDING} (
    -- Identity
    AUTO_POLICY_ID               STRING    NOT NULL,
    HISTORY_ID                   STRING,

    -- Vehicle features (only effective_date groups land here)
    NO_OF_VEHICLES               INT,

    -- Scheduling
    EFFECTIVE_DATE               TIMESTAMP NOT NULL,
    CHANGED_FEATURE_GROUP        STRING,
    SOURCE_EVENT_ID              STRING,
    EVENT_RECEIVED_AT            TIMESTAMP
)
USING DELTA
""")
print(f"Created: {PENDING}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 6. AUTO_FEATURES_HISTORY (Feature Store)
# MAGIC
# MAGIC Full-row snapshots archived before every update (SCD Type 2).
# MAGIC
# MAGIC Validity window:
# MAGIC - `VALID_TRANSACTION_FROM` = effective date of the event that created this row (TIMESTAMP)
# MAGIC - `VALID_TRANSACTION_TO`   = effective date of the NEXT event minus 1 millisecond
# MAGIC - No overlap between consecutive rows for the same policy
# MAGIC - `IS_CURRENT = true`  → version currently in AUTO_FEATURES_ACTIVE
# MAGIC - `IS_CURRENT = false` → superseded historical version

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {HISTORY} (
    -- Identity
    AUTO_POLICY_ID               STRING    NOT NULL,
    HISTORY_ID                   STRING,

    -- Transaction features
    NO_OF_TRANSACTIONS           INT,
    TXN_FEATURES_UPDATED_AT      TIMESTAMP,

    -- Vehicle features
    NO_OF_VEHICLES               INT,
    VEHICLE_FEATURES_UPDATED_AT  TIMESTAMP,

    -- Metadata
    FEATURE_UPDATED_AT           TIMESTAMP,
    LAST_SOURCE_EVENT_ID         STRING,

    -- SCD Type 2 validity window (TIMESTAMP — minute precision)
    SNAPSHOT_AT                  TIMESTAMP NOT NULL,
    REASON                       STRING,
    EVENT_ID                     STRING,
    CHANGED_FEATURE_GROUP        STRING,
    VALID_TRANSACTION_FROM       TIMESTAMP NOT NULL,
    VALID_TRANSACTION_TO         TIMESTAMP,
    IS_CURRENT                   BOOLEAN   NOT NULL
)
USING DELTA
""")
print(f"Created: {HISTORY}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 7. FEATURE_GROUP_REGISTRY
# MAGIC
# MAGIC Controls routing at runtime — read fresh every micro-batch.
# MAGIC No code change needed to add or reroute a feature group.
# MAGIC
# MAGIC | ROUTING_TYPE | Behavior |
# MAGIC |---|---|
# MAGIC | immediate | Always MERGE to ACTIVE now — uses TXN_EFFECTIVE_DATE |
# MAGIC | effective_date | Check POLICY_EFFECTIVE_DATE: <= now → active, > now → pending |

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {REGISTRY} (
    FEATURE_GROUP    STRING        NOT NULL,
    OWNED_COLUMNS    ARRAY<STRING> NOT NULL,
    ROUTING_TYPE     STRING        NOT NULL,
    EFFECTIVE_DATE_COL STRING      NOT NULL,
    DESCRIPTION      STRING,
    CONSTRAINT FEATURE_GROUP_REGISTRY_PK PRIMARY KEY (FEATURE_GROUP)
)
USING DELTA
""")

if spark.table(REGISTRY).limit(1).count() == 0:
    spark.sql(f"""
    INSERT INTO {REGISTRY} VALUES
    (
        'TXN_FEATURES',
        ARRAY('NO_OF_TRANSACTIONS'),
        'immediate',
        'TXN_EFFECTIVE_DATE',
        'Transaction count features — always immediate. Uses TXN_EFFECTIVE_DATE = transaction_date. Serves retention model.'
    ),
    (
        'VEHICLE_FEATURES',
        ARRAY('NO_OF_VEHICLES'),
        'effective_date',
        'POLICY_EFFECTIVE_DATE',
        'Vehicle count features — respect policy effective date. Uses POLICY_EFFECTIVE_DATE. Serves loss/risk model.'
    )
    """)
    print("Registry seeded with 2 feature groups.")

print(f"Created: {REGISTRY}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify All Tables

# COMMAND ----------

tables = [
    ("RAW_POLICY_EVENTS",       RAW_EVENTS),
    ("RAW_EVENTS_DLQ",          DLQ),
    ("COMPUTED_FEATURE_EVENTS", COMPUTED),
    ("AUTO_FEATURES_ACTIVE",    ACTIVE),
    ("AUTO_FEATURES_PENDING",   PENDING),
    ("AUTO_FEATURES_HISTORY",   HISTORY),
    ("FEATURE_GROUP_REGISTRY",  REGISTRY),
]

print("=== Table Row Counts ===")
for label, tbl in tables:
    print(f"  {label:30s}: {spark.table(tbl).count()} rows")

print("\n=== FEATURE_GROUP_REGISTRY ===")
display(spark.table(REGISTRY))
