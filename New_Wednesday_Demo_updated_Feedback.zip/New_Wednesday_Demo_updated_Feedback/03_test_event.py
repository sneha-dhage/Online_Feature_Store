# Databricks notebook source
# MAGIC %md
# MAGIC # 03 — Test Event
# MAGIC
# MAGIC **Edit Section 1 (policy header) and Section 2 (transaction list), then run the Publish cell.**
# MAGIC
# MAGIC ## XML Structure
# MAGIC One XML per policy — contains the FULL transaction history for that policy.
# MAGIC SP finds the latest transaction (highest `<TransactionSequence>`) and reads:
# MAGIC - `NO_OF_TRANSACTIONS`   = count of `<Transaction>` nodes where `<IsDeleted>=0`
# MAGIC - `NO_OF_VEHICLES`       = vehicle count from the latest non-deleted transaction
# MAGIC - `POLICY_EFFECTIVE_DATE`= `<TransactionEffectiveDate>` of that latest transaction
# MAGIC
# MAGIC | Scenario | What to change |
# MAGIC |---|---|
# MAGIC | New business | 1 Transaction node, type=NewBusiness |
# MAGIC | Add vehicle (endorsement) | Add 2nd Transaction node, higher sequence, more vehicles |
# MAGIC | Soft delete / reversal | Set `<IsDeleted>1</IsDeleted>` on a transaction |
# MAGIC | Cancellation | Add Transaction node, type=Cancellation |

# COMMAND ----------

CATALOG       = "project"
SCHEMA        = "kafka_feedback"
KAFKA_LANDING = f"/Volumes/{CATALOG}/{SCHEMA}/incoming_xml"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Section 1 — Policy Header

# COMMAND ----------

HISTORY_ID            = "HIS-001"
POLICY_NUMBER         = "POL-1234"
POLICY_EFFECTIVE_DATE = "2026-07-07T00:00:00"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Section 2 — Transaction List
# MAGIC
# MAGIC Add `<Transaction>` nodes to simulate policy history.
# MAGIC Latest = highest `<TransactionSequence>` with `<IsDeleted>0</IsDeleted>`.

# COMMAND ----------

raw_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<PolicyChangeEvent>
    <HISTORY_ID>{HISTORY_ID}</HISTORY_ID>
    <PolicyNumber>{POLICY_NUMBER}</PolicyNumber>
    <PolicyEffectiveDate>{POLICY_EFFECTIVE_DATE}</PolicyEffectiveDate>
    <Transactions>

        <Transaction id="001">
            <TransactionSequence>1</TransactionSequence>
            <TransactionType>NewBusiness</TransactionType>
            <TransactionDate>2026-07-01T00:00:00</TransactionDate>
            <TransactionEffectiveDate>2026-07-01T00:00:00</TransactionEffectiveDate>
            <Vehicles>
                <Vehicle><VehicleId>VEH-001</VehicleId><Make>Toyota</Make><Model>Camry</Model></Vehicle>
                <Vehicle><VehicleId>VEH-002</VehicleId><Make>Honda</Make><Model>Civic</Model></Vehicle>
            </Vehicles>
            <TransactionStatus>Committed</TransactionStatus>
            <IsProcessed>1</IsProcessed>
            <IsDeleted>0</IsDeleted>
        </Transaction>

        <Transaction id="002">
            <TransactionSequence>2</TransactionSequence>
            <TransactionType>Endorsement</TransactionType>
            <TransactionDate>2026-07-01T10:30:00</TransactionDate>
            <TransactionEffectiveDate>2026-07-07T00:00:00</TransactionEffectiveDate>
            <Vehicles>
                <Vehicle><VehicleId>VEH-001</VehicleId><Make>Toyota</Make><Model>Camry</Model></Vehicle>
                <Vehicle><VehicleId>VEH-002</VehicleId><Make>Honda</Make><Model>Civic</Model></Vehicle>
                <Vehicle><VehicleId>VEH-003</VehicleId><Make>Ford</Make><Model>Explorer</Model></Vehicle>
            </Vehicles>
            <TransactionStatus>Committed</TransactionStatus>
            <IsProcessed>1</IsProcessed>
            <IsDeleted>0</IsDeleted>
        </Transaction>

    </Transactions>
</PolicyChangeEvent>"""

# COMMAND ----------
# MAGIC %md
# MAGIC ## Validate + Publish to Kafka Landing Zone

# COMMAND ----------

import xml.etree.ElementTree as ET
import datetime

root        = ET.fromstring(raw_xml)
txns        = root.findall("Transactions/Transaction")
active_txns = [t for t in txns if t.findtext("IsDeleted", "0").strip() == "0"]
latest_txn  = max(active_txns, key=lambda t: int(t.findtext("TransactionSequence", "0")))
vehicles    = latest_txn.findall("Vehicles/Vehicle")

print("=== Policy Header ===")
print(f"  HISTORY_ID            : {root.findtext('HISTORY_ID')}")
print(f"  POLICY_NUMBER         : {root.findtext('PolicyNumber')}")
print(f"  POLICY_EFFECTIVE_DATE : {root.findtext('PolicyEffectiveDate')}")

print(f"\n=== All Transactions ===")
for t in txns:
    seq     = t.findtext("TransactionSequence")
    typ     = t.findtext("TransactionType", "")
    deleted = t.findtext("IsDeleted", "0").strip()
    vehs    = len(t.findall("Vehicles/Vehicle"))
    eff     = t.findtext("TransactionEffectiveDate", "—")
    flag    = " ← DELETED" if deleted == "1" else ""
    print(f"  Seq {seq}: {typ:20s} | vehicles={vehs} | eff={eff}{flag}")

print(f"\n=== SP will compute ===")
print(f"  NO_OF_TRANSACTIONS   : {len(active_txns)}  (IsDeleted=0)")
print(f"  NO_OF_VEHICLES       : {len(vehicles)}  (from seq={latest_txn.findtext('TransactionSequence')})")
print(f"  POLICY_EFFECTIVE_DATE: {latest_txn.findtext('TransactionEffectiveDate')}  (latest txn)")

ts        = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
drop_path = f"{KAFKA_LANDING}/{HISTORY_ID}_{ts}.xml"
dbutils.fs.put(drop_path, raw_xml, overwrite=True)

print(f"\n✓ Published: {drop_path}")
print(f"\n>>> Next: Run 04_kafka_landing_zone <<<")
