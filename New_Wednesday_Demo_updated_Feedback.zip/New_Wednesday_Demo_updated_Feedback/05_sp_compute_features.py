# Databricks notebook source
# MAGIC %md
# MAGIC # 05 — SP: Compute Features → COMPUTED_FEATURE_EVENTS (Silver)
# MAGIC
# MAGIC Streams from `RAW_POLICY_EVENTS` via CDF.
# MAGIC Parses the full XML and computes both features — no external table lookups.
# MAGIC
# MAGIC ## Feature Logic (all from XML)
# MAGIC
# MAGIC | Feature | How |
# MAGIC |---|---|
# MAGIC | `NO_OF_TRANSACTIONS` | Count `<Transaction>` nodes where `<IsDeleted>=0` |
# MAGIC | `NO_OF_VEHICLES` | Vehicle count from latest transaction (highest `<TransactionSequence>`) |
# MAGIC | `POLICY_EFFECTIVE_DATE` | `<TransactionEffectiveDate>` of latest transaction → drives PENDING vs ACTIVE |
# MAGIC | `TRANSACTION_DATE` | `<TransactionDate>` of latest transaction → TXN_FEATURES effective date |

# COMMAND ----------

import xml.etree.ElementTree as ET
from pyspark.sql import functions as F

dbutils.widgets.text("catalog",         "project")
dbutils.widgets.text("schema",          "kafka_feedback")
dbutils.widgets.text("checkpoint_path", "/Volumes/project/kafka_feedback/checkpoints/sp_compute")

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")

RAW_EVENTS = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
COMPUTED   = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"

# COMMAND ----------
# MAGIC %md
# MAGIC ## foreachBatch — Parse XML and Compute Features

# COMMAND ----------

def compute_batch(df, batch_id):
    new_rows = df.filter(F.col("_change_type") == "insert")
    count    = new_rows.count()
    print(f"\n[batch {batch_id}] {count} new event(s)")
    if count == 0:
        return

    events = new_rows.orderBy("INGESTED_AT", "HISTORY_ID").collect()

    for event in events:
        history_id        = event["HISTORY_ID"]
        policy_number     = event["POLICY_NUMBER"]
        raw_payload       = event["RAW_PAYLOAD"]
        total_transactions = event["TOTAL_TRANSACTIONS"]

        # Idempotency — same HISTORY_ID + same transaction count already computed
        already = spark.sql(f"""
            SELECT COUNT(*) AS cnt FROM {COMPUTED}
            WHERE HISTORY_ID         = '{history_id}'
              AND TOTAL_TRANSACTIONS = {total_transactions}
        """).first()["cnt"]

        if already > 0:
            print(f"  [{history_id}] already computed — skipping")
            continue

        try:
            root        = ET.fromstring(raw_payload)
            txns        = root.findall("Transactions/Transaction")
            active_txns = [t for t in txns if t.findtext("IsDeleted", "0").strip() == "0"]

            # ── NO_OF_TRANSACTIONS ───────────────────────────────────────
            no_of_transactions = len(active_txns)

            # ── Latest transaction (highest TransactionSequence, non-deleted) ─
            latest_txn  = max(active_txns, key=lambda t: int(t.findtext("TransactionSequence", "0")))
            latest_seq  = latest_txn.findtext("TransactionSequence")
            latest_type = latest_txn.findtext("TransactionType", "")

            # ── NO_OF_VEHICLES ───────────────────────────────────────────
            vehicles       = latest_txn.findall("Vehicles/Vehicle")
            no_of_vehicles = len(vehicles)
            vehicle_ids    = [v.findtext("VehicleId", "").strip() for v in vehicles]

            # ── Effective dates ──────────────────────────────────────────
            def clean(ts):
                return (ts or "").strip().replace("T", " ").split(".")[0]

            transaction_date      = clean(latest_txn.findtext("TransactionDate"))
            policy_effective_date = clean(latest_txn.findtext("TransactionEffectiveDate"))

        except Exception as e:
            print(f"  [{history_id}] XML parse error: {e} — skipping")
            continue

        spark.sql(f"""
            INSERT INTO {COMPUTED}
            (HISTORY_ID, POLICY_NUMBER, TRANSACTION_DATE,
             NO_OF_TRANSACTIONS, TXN_EFFECTIVE_DATE,
             NO_OF_VEHICLES, POLICY_EFFECTIVE_DATE,
             TOTAL_TRANSACTIONS, LATEST_TXN_SEQUENCE,
             COMPUTED_AT)
            VALUES (
                '{history_id}',
                '{policy_number}',
                TIMESTAMP '{transaction_date}',
                {no_of_transactions},
                TIMESTAMP '{transaction_date}',
                {no_of_vehicles},
                TIMESTAMP '{policy_effective_date}',
                {total_transactions},
                {latest_seq},
                current_timestamp()
            )
        """)

        print(f"  [{history_id}] NO_OF_TRANSACTIONS={no_of_transactions} | latest=seq{latest_seq} ({latest_type})")
        print(f"           NO_OF_VEHICLES={no_of_vehicles} {vehicle_ids}")
        print(f"           txn_eff={transaction_date} | policy_eff={policy_effective_date}")

    print(f"\n[batch {batch_id}] done.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Start Streaming from RAW_POLICY_EVENTS via CDF

# COMMAND ----------

query = (
    spark.readStream
         .format("delta")
         .option("readChangeFeed",  "true")
         .option("startingVersion", "0")
         .table(RAW_EVENTS)
         .writeStream
         .foreachBatch(compute_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nSP compute — finished.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== COMPUTED_FEATURE_EVENTS ===")
display(spark.table(COMPUTED).orderBy("COMPUTED_AT"))

print("\n>>> Next: Run 06_routing_pipeline <<<")
