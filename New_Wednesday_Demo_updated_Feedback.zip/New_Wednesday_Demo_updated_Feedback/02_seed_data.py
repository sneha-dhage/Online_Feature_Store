# Databricks notebook source
# MAGIC %md
# MAGIC # 02 — Seed Data
# MAGIC
# MAGIC Seeds the Feature Store with a baseline state for POL-1234
# MAGIC so the demo starts with an existing policy already active.
# MAGIC
# MAGIC | Layer | Table | Seed value |
# MAGIC |---|---|---|
# MAGIC | Feature Store | AUTO_FEATURES_ACTIVE | POL-1234 — NO_OF_TRANSACTIONS=1, NO_OF_VEHICLES=2 |
# MAGIC | Feature Store | AUTO_FEATURES_HISTORY | POL-1234 — IS_CURRENT=true, VALID_FROM=2026-07-01 |
# MAGIC
# MAGIC `RAW_POLICY_EVENTS` is NOT seeded — XML arrives via `03_test_event` → `04_kafka_landing_zone`.
# MAGIC `COMPUTED_FEATURE_EVENTS` is NOT seeded — only receives rows written by SP (05).
# MAGIC `POLICY_TXN_HISTORY` no longer exists — transaction history lives inside the XML.

# COMMAND ----------

dbutils.widgets.text("catalog", "project")
dbutils.widgets.text("schema",  "kafka_feedback")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

ACTIVE  = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
HISTORY = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Feature Store: AUTO_FEATURES_ACTIVE

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {ACTIVE} WHERE AUTO_POLICY_ID = 'POL-1234'").first()["cnt"] == 0:
    spark.sql(f"""
        INSERT INTO {ACTIVE}
        (AUTO_POLICY_ID, HISTORY_ID,
         NO_OF_TRANSACTIONS, TXN_FEATURES_UPDATED_AT,
         NO_OF_VEHICLES, VEHICLE_FEATURES_UPDATED_AT,
         FEATURE_UPDATED_AT, LAST_SOURCE_EVENT_ID)
        VALUES (
            'POL-1234', 'HIS-001',
            1, TIMESTAMP '2026-07-01 00:00:00',
            2, TIMESTAMP '2026-07-01 00:00:00',
            TIMESTAMP '2026-07-01 00:00:00', 'HIS-001'
        )
    """)
    print("Seeded AUTO_FEATURES_ACTIVE: POL-1234 — (NO_OF_TRANSACTIONS=1, NO_OF_VEHICLES=2)")
else:
    print("AUTO_FEATURES_ACTIVE already has POL-1234 — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Feature Store: AUTO_FEATURES_HISTORY

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {HISTORY} WHERE AUTO_POLICY_ID = 'POL-1234'").first()["cnt"] == 0:
    spark.sql(f"""
        INSERT INTO {HISTORY}
        (AUTO_POLICY_ID, HISTORY_ID,
         NO_OF_TRANSACTIONS, TXN_FEATURES_UPDATED_AT,
         NO_OF_VEHICLES, VEHICLE_FEATURES_UPDATED_AT,
         FEATURE_UPDATED_AT, LAST_SOURCE_EVENT_ID,
         SNAPSHOT_AT, REASON, EVENT_ID, CHANGED_FEATURE_GROUP,
         VALID_TRANSACTION_FROM, VALID_TRANSACTION_TO, IS_CURRENT)
        VALUES (
            'POL-1234', 'HIS-001',
            1, TIMESTAMP '2026-07-01 00:00:00',
            2, TIMESTAMP '2026-07-01 00:00:00',
            TIMESTAMP '2026-07-01 00:00:00', 'HIS-001',
            TIMESTAMP '2026-07-01 00:00:00',
            'new_business_seed', 'HIS-001',
            'TXN_FEATURES,VEHICLE_FEATURES',
            TIMESTAMP '2026-07-01 00:00:00',
            NULL, true
        )
    """)
    print("Seeded AUTO_FEATURES_HISTORY: POL-1234 — IS_CURRENT=true")
else:
    print("AUTO_FEATURES_HISTORY already has POL-1234 — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== AUTO_FEATURES_ACTIVE ===")
display(spark.table(ACTIVE))

print("=== AUTO_FEATURES_HISTORY ===")
display(spark.table(HISTORY))

print("\n>>> Next: Edit 03_test_event → run 03_test_event → run 04_kafka_landing_zone <<<")
