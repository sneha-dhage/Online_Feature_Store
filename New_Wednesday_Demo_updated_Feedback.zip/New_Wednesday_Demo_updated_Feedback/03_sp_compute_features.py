# Databricks notebook source
# MAGIC %md
# MAGIC # 03 — SP: Compute Features → COMPUTED_FEATURE_EVENTS (Silver)
# MAGIC
# MAGIC Streams from RAW_POLICY_EVENTS via CDF.
# MAGIC For every new INSERT, computes features and writes one row per event
# MAGIC to COMPUTED_FEATURE_EVENTS with per-feature effective dates.
# MAGIC
# MAGIC Multiple events in the same micro-batch are processed in
# MAGIC TRANSACTION_DATE ASC order so 14-day counts are always correct.
# MAGIC
# MAGIC ## Feature Logic
# MAGIC
# MAGIC | Feature | Source | Effective Date | Routing |
# MAGIC |---|---|---|---|
# MAGIC | `NO_OF_TRANSACTIONS` | COUNT(*) from POLICY_TXN_HISTORY where POLICY_NUMBER matches and IS_DELETED=false | `TRANSACTION_DATE` (immediate) | immediate |
# MAGIC | `NO_OF_VEHICLES` | Parse `<Vehicles>` from RAW_PAYLOAD XML of THIS event | `POLICY_EFFECTIVE_DATE` (may be future) | effective_date |
# MAGIC
# MAGIC ## Key Design
# MAGIC - CDF on RAW_POLICY_EVENTS triggers this pipeline automatically after every INSERT.
# MAGIC - NO_OF_TRANSACTIONS reads from POLICY_TXN_HISTORY (not RAW_POLICY_EVENTS) — IS_DELETED=false filter.
# MAGIC - NO_OF_VEHICLES parsed from XML in RAW_POLICY_EVENTS.
# MAGIC - NO sim_date dependency here — we use actual event timestamps.

# COMMAND ----------

import xml.etree.ElementTree as ET
from pyspark.sql import functions as F

dbutils.widgets.text("catalog",         "main")
dbutils.widgets.text("schema",          "model")
dbutils.widgets.text("checkpoint_path", "/Volumes/main/model/checkpoints/sp_compute")

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")

TXN_HISTORY = f"{CATALOG}.{SCHEMA}.POLICY_TXN_HISTORY"
RAW_EVENTS  = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
COMPUTED    = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"

# COMMAND ----------
# MAGIC %md
# MAGIC ## foreachBatch — Compute Features for Every New Event

# COMMAND ----------

def compute_batch(df, batch_id):
    # Only care about new rows landing in Bronze
    new_rows = df.filter(F.col("_change_type") == "insert")
    count = new_rows.count()
    print(f"\n[batch {batch_id}] {count} new event(s) from RAW_POLICY_EVENTS")
    if count == 0:
        return

    # Process in TRANSACTION_DATE order so 14-day counts are sequentially correct
    # (H03 → H04 → H05 each see only events up to their own date)
    events = new_rows.orderBy("TRANSACTION_DATE", "HISTORY_ID").collect()

    for event in events:
        history_id            = event["HISTORY_ID"]
        policy_number         = event["POLICY_NUMBER"]
        transaction_date      = str(event["TRANSACTION_DATE"])
        policy_effective_date = str(event["POLICY_EFFECTIVE_DATE"])
        raw_payload           = event["RAW_PAYLOAD"]

        # Idempotency — skip if already computed (replay-safe)
        already = spark.sql(f"""
            SELECT COUNT(*) AS cnt FROM {COMPUTED}
            WHERE HISTORY_ID = '{history_id}'
        """).first()["cnt"]

        if already > 0:
            print(f"  [{history_id}] already in COMPUTED_FEATURE_EVENTS — skipping")
            continue

        # ── Feature 1: NO_OF_TRANSACTIONS ──────────────────────────────
        # Count all non-deleted transactions for this policy from POLICY_TXN_HISTORY.
        # IS_DELETED=false excludes soft-deleted/reversed transactions.
        no_of_transactions = spark.sql(f"""
            SELECT COUNT(*) AS cnt
            FROM {TXN_HISTORY}
            WHERE POLICY_NUMBER = '{policy_number}'
              AND IS_DELETED    = false
        """).first()["cnt"]

        # ── Feature 2: NO_OF_VEHICLES ───────────────────────────────────
        # Parse XML from this event's RAW_PAYLOAD — each event carries its own vehicle list.
        try:
            root           = ET.fromstring(raw_payload)
            vehicle_nodes  = root.findall("Vehicles/Vehicle")
            no_of_vehicles = len(vehicle_nodes)
            vehicle_ids    = [v.findtext("VehicleId", "").strip() for v in vehicle_nodes]
        except Exception as e:
            print(f"  [{history_id}] XML parse error: {e} — NO_OF_VEHICLES set to 0")
            no_of_vehicles = 0
            vehicle_ids    = []

        # ── Write to COMPUTED_FEATURE_EVENTS ────────────────────────────
        spark.sql(f"""
            INSERT INTO {COMPUTED}
            (HISTORY_ID, POLICY_NUMBER, TRANSACTION_DATE,
             NO_OF_TRANSACTIONS, TXN_EFFECTIVE_DATE,
             NO_OF_VEHICLES, POLICY_EFFECTIVE_DATE,
             COMPUTED_AT)
            VALUES (
                '{history_id}',
                '{policy_number}',
                TIMESTAMP '{transaction_date}',
                {no_of_transactions},
                TIMESTAMP '{transaction_date}',
                {no_of_vehicles},
                TIMESTAMP '{policy_effective_date}',
                current_timestamp()
            )
        """)

        print(f"  [{history_id}] → NO_OF_TRANSACTIONS={no_of_transactions}  (eff: {transaction_date} — immediate)")
        print(f"  [{history_id}] → NO_OF_VEHICLES={no_of_vehicles} {vehicle_ids}  (eff: {policy_effective_date} — may be future)")

    print(f"\n[batch {batch_id}] done.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Start Streaming from RAW_POLICY_EVENTS via CDF

# COMMAND ----------

query = (
    spark.readStream
         .format("delta")
         .option("readChangeFeed", "true")
         .option("startingVersion", "0")
         .table(RAW_EVENTS)
         .writeStream
         .foreachBatch(compute_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nSP compute pipeline finished.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== COMPUTED_FEATURE_EVENTS ===")
display(spark.table(COMPUTED).orderBy("TRANSACTION_DATE", "HISTORY_ID"))

print("\n>>> Next: Run 04_routing_pipeline <<<")
