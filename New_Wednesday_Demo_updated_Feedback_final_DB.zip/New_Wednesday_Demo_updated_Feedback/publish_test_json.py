# Databricks notebook source
# MAGIC %md
# MAGIC # Publish Test JSON (testing utility — not a pipeline step)
# MAGIC
# MAGIC Paste a transaction JSON into `RAW_JSON` below and run the Publish cell — it lands the
# MAGIC file straight into the `incoming_json` volume, same as if you'd uploaded it through the UI.
# MAGIC Use this whenever you want to push a new test transaction without leaving the notebook.
# MAGIC
# MAGIC Required top-level fields: `plcy_id_sk`, `eff_dt`, `src_trans_tmsp`,
# MAGIC `1_vehicle_snapshot`, `2_driver_snapshot`, `3_coverage_snapshot`.
# MAGIC
# MAGIC `auto_plcy_trans_sk` is auto-generated whenever it's missing/blank, so you can paste the
# MAGIC same JSON again and again as distinct test transactions without tripping the idempotency
# MAGIC check in `03_autoloader_landing_zone` (which dedupes on TRANS_ID). If your JSON already has a
# MAGIC real `auto_plcy_trans_sk`, that value is kept as-is.
# MAGIC
# MAGIC >>> After publishing: run `03_autoloader_landing_zone` → `04_sp_compute_features` → `05_routing_pipeline` <<<

# COMMAND ----------

import json
import datetime

CATALOG        = "main"
SCHEMA         = "final_database"
LANDING_VOLUME = f"/Volumes/{CATALOG}/{SCHEMA}/incoming_json"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Paste JSON Here

# COMMAND ----------

RAW_JSON = """
<paste your transaction JSON here>
"""

# COMMAND ----------
# MAGIC %md
# MAGIC ## Validate + Publish to the Landing Volume

# COMMAND ----------

event = json.loads(RAW_JSON)

REQUIRED_FIELDS = ["plcy_id_sk", "eff_dt", "src_trans_tmsp",
                   "1_vehicle_snapshot", "2_driver_snapshot", "3_coverage_snapshot"]
missing = [f for f in REQUIRED_FIELDS if not event.get(f)]
if missing:
    raise ValueError(f"Pasted JSON is missing required field(s): {missing}")

if not event.get("auto_plcy_trans_sk"):
    event["auto_plcy_trans_sk"] = f"TXN-{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"
    print(f"auto_plcy_trans_sk was blank — generated: {event['auto_plcy_trans_sk']}")

policy_id = str(event["plcy_id_sk"])
trans_id  = str(event["auto_plcy_trans_sk"])

CVG_CATEGORIES = {"BI", "PD", "MD", "COLL", "COMP", "PIP"}
in_scope_cvg   = [c for c in event["3_coverage_snapshot"] if c.get("mva_cvg_ctgy_cd") in CVG_CATEGORIES]
outstanding    = str(event["eff_dt"]) > datetime.date.today().isoformat()

print("=== Transaction Header ===")
print(f"  plcy_id_sk         : {policy_id}")
print(f"  auto_plcy_trans_sk : {trans_id}")
print(f"  eff_dt             : {event['eff_dt']}  {'(FUTURE — routes to PENDING)' if outstanding else '(today/past — routes to ACTIVE)'}")
print(f"  src_trans_tmsp     : {event['src_trans_tmsp']}")

print(f"\n=== Snapshot sizes ===")
print(f"  vehicles  : {len(event['1_vehicle_snapshot'])}")
print(f"  drivers   : {len(event['2_driver_snapshot'])}")
print(f"  coverages : {len(event['3_coverage_snapshot'])} ({len(in_scope_cvg)} in BI/PD/MD/COLL/COMP/PIP scope)")

ts        = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
drop_path = f"{LANDING_VOLUME}/{policy_id}_{trans_id}_{ts}.json"
dbutils.fs.put(drop_path, json.dumps(event, indent=2), overwrite=True)

print(f"\n✓ Published: {drop_path}")
print(f"\n>>> Next: Run 03_autoloader_landing_zone <<<")
