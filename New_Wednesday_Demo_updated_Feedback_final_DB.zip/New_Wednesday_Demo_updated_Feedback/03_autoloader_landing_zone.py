# Databricks notebook source
# MAGIC %md
# MAGIC # 03 — Autoloader Landing Zone
# MAGIC
# MAGIC Reads transaction JSON files from the Volume via Auto Loader and lands them into `RAW_POLICY_EVENTS`.
# MAGIC
# MAGIC ## What happens per JSON file
# MAGIC ```
# MAGIC Your transaction JSON lands in → /Volumes/.../incoming_json/
# MAGIC       ↓
# MAGIC Auto Loader detects the new file (one file = one transaction)
# MAGIC       ↓
# MAGIC Extract: plcy_id_sk, plcy_cntrct_num, src_hh_num, auto_plcy_trans_sk, eff_dt, src_trans_tmsp
# MAGIC       ↓
# MAGIC INSERT → RAW_POLICY_EVENTS (Bronze — full JSON stored as RAW_PAYLOAD)
# MAGIC       ↓
# MAGIC CDF on RAW_POLICY_EVENTS triggers 04_sp_compute_features
# MAGIC ```
# MAGIC
# MAGIC ## JSON structure expected
# MAGIC ```json
# MAGIC {
# MAGIC   "plcy_id_sk": "503203043",
# MAGIC   "plcy_cntrct_num": "519748512",
# MAGIC   "src_hh_num": "4794013556",
# MAGIC   "auto_plcy_trans_sk": "TXN-...",
# MAGIC   "eff_dt": "2026-07-20",
# MAGIC   "src_trans_tmsp": "2026-07-20 10:42:18.526",
# MAGIC   "1_vehicle_snapshot": [...],
# MAGIC   "2_driver_snapshot": [...],
# MAGIC   "3_coverage_snapshot": [...]
# MAGIC }
# MAGIC ```

# COMMAND ----------

import json

dbutils.widgets.text("catalog",         "main")
dbutils.widgets.text("schema",          "final_database")
dbutils.widgets.text("checkpoint_path", "/Volumes/main/final_database/checkpoints/autoloader_landing")

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")

LANDING_VOLUME = f"/Volumes/{CATALOG}/{SCHEMA}/incoming_json"
RAW_EVENTS     = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
DLQ            = f"{CATALOG}.{SCHEMA}.RAW_EVENTS_DLQ"

print(f"Watching : {LANDING_VOLUME}")
print(f"Landing  : {RAW_EVENTS}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Process Each JSON File

# COMMAND ----------

def _clean_ts(ts):
    return ts.strip().replace("T", " ").split(".")[0]


def _sql_escape(value):
    return str(value).replace("'", "''")


def process_landing_batch(df, batch_id):
    files = df.collect()
    print(f"\n[batch {batch_id}] {len(files)} JSON file(s)")

    for row in files:
        source_file = row["path"]
        try:
            raw_payload = row["content"].decode("utf-8")
            event       = json.loads(raw_payload)

            trans_id  = str(event.get("auto_plcy_trans_sk", "")).strip()
            policy_id = str(event.get("plcy_id_sk", "")).strip()
            cntrct_num = str(event.get("plcy_cntrct_num", "") or "").strip()
            hh_num     = str(event.get("src_hh_num", "") or "").strip()
            eff_dt     = str(event.get("eff_dt", "")).strip()
            trans_tmsp = str(event.get("src_trans_tmsp", "")).strip()

            missing = [f for f, v in {
                "auto_plcy_trans_sk": trans_id,
                "plcy_id_sk":         policy_id,
                "eff_dt":             eff_dt,
                "src_trans_tmsp":     trans_tmsp,
            }.items() if not v]

            if missing:
                raise ValueError(f"Missing JSON header fields: {missing}")

            if not isinstance(event.get("1_vehicle_snapshot"), list) or not event["1_vehicle_snapshot"]:
                raise ValueError("1_vehicle_snapshot is missing or empty")

            # Idempotency — skip if this exact transaction is already landed
            existing = spark.sql(f"""
                SELECT COUNT(*) AS cnt FROM {RAW_EVENTS}
                WHERE TRANS_ID = '{_sql_escape(trans_id)}'
            """).first()["cnt"]

            if existing > 0:
                print(f"  [{trans_id}] already in RAW_POLICY_EVENTS — skipping")
                continue

            spark.sql(f"""
                INSERT INTO {RAW_EVENTS}
                (TRANS_ID, AUTO_POLICY_ID, PLCY_CNTRCT_NUM, SRC_HH_NUM,
                 EFF_DT, SRC_TRANS_TMSP,
                 RAW_PAYLOAD, INGESTED_AT)
                VALUES (
                    '{_sql_escape(trans_id)}',
                    '{_sql_escape(policy_id)}',
                    '{_sql_escape(cntrct_num)}',
                    '{_sql_escape(hh_num)}',
                    TIMESTAMP '{_clean_ts(eff_dt)}',
                    TIMESTAMP '{_clean_ts(trans_tmsp)}',
                    '{_sql_escape(raw_payload)}',
                    current_timestamp()
                )
            """)

            print(f"  [{trans_id}] landed | policy={policy_id} | eff_dt={eff_dt} | vehicles={len(event['1_vehicle_snapshot'])}")

        except Exception as e:
            spark.sql(f"""
                INSERT INTO {DLQ}
                (RAW_PAYLOAD, ERROR_MESSAGE, FAILED_AT, SOURCE_NAME)
                VALUES (
                    '{_sql_escape(source_file)}',
                    '{_sql_escape(str(e))}',
                    current_timestamp(),
                    'policy_change_events'
                )
            """)
            print(f"  [DLQ] {source_file} — {e}")

    print(f"\n[batch {batch_id}] done.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Start Auto Loader

# COMMAND ----------

query = (
    spark.readStream
         .format("cloudFiles")
         .option("cloudFiles.format",        "binaryFile")
         .option("pathGlobFilter",            "*.json")
         .option("cloudFiles.schemaLocation", CHECKPOINT_PATH + "/schema")
         .load(LANDING_VOLUME)
         .writeStream
         .foreachBatch(process_landing_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nAuto Loader landing — batch complete.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== RAW_POLICY_EVENTS ===")
display(spark.table(RAW_EVENTS).orderBy("INGESTED_AT"))

print("=== DLQ ===")
display(spark.sql(f"SELECT * FROM {DLQ} ORDER BY FAILED_AT DESC"))

print("\n>>> Next: Run 04_sp_compute_features <<<")
