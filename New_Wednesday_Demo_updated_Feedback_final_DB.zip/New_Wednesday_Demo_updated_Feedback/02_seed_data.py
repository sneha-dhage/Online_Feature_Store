# Databricks notebook source
# MAGIC %md
# MAGIC # 02 — Seed Data
# MAGIC
# MAGIC Seeds the Feature Store with a baseline state for policy `503203043`
# MAGIC so the demo starts with an existing policy already active.
# MAGIC (`503203043` / `519748512` / `4794013556` — adjust to match whatever real policy you plan to test with.)
# MAGIC
# MAGIC | Layer | Table | Seed value |
# MAGIC |---|---|---|
# MAGIC | Feature Store | AUTO_FEATURES_ACTIVE | AUTO_POLICY_ID=503203043 — VEH_CNT=2, DRVR_CNT=2 |
# MAGIC | Feature Store | AUTO_FEATURES_HISTORY | AUTO_POLICY_ID=503203043 — IS_CURRENT=true, VALID_FROM=2026-07-01 |
# MAGIC
# MAGIC `RAW_POLICY_EVENTS` is NOT seeded — upload your real transaction JSON to the `incoming_json` volume, then run `03_autoloader_landing_zone`.
# MAGIC `COMPUTED_FEATURE_EVENTS` is NOT seeded — only receives rows written by PySpark compute (05).

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "final_database")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

ACTIVE  = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
HISTORY = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"

SEED_POLICY_ID   = "503203043"
SEED_CNTRCT_NUM  = "519748512"
SEED_HH_NUM      = "4794013556"
SEED_TRANS_ID    = "TXN-SEED-001"
SEED_TS          = "2026-07-01 00:00:00"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Feature values for the seed row
# MAGIC
# MAGIC Built as Python dicts (not hand-typed SQL) so the column list can never drift
# MAGIC out of sync with the ~29-column schema created in `01_setup_tables`.

# COMMAND ----------

GROUP_A_SEED = {
    "TXN_CNT_1D":            0,
    "TXN_CNT_1W":            0,
    "TXN_CNT_1M":            1,
    "OUTSTANDING_TXN_IND":   0,
    "TENURE_YRS":            0,
}

GROUP_B_SEED = {
    "VEH_CNT":                 2,
    "AVG_VEH_AGE":              10.5,
    "VEH_ADDED_LATEST_TXN":     0,
    "DRVR_CNT":                 2,
    "MAX_DRVR_AGE":             45,
    "MIN_DRVR_AGE":             30,
    "AVG_DRVR_AGE":             37.5,
    "DRVRS_ADDED_LATEST_TXN":   0,
    "PREM_CHANGE_AMT":          0.0,
    "BI_COVERAGE_ADDED":        0,
    "BI_COVERAGE_REMOVED":      0,
    "PD_COVERAGE_ADDED":        0,
    "PD_COVERAGE_REMOVED":      0,
    "MD_COVERAGE_ADDED":        0,
    "MD_COVERAGE_REMOVED":      0,
    "COLL_COVERAGE_ADDED":      0,
    "COLL_COVERAGE_REMOVED":    0,
    "COMP_COVERAGE_ADDED":      0,
    "COMP_COVERAGE_REMOVED":    0,
    "PIP_COVERAGE_ADDED":       0,
    "PIP_COVERAGE_REMOVED":     0,
    "COMP_DED_CHANGE_IND":      0,
    "GNDR_CHANGE_IND":          0,
    "MRTL_CHANGE_IND":          0,
}


def _sql_literal(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    return f"'{value}'"


# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Feature Store: AUTO_FEATURES_ACTIVE

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {ACTIVE} WHERE AUTO_POLICY_ID = '{SEED_POLICY_ID}'").first()["cnt"] == 0:
    columns = (
        ["AUTO_POLICY_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM", "TRANS_ID"]
        + list(GROUP_A_SEED.keys()) + ["GROUP_A_UPDATED_AT"]
        + list(GROUP_B_SEED.keys()) + ["GROUP_B_UPDATED_AT"]
        + ["FEATURE_UPDATED_AT", "LAST_SOURCE_EVENT_ID"]
    )
    values = (
        [SEED_POLICY_ID, SEED_CNTRCT_NUM, SEED_HH_NUM, SEED_TRANS_ID]
        + list(GROUP_A_SEED.values()) + [f"TIMESTAMP '{SEED_TS}'"]
        + list(GROUP_B_SEED.values()) + [f"TIMESTAMP '{SEED_TS}'"]
        + [f"TIMESTAMP '{SEED_TS}'", SEED_TRANS_ID]
    )
    value_sql = ", ".join(v if str(v).startswith("TIMESTAMP") else _sql_literal(v) for v in values)

    spark.sql(f"""
        INSERT INTO {ACTIVE} ({", ".join(columns)})
        VALUES ({value_sql})
    """)
    print(f"Seeded AUTO_FEATURES_ACTIVE: {SEED_POLICY_ID} — (VEH_CNT={GROUP_B_SEED['VEH_CNT']}, DRVR_CNT={GROUP_B_SEED['DRVR_CNT']})")
else:
    print(f"AUTO_FEATURES_ACTIVE already has {SEED_POLICY_ID} — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Feature Store: AUTO_FEATURES_HISTORY

# COMMAND ----------

if spark.sql(f"SELECT COUNT(*) AS cnt FROM {HISTORY} WHERE AUTO_POLICY_ID = '{SEED_POLICY_ID}'").first()["cnt"] == 0:
    columns = (
        ["AUTO_POLICY_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM", "TRANS_ID"]
        + list(GROUP_A_SEED.keys()) + ["GROUP_A_UPDATED_AT"]
        + list(GROUP_B_SEED.keys()) + ["GROUP_B_UPDATED_AT"]
        + ["FEATURE_UPDATED_AT", "LAST_SOURCE_EVENT_ID",
           "SNAPSHOT_AT", "REASON", "EVENT_ID", "CHANGED_FEATURE_GROUP",
           "VALID_TRANSACTION_FROM", "VALID_TRANSACTION_TO", "IS_CURRENT"]
    )
    values = (
        [SEED_POLICY_ID, SEED_CNTRCT_NUM, SEED_HH_NUM, SEED_TRANS_ID]
        + list(GROUP_A_SEED.values()) + [f"TIMESTAMP '{SEED_TS}'"]
        + list(GROUP_B_SEED.values()) + [f"TIMESTAMP '{SEED_TS}'"]
        + [f"TIMESTAMP '{SEED_TS}'", SEED_TRANS_ID,
           f"TIMESTAMP '{SEED_TS}'", "new_business_seed", SEED_TRANS_ID, "GROUP_A,GROUP_B",
           f"TIMESTAMP '{SEED_TS}'", "NULL", True]
    )

    def _fmt(v):
        if v == "NULL":
            return "NULL"
        if str(v).startswith("TIMESTAMP"):
            return v
        return _sql_literal(v)

    value_sql = ", ".join(_fmt(v) for v in values)

    spark.sql(f"""
        INSERT INTO {HISTORY} ({", ".join(columns)})
        VALUES ({value_sql})
    """)
    print(f"Seeded AUTO_FEATURES_HISTORY: {SEED_POLICY_ID} — IS_CURRENT=true")
else:
    print(f"AUTO_FEATURES_HISTORY already has {SEED_POLICY_ID} — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== AUTO_FEATURES_ACTIVE ===")
display(spark.table(ACTIVE))

print("=== AUTO_FEATURES_HISTORY ===")
display(spark.table(HISTORY))

print("\n>>> Next: Upload your transaction JSON to the incoming_json volume, then run 03_autoloader_landing_zone <<<")
