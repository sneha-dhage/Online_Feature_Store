# Databricks notebook source
# MAGIC %md
# MAGIC # 01 — Setup Tables
# MAGIC
# MAGIC | Table | Type | Role |
# MAGIC |---|---|---|
# MAGIC | `RAW_POLICY_EVENTS` | Bronze | Raw transaction JSON — append only, one row per transaction |
# MAGIC | `RAW_EVENTS_DLQ` | Bronze | Dead letter queue for malformed events |
# MAGIC | `COMPUTED_FEATURE_EVENTS` | Silver | PySpark-computed features with per-group effective dates |
# MAGIC | `AUTO_FEATURES_ACTIVE` | Feature Store | Live features — one row per policy |
# MAGIC | `AUTO_FEATURES_PENDING` | Feature Store | Future-dated GROUP_B features waiting for EFF_DT |
# MAGIC | `AUTO_FEATURES_HISTORY` | Feature Store | SCD Type 2 full-row snapshots |
# MAGIC | `FEATURE_GROUP_REGISTRY` | Feature Store | Registry — routing type per feature group |
# MAGIC
# MAGIC ## Key Design Decisions
# MAGIC
# MAGIC - Source is now **JSON, one file = one transaction snapshot** (vehicle / driver / coverage arrays), not XML with embedded history.
# MAGIC - `RAW_POLICY_EVENTS` is append-only Bronze — never updated, never deleted. History is reconstructed by reading all rows for a policy.
# MAGIC - Feature computation is **PySpark DataFrame ops** (explode / groupBy / window `lag()`), not a row-by-row SP.
# MAGIC - Two feature groups, unchanged routing mechanism via `FEATURE_GROUP_REGISTRY`:
# MAGIC   - `GROUP_A` (immediate) — driven by `SRC_TRANS_TMSP`. Drifts on wall-clock time even without new events (see `07_job_daily_group_a_refresh`).
# MAGIC   - `GROUP_B` (effective_date) — driven by `EFF_DT`. Future-dated rows wait in `AUTO_FEATURES_PENDING` until promoted (see `06_job_hourly_promotion`).
# MAGIC - `AUTO_POLICY_ID` = `plcy_id_sk` (unique per policy). `TRANS_ID` = `auto_plcy_trans_sk` (unique per transaction, replaces the old `HISTORY_ID`).
# MAGIC - `COMPUTED_FEATURE_EVENTS` and `AUTO_FEATURES_ACTIVE` have CDF enabled — routing pipeline / Lakebase sync read via CDF stream.
# MAGIC - `VALID_TRANSACTION_FROM` / `VALID_TRANSACTION_TO` use TIMESTAMP — minute precision, no overlap.

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "final_database")
dbutils.widgets.dropdown("reset", "false", ["false", "true"])

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")
RESET   = dbutils.widgets.get("reset") == "true"

# Bronze
RAW_EVENTS  = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
DLQ         = f"{CATALOG}.{SCHEMA}.RAW_EVENTS_DLQ"

# Silver
COMPUTED    = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"

# Feature Store
ACTIVE      = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
PENDING     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_PENDING"
HISTORY     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"
REGISTRY    = f"{CATALOG}.{SCHEMA}.FEATURE_GROUP_REGISTRY"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Feature Column Definitions
# MAGIC
# MAGIC Defined once here as SQL fragments and reused across every table so `ACTIVE`, `PENDING`,
# MAGIC `HISTORY` and `COMPUTED_FEATURE_EVENTS` never drift out of sync with each other.

# COMMAND ----------

# GROUP_A — immediate, driven by SRC_TRANS_TMSP. Recomputed daily regardless of new events.
GROUP_A_COLUMNS_DDL = """
    TXN_CNT_1D                   INT,
    TXN_CNT_1W                   INT,
    TXN_CNT_1M                   INT,
    OUTSTANDING_TXN_IND          INT,
    TENURE_YRS                   INT"""

GROUP_A_COLUMN_NAMES = [
    "TXN_CNT_1D", "TXN_CNT_1W", "TXN_CNT_1M",
    "OUTSTANDING_TXN_IND", "TENURE_YRS",
]

# GROUP_B — effective_date, driven by EFF_DT. Only group that can land in PENDING.
GROUP_B_COLUMNS_DDL = """
    VEH_CNT                      INT,
    AVG_VEH_AGE                  DOUBLE,
    VEH_ADDED_LATEST_TXN         INT,
    DRVR_CNT                     INT,
    MAX_DRVR_AGE                 INT,
    MIN_DRVR_AGE                 INT,
    AVG_DRVR_AGE                 DOUBLE,
    DRVRS_ADDED_LATEST_TXN       INT,
    PREM_CHANGE_AMT              DOUBLE,
    BI_COVERAGE_ADDED            INT,
    BI_COVERAGE_REMOVED          INT,
    PD_COVERAGE_ADDED            INT,
    PD_COVERAGE_REMOVED          INT,
    MD_COVERAGE_ADDED            INT,
    MD_COVERAGE_REMOVED          INT,
    COLL_COVERAGE_ADDED          INT,
    COLL_COVERAGE_REMOVED        INT,
    COMP_COVERAGE_ADDED          INT,
    COMP_COVERAGE_REMOVED        INT,
    PIP_COVERAGE_ADDED           INT,
    PIP_COVERAGE_REMOVED         INT,
    COMP_DED_CHANGE_IND          INT,
    GNDR_CHANGE_IND              INT,
    MRTL_CHANGE_IND              INT"""

GROUP_B_COLUMN_NAMES = [
    "VEH_CNT", "AVG_VEH_AGE", "VEH_ADDED_LATEST_TXN",
    "DRVR_CNT", "MAX_DRVR_AGE", "MIN_DRVR_AGE", "AVG_DRVR_AGE", "DRVRS_ADDED_LATEST_TXN",
    "PREM_CHANGE_AMT",
    "BI_COVERAGE_ADDED", "BI_COVERAGE_REMOVED",
    "PD_COVERAGE_ADDED", "PD_COVERAGE_REMOVED",
    "MD_COVERAGE_ADDED", "MD_COVERAGE_REMOVED",
    "COLL_COVERAGE_ADDED", "COLL_COVERAGE_REMOVED",
    "COMP_COVERAGE_ADDED", "COMP_COVERAGE_REMOVED",
    "PIP_COVERAGE_ADDED", "PIP_COVERAGE_REMOVED",
    "COMP_DED_CHANGE_IND", "GNDR_CHANGE_IND", "MRTL_CHANGE_IND",
]

print(f"GROUP_A: {len(GROUP_A_COLUMN_NAMES)} columns")
print(f"GROUP_B: {len(GROUP_B_COLUMN_NAMES)} columns")

# COMMAND ----------
# MAGIC %md
# MAGIC ## PRE-FLIGHT CHECKS
# MAGIC
# MAGIC Validates the environment before creating any tables.
# MAGIC All checks must pass (✅) before proceeding.
# MAGIC Any failure (❌) will raise an exception and stop the notebook.

# COMMAND ----------

import re

print("=" * 60)
print("  PRE-FLIGHT VALIDATION")
print("=" * 60)

errors   = []
warnings = []

# ── CHECK 1: Databricks Runtime Version ─────────────────────────
try:
    dbr_version = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion", "")
    if not dbr_version:
        dbr_version = spark.version  # fallback to Spark version
    major = int(re.search(r"(\d+)\.", dbr_version).group(1))
    if major >= 12:
        print(f"✅  CHECK 1 — Databricks Runtime : {dbr_version} (>= 12.0 required)")
    else:
        errors.append(f"DBR {dbr_version} is below 12.0. CDF and ARRAY<STRING> require DBR 12.0+.")
        print(f"❌  CHECK 1 — Databricks Runtime : {dbr_version} — UPGRADE REQUIRED (need >= 12.0)")
except Exception as e:
    warnings.append(f"Could not determine DBR version: {e}")
    print(f"⚠️   CHECK 1 — Databricks Runtime : Could not verify — proceeding with caution")

# ── CHECK 2: Unity Catalog Enabled ──────────────────────────────
try:
    spark.sql("SHOW CATALOGS").collect()
    print(f"✅  CHECK 2 — Unity Catalog       : Enabled")
except Exception as e:
    errors.append("Unity Catalog is not enabled. 3-level namespace (catalog.schema.table) will not work.")
    print(f"❌  CHECK 2 — Unity Catalog       : NOT ENABLED — required for {CATALOG}.{SCHEMA}.*")

# ── CHECK 3: Catalog Exists ──────────────────────────────────────
try:
    catalogs = [r[0] for r in spark.sql("SHOW CATALOGS").collect()]
    if CATALOG in catalogs:
        print(f"✅  CHECK 3 — Catalog '{CATALOG}'    : Exists")
    else:
        errors.append(f"Catalog '{CATALOG}' does not exist. Create it or change the catalog widget.")
        print(f"❌  CHECK 3 — Catalog '{CATALOG}'    : NOT FOUND")
        print(f"    Available catalogs: {catalogs}")
        print(f"    Fix: CREATE CATALOG {CATALOG};  OR change the catalog widget value.")
except Exception as e:
    errors.append(f"Could not check catalog: {e}")
    print(f"❌  CHECK 3 — Catalog check failed : {e}")

# ── CHECK 4: Schema Exists ───────────────────────────────────────
try:
    schemas = [r[0] for r in spark.sql(f"SHOW SCHEMAS IN {CATALOG}").collect()]
    if SCHEMA in schemas:
        print(f"✅  CHECK 4 — Schema '{SCHEMA}'     : Exists in {CATALOG}")
    else:
        errors.append(f"Schema '{SCHEMA}' does not exist in catalog '{CATALOG}'.")
        print(f"❌  CHECK 4 — Schema '{SCHEMA}'     : NOT FOUND in {CATALOG}")
        print(f"    Fix: CREATE SCHEMA {CATALOG}.{SCHEMA};  OR change the schema widget value.")
except Exception as e:
    errors.append(f"Could not check schema: {e}")
    print(f"❌  CHECK 4 — Schema check failed  : {e}")

# ── CHECK 5: Write Permission on Schema ──────────────────────────
try:
    _test_tbl = f"{CATALOG}.{SCHEMA}._preflight_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"CREATE TABLE IF NOT EXISTS {_test_tbl} (x INT) USING DELTA")
    spark.sql(f"DROP TABLE IF EXISTS {_test_tbl}")
    print(f"✅  CHECK 5 — Write Permission    : Can create/drop tables in {CATALOG}.{SCHEMA}")
except Exception as e:
    errors.append(f"No write permission on {CATALOG}.{SCHEMA}: {e}")
    print(f"❌  CHECK 5 — Write Permission    : FAILED — {e}")

# ── CHECK 6: CDF Supported ───────────────────────────────────────
try:
    _cdf_test = f"{CATALOG}.{SCHEMA}._cdf_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {_cdf_test} (x INT)
        USING DELTA
        TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
    """)
    spark.sql(f"DROP TABLE IF EXISTS {_cdf_test}")
    print(f"✅  CHECK 6 — CDF Support         : Change Data Feed supported")
except Exception as e:
    errors.append(f"CDF (Change Data Feed) not supported: {e}")
    print(f"❌  CHECK 6 — CDF Support         : FAILED — {e}")

# ── CHECK 7: Volume Support (for checkpoints) ────────────────────
try:
    spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}._preflight_vol_check")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}._preflight_vol_check")
    print(f"✅  CHECK 7 — Volume Support      : Can create Volumes in {CATALOG}.{SCHEMA}")
except Exception as e:
    warnings.append(f"Volume creation failed — checkpoint path may not work: {e}")
    print(f"⚠️   CHECK 7 — Volume Support      : WARNING — {e}")
    print(f"    Notebooks will still work but checkpoint path for streaming must be an existing path.")

# ── CHECK 8: Existing Tables (warn if RESET=false) ───────────────
try:
    existing_tables = [r[1] for r in spark.sql(f"SHOW TABLES IN {CATALOG}.{SCHEMA}").collect()]
    feature_tables  = ["RAW_POLICY_EVENTS","RAW_EVENTS_DLQ","COMPUTED_FEATURE_EVENTS",
                       "AUTO_FEATURES_ACTIVE","AUTO_FEATURES_PENDING",
                       "AUTO_FEATURES_HISTORY","FEATURE_GROUP_REGISTRY"]
    already_exist   = [t for t in feature_tables if t in existing_tables]
    if already_exist and not RESET:
        warnings.append(f"Tables already exist: {already_exist}. Using CREATE IF NOT EXISTS — no data will be lost. Set reset=true to drop and recreate.")
        print(f"⚠️   CHECK 8 — Existing Tables    : {len(already_exist)} table(s) already exist — will be skipped (reset=false)")
        for t in already_exist:
            print(f"    → {t}")
    elif already_exist and RESET:
        print(f"⚠️   CHECK 8 — Existing Tables    : {len(already_exist)} table(s) will be DROPPED (reset=true)")
        for t in already_exist:
            print(f"    → {t}")
    else:
        print(f"✅  CHECK 8 — Existing Tables    : No conflicts — fresh setup")
except Exception as e:
    warnings.append(f"Could not check existing tables: {e}")
    print(f"⚠️   CHECK 8 — Existing Tables    : Could not verify — {e}")

# ── SUMMARY ─────────────────────────────────────────────────────
print()
print("=" * 60)
if errors:
    print(f"  RESULT: ❌  {len(errors)} ERROR(S) — CANNOT PROCEED")
    print("=" * 60)
    for i, err in enumerate(errors, 1):
        print(f"  [{i}] {err}")
    print()
    raise Exception(
        f"Pre-flight failed with {len(errors)} error(s). "
        f"Fix the issues above before running this notebook."
    )
elif warnings:
    print(f"  RESULT: ⚠️   PASSED WITH {len(warnings)} WARNING(S) — proceeding")
    print("=" * 60)
    for i, w in enumerate(warnings, 1):
        print(f"  [{i}] {w}")
    print()
    print("  Proceeding to table creation...")
else:
    print("  RESULT: ✅  ALL CHECKS PASSED — proceeding")
    print("=" * 60)
    print()
    print("  Proceeding to table creation...")

# COMMAND ----------

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Using: {CATALOG}.{SCHEMA}")

if RESET:
    for tbl in [RAW_EVENTS, DLQ, COMPUTED, ACTIVE, PENDING, HISTORY, REGISTRY]:
        spark.sql(f"DROP TABLE IF EXISTS {tbl}")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}.checkpoints")
    print("All tables dropped — will recreate.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 0. Create Checkpoint Volume

# COMMAND ----------

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.checkpoints")
print(f"Volume ready: /Volumes/{CATALOG}/{SCHEMA}/checkpoints")

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.incoming_json")
print(f"Volume ready: /Volumes/{CATALOG}/{SCHEMA}/incoming_json  ← drop transaction JSON files here (Auto Loader landing zone)")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 1. RAW_POLICY_EVENTS (Bronze)
# MAGIC
# MAGIC Append-only. **One row per transaction JSON** (one JSON = one transaction snapshot,
# MAGIC not the full policy history). Malformed events go to `RAW_EVENTS_DLQ` instead.
# MAGIC
# MAGIC `RAW_PAYLOAD` stores the full JSON string exactly as received — no transformation.
# MAGIC `TRANS_ID`, `AUTO_POLICY_ID`, `EFF_DT`, `SRC_TRANS_TMSP` are extracted at ingestion so
# MAGIC downstream queries can filter/order without re-parsing JSON every time.
# MAGIC PySpark (05) parses `RAW_PAYLOAD` to explode the vehicle/driver/coverage arrays.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {RAW_EVENTS} (
    TRANS_ID                STRING    NOT NULL,
    AUTO_POLICY_ID           STRING    NOT NULL,
    PLCY_CNTRCT_NUM          STRING,
    SRC_HH_NUM               STRING,
    EFF_DT                   TIMESTAMP NOT NULL,
    SRC_TRANS_TMSP           TIMESTAMP NOT NULL,
    RAW_PAYLOAD               STRING    NOT NULL,
    INGESTED_AT               TIMESTAMP NOT NULL
)
USING DELTA
TBLPROPERTIES (
    'delta.appendOnly'           = 'true',
    'delta.enableChangeDataFeed' = 'true'
)
""")
print(f"Created: {RAW_EVENTS}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 2. RAW_EVENTS_DLQ (Dead Letter Queue)
# MAGIC
# MAGIC Catches malformed or unparseable transaction files.
# MAGIC Prevents bad events from stalling the pipeline.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DLQ} (
    RAW_PAYLOAD           STRING,
    ERROR_MESSAGE         STRING,
    FAILED_AT             TIMESTAMP NOT NULL,
    SOURCE_NAME           STRING
)
USING DELTA
""")
print(f"Created: {DLQ}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 3. COMPUTED_FEATURE_EVENTS (Silver)
# MAGIC
# MAGIC Written by PySpark (05) after computing GROUP_A / GROUP_B features from `RAW_POLICY_EVENTS`
# MAGIC history for the touched policy. CDF enabled — routing pipeline reads this via CDF stream.
# MAGIC
# MAGIC Key design: each feature group has its OWN effective date.
# MAGIC - `SRC_TRANS_TMSP` — drives GROUP_A (always immediate)
# MAGIC - `EFF_DT`         — drives GROUP_B (may be future-dated)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {COMPUTED} (
    TRANS_ID                 STRING    NOT NULL,
    AUTO_POLICY_ID            STRING    NOT NULL,
    PLCY_CNTRCT_NUM           STRING,
    SRC_HH_NUM                STRING,

    SRC_TRANS_TMSP            TIMESTAMP NOT NULL,
    EFF_DT                    TIMESTAMP NOT NULL,
    {GROUP_A_COLUMNS_DDL},
    {GROUP_B_COLUMNS_DDL},

    COMPUTED_AT                TIMESTAMP NOT NULL
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {COMPUTED}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 4. AUTO_FEATURES_ACTIVE (Feature Store)
# MAGIC
# MAGIC Live feature store — one row per policy.
# MAGIC CDF enabled for Lakebase / Online Store sync.
# MAGIC Each feature group has its own `_UPDATED_AT` timestamp
# MAGIC so you can tell exactly when each group was last refreshed.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {ACTIVE} (
    -- Identity
    AUTO_POLICY_ID                 STRING    NOT NULL,
    PLCY_CNTRCT_NUM                 STRING,
    SRC_HH_NUM                      STRING,
    TRANS_ID                        STRING,

    -- GROUP_A features (routing_type = immediate)
    {GROUP_A_COLUMNS_DDL},
    GROUP_A_UPDATED_AT              TIMESTAMP,

    -- GROUP_B features (routing_type = effective_date)
    {GROUP_B_COLUMNS_DDL},
    GROUP_B_UPDATED_AT              TIMESTAMP,

    -- Metadata
    FEATURE_UPDATED_AT              TIMESTAMP,
    LAST_SOURCE_EVENT_ID            STRING,

    CONSTRAINT AUTO_FEATURES_ACTIVE_PK PRIMARY KEY (AUTO_POLICY_ID)
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {ACTIVE}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 5. AUTO_FEATURES_PENDING (Feature Store)
# MAGIC
# MAGIC Future-dated GROUP_B features waiting for `EFF_DT` to arrive.
# MAGIC GROUP_A is always immediate — never goes to pending.
# MAGIC Promotion job (07) runs HOURLY — checks `EFFECTIVE_DATE <= current_timestamp()`.
# MAGIC GROUP_A drift (08) runs DAILY, independent of pending/promotion.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {PENDING} (
    -- Identity
    AUTO_POLICY_ID                 STRING    NOT NULL,
    TRANS_ID                        STRING,

    -- GROUP_B features only (only effective_date group lands here)
    {GROUP_B_COLUMNS_DDL},

    -- Scheduling
    EFFECTIVE_DATE                  TIMESTAMP NOT NULL,
    CHANGED_FEATURE_GROUP           STRING,
    SOURCE_EVENT_ID                 STRING,
    EVENT_RECEIVED_AT               TIMESTAMP
)
USING DELTA
""")
print(f"Created: {PENDING}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 6. AUTO_FEATURES_HISTORY (Feature Store)
# MAGIC
# MAGIC Full-row snapshots archived before every update (SCD Type 2).
# MAGIC
# MAGIC Validity window:
# MAGIC - `VALID_TRANSACTION_FROM` = effective date of the event that created this row (TIMESTAMP)
# MAGIC - `VALID_TRANSACTION_TO`   = effective date of the NEXT event minus 1 millisecond
# MAGIC - No overlap between consecutive rows for the same policy
# MAGIC - `IS_CURRENT = true`  → version currently in AUTO_FEATURES_ACTIVE
# MAGIC - `IS_CURRENT = false` → superseded historical version

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {HISTORY} (
    -- Identity
    AUTO_POLICY_ID                 STRING    NOT NULL,
    PLCY_CNTRCT_NUM                 STRING,
    SRC_HH_NUM                      STRING,
    TRANS_ID                        STRING,

    -- GROUP_A features
    {GROUP_A_COLUMNS_DDL},
    GROUP_A_UPDATED_AT              TIMESTAMP,

    -- GROUP_B features
    {GROUP_B_COLUMNS_DDL},
    GROUP_B_UPDATED_AT              TIMESTAMP,

    -- Metadata
    FEATURE_UPDATED_AT              TIMESTAMP,
    LAST_SOURCE_EVENT_ID            STRING,

    -- SCD Type 2 validity window (TIMESTAMP — minute precision)
    SNAPSHOT_AT                     TIMESTAMP NOT NULL,
    REASON                          STRING,
    EVENT_ID                        STRING,
    CHANGED_FEATURE_GROUP           STRING,
    VALID_TRANSACTION_FROM          TIMESTAMP NOT NULL,
    VALID_TRANSACTION_TO            TIMESTAMP,
    IS_CURRENT                      BOOLEAN   NOT NULL
)
USING DELTA
""")
print(f"Created: {HISTORY}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 7. FEATURE_GROUP_REGISTRY
# MAGIC
# MAGIC Controls routing at runtime — read fresh every micro-batch.
# MAGIC No code change needed to add or reroute a feature group.
# MAGIC
# MAGIC | ROUTING_TYPE | Behavior |
# MAGIC |---|---|
# MAGIC | immediate | Always MERGE to ACTIVE now — uses SRC_TRANS_TMSP |
# MAGIC | effective_date | Check EFF_DT: <= now → active, > now → pending |

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {REGISTRY} (
    FEATURE_GROUP        STRING        NOT NULL,
    OWNED_COLUMNS         ARRAY<STRING> NOT NULL,
    ROUTING_TYPE          STRING        NOT NULL,
    EFFECTIVE_DATE_COL     STRING        NOT NULL,
    DESCRIPTION            STRING,
    CONSTRAINT FEATURE_GROUP_REGISTRY_PK PRIMARY KEY (FEATURE_GROUP)
)
USING DELTA
""")

if spark.table(REGISTRY).limit(1).count() == 0:
    group_a_array = ", ".join(f"'{c}'" for c in GROUP_A_COLUMN_NAMES)
    group_b_array = ", ".join(f"'{c}'" for c in GROUP_B_COLUMN_NAMES)
    spark.sql(f"""
    INSERT INTO {REGISTRY} VALUES
    (
        'GROUP_A',
        ARRAY({group_a_array}),
        'immediate',
        'SRC_TRANS_TMSP',
        'Transaction-clock features (txn counts, tenure, outstanding flag) — always immediate, drift daily on wall-clock time.'
    ),
    (
        'GROUP_B',
        ARRAY({group_b_array}),
        'effective_date',
        'EFF_DT',
        'Policy-effective-date features (vehicle/driver/coverage snapshot + lag deltas) — respect EFF_DT, may be future-dated.'
    )
    """)
    print("Registry seeded with 2 feature groups.")

print(f"Created: {REGISTRY}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify All Tables

# COMMAND ----------

tables = [
    ("RAW_POLICY_EVENTS",       RAW_EVENTS),
    ("RAW_EVENTS_DLQ",          DLQ),
    ("COMPUTED_FEATURE_EVENTS", COMPUTED),
    ("AUTO_FEATURES_ACTIVE",    ACTIVE),
    ("AUTO_FEATURES_PENDING",   PENDING),
    ("AUTO_FEATURES_HISTORY",   HISTORY),
    ("FEATURE_GROUP_REGISTRY",  REGISTRY),
]

print("=== Table Row Counts ===")
for label, tbl in tables:
    print(f"  {label:30s}: {spark.table(tbl).count()} rows")

print("\n=== FEATURE_GROUP_REGISTRY ===")
display(spark.table(REGISTRY))
