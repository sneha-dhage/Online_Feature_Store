# Databricks notebook source
# MAGIC %md
# MAGIC # 05 — Routing Pipeline (Streaming from Landing Volume)
# MAGIC
# MAGIC Reads JSON event files dropped into the landing Volume by `03_sp_compute_features`
# MAGIC and routes them automatically via `cloudFiles` + `foreachBatch`.
# MAGIC
# MAGIC ## Routing rules
# MAGIC | `transaction_effective_date` | Action |
# MAGIC |---|---|
# MAGIC | > today | INSERT into `auto_features_pending` |
# MAGIC | <= today | MERGE into `auto_features_active` + snapshot to `auto_features_history` |
# MAGIC
# MAGIC ## Flow
# MAGIC ```
# MAGIC 03_sp_compute_features writes  →  /Volumes/main/model/landing/<history_id>.json
# MAGIC           ↓  cloudFiles detects new file automatically
# MAGIC 05_routing_pipeline foreachBatch
# MAGIC           ↓
# MAGIC   future-dated  → auto_features_pending
# MAGIC   past/today    → auto_features_active + auto_features_history
# MAGIC ```

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql import types as T

dbutils.widgets.text("catalog",         "main")
dbutils.widgets.text("schema",          "model")
dbutils.widgets.text("source_path",     "/Volumes/main/model/landing")
dbutils.widgets.text("checkpoint_path", "/Volumes/main/model/streaming")

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
SOURCE_PATH     = dbutils.widgets.get("source_path")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")

ACTIVE  = f"{CATALOG}.{SCHEMA}.auto_features_active"
PENDING = f"{CATALOG}.{SCHEMA}.auto_features_pending"
HISTORY = f"{CATALOG}.{SCHEMA}.auto_features_history"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Event schema
# MAGIC
# MAGIC Matches the JSON payload written by 03_sp_compute_features.

# COMMAND ----------

EVENT_SCHEMA = T.StructType([
    T.StructField("event_type",                       T.StringType(),  True),
    T.StructField("policy_number",                    T.StringType(),  True),
    T.StructField("history_id",                       T.StringType(),  True),
    T.StructField("transaction_effective_date",       T.StringType(),  True),
    T.StructField("no_of_drivers_insured",            T.IntegerType(), True),
    T.StructField("no_of_drivers_latest_transaction", T.IntegerType(), True),
    T.StructField("no_of_transaction_last_2_weeks",   T.IntegerType(), True),
    T.StructField("driver_change_last_transaction",   T.IntegerType(), True),
])

# COMMAND ----------
# MAGIC %md
# MAGIC ## Route A — Pending (future-dated)

# COMMAND ----------

def insert_to_pending(df):
    df.createOrReplaceTempView("_pending_events")
    spark.sql(f"""
        MERGE INTO {PENDING} AS t
        USING _pending_events AS s
        ON  t.auto_policy_id  = s.policy_number
        AND t.effective_date  = TO_DATE(s.transaction_effective_date)
        AND t.source_event_id = s.history_id
        WHEN MATCHED THEN UPDATE SET
            t.no_of_drivers_insured            = COALESCE(s.no_of_drivers_insured,            t.no_of_drivers_insured),
            t.no_of_drivers_latest_transaction = COALESCE(s.no_of_drivers_latest_transaction, t.no_of_drivers_latest_transaction),
            t.no_of_transaction_last_2_weeks   = COALESCE(s.no_of_transaction_last_2_weeks,   t.no_of_transaction_last_2_weeks),
            t.driver_change_last_transaction   = COALESCE(s.driver_change_last_transaction,   t.driver_change_last_transaction),
            t.event_received_at                = current_timestamp()
        WHEN NOT MATCHED THEN INSERT (
            auto_policy_id, policyholder_id,
            no_of_drivers_insured, no_of_drivers_latest_transaction,
            no_of_transaction_last_2_weeks, driver_change_last_transaction,
            effective_date, changed_feature_group,
            source_event_id, event_received_at
        ) VALUES (
            s.policy_number, NULL,
            s.no_of_drivers_insured, s.no_of_drivers_latest_transaction,
            s.no_of_transaction_last_2_weeks, s.driver_change_last_transaction,
            TO_DATE(s.transaction_effective_date), 'driver',
            s.history_id, current_timestamp()
        )
    """)
    print("  [PENDING] future-dated event parked in auto_features_pending.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Route B — Immediate (active + history)

# COMMAND ----------

def archive_and_merge_immediate(df):
    df.createOrReplaceTempView("_immediate_events")
    df.select(F.col("policy_number").alias("auto_policy_id")).distinct() \
      .createOrReplaceTempView("_immediate_policies")

    # Step 1: Close existing is_current = true history rows
    spark.sql(f"""
        MERGE INTO {HISTORY} AS h
        USING _immediate_policies AS p
        ON h.auto_policy_id = p.auto_policy_id AND h.is_current = true
        WHEN MATCHED THEN UPDATE SET
            h.is_current = false,
            h.valid_to   = current_timestamp()
    """)

    # Step 2: MERGE features into active
    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING _immediate_events AS s
        ON t.auto_policy_id = s.policy_number
        WHEN MATCHED THEN UPDATE SET
            t.no_of_drivers_insured            = COALESCE(s.no_of_drivers_insured,            t.no_of_drivers_insured),
            t.no_of_drivers_latest_transaction = COALESCE(s.no_of_drivers_latest_transaction, t.no_of_drivers_latest_transaction),
            t.no_of_transaction_last_2_weeks   = COALESCE(s.no_of_transaction_last_2_weeks,   t.no_of_transaction_last_2_weeks),
            t.driver_change_last_transaction   = COALESCE(s.driver_change_last_transaction,   t.driver_change_last_transaction),
            t.feature_updated_at               = current_timestamp(),
            t.last_source_event_id             = s.history_id
        WHEN NOT MATCHED THEN INSERT (
            auto_policy_id, policyholder_id,
            no_of_drivers_insured, no_of_drivers_latest_transaction,
            no_of_transaction_last_2_weeks, driver_change_last_transaction,
            feature_updated_at, last_source_event_id
        ) VALUES (
            s.policy_number, NULL,
            s.no_of_drivers_insured, s.no_of_drivers_latest_transaction,
            s.no_of_transaction_last_2_weeks, s.driver_change_last_transaction,
            current_timestamp(), s.history_id
        )
    """)

    # Step 3: Snapshot updated active → history as is_current = true
    spark.sql(f"""
        INSERT INTO {HISTORY}
        SELECT
            a.auto_policy_id, a.policyholder_id,
            a.no_of_drivers_insured, a.no_of_drivers_latest_transaction,
            a.no_of_transaction_last_2_weeks, a.driver_change_last_transaction,
            a.feature_updated_at, a.last_source_event_id,
            current_timestamp()        AS snapshot_at,
            'immediate_merge'          AS reason,
            a.last_source_event_id     AS event_id,
            'driver'                   AS changed_feature_group,
            current_timestamp()        AS valid_from,
            NULL                       AS valid_to,
            true                       AS is_current
        FROM {ACTIVE} a
        INNER JOIN _immediate_policies p ON a.auto_policy_id = p.auto_policy_id
    """)
    print("  [IMMEDIATE] merged to active + snapshotted to history.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## foreachBatch

# COMMAND ----------

def process_micro_batch(df, batch_id):
    import traceback
    try:
        count = df.count()
        print(f"\n[batch {batch_id}] {count} event(s) from landing volume")
        if count == 0:
            return

        # Cast transaction_effective_date string → DateType
        df = df.withColumn("effective_date",
                           F.to_date(F.col("transaction_effective_date"), "yyyy-MM-dd"))

        today = spark.sql("SELECT current_date()").first()[0]

        future_df    = df.filter(F.col("effective_date") > F.lit(today))
        immediate_df = df.filter(F.col("effective_date") <= F.lit(today))

        f_count = future_df.count()
        i_count = immediate_df.count()

        print(f"  event(s) routing → PENDING   : {f_count}  (effective_date > {today})")
        print(f"  event(s) routing → IMMEDIATE : {i_count}  (effective_date <= {today})")

        if f_count > 0:
            insert_to_pending(future_df)

        if i_count > 0:
            archive_and_merge_immediate(immediate_df)

        print(f"[batch {batch_id}] done.")

    except Exception as e:
        print(f"[ERROR] batch {batch_id}: {e}")
        traceback.print_exc()
        raise

# COMMAND ----------
# MAGIC %md
# MAGIC ## Start streaming
# MAGIC
# MAGIC Picks up any JSON file dropped into `/Volumes/main/model/landing/` automatically.
# MAGIC Run 03_sp_compute_features first — it writes the event file to that path.

# COMMAND ----------

query = (
    spark.readStream
         .format("cloudFiles")
         .option("cloudFiles.format", "json")
         .option("cloudFiles.inferColumnTypes", "false")
         .schema(EVENT_SCHEMA)
         .load(SOURCE_PATH)
         .writeStream
         .foreachBatch(process_micro_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nStream finished. Verify tables below.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== auto_features_active ===")
display(spark.table(ACTIVE).orderBy("auto_policy_id"))

print("=== auto_features_pending (future-dated) ===")
display(spark.table(PENDING).orderBy("effective_date"))

print("=== auto_features_history ===")
display(spark.table(HISTORY).orderBy("auto_policy_id", "valid_from"))
