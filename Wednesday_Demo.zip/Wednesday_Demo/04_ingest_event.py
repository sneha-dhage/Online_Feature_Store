# Databricks notebook source
# MAGIC %md
# MAGIC # 04 — Ingest Event
# MAGIC
# MAGIC Simple INSERT statements for HIST-002 (Endorsement for POL-1234).
# MAGIC
# MAGIC **What's being inserted:**
# MAGIC - policy_history : HIST-002, Endorsement, transaction_date=2026-06-22, effective_date=2026-06-25
# MAGIC - policy_drivers : 5 rows — 2 new drivers (Sush, Sneha) + 3 carried forward (Bob deleted, Alicia & Todd kept)
# MAGIC - policy_vehicles: no change (same vehicles as HIST-001)
# MAGIC
# MAGIC After running, copy the printed `history_id` into **03_sp_compute_features** widget.

# COMMAND ----------

CATALOG = "main"
SCHEMA  = "model"

POLICY_HISTORY  = f"{CATALOG}.{SCHEMA}.policy_history"
POLICY_DRIVERS  = f"{CATALOG}.{SCHEMA}.policy_drivers"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Insert into policy_history

# COMMAND ----------

spark.sql(f"""
INSERT INTO {POLICY_HISTORY}
(history_id, policy_number, quote_id, transaction_type,
 transaction_date, effective_date, policy_effective_date, state)
VALUES
('HIST-002', 'POL-1234', 'QUOTE-001', 'Endorsement',
 DATE '2026-06-22', DATE '2026-06-29', DATE '2026-06-21', 'inforce')
""")

print("Inserted HIST-002 into policy_history.")
print("history_id : HIST-002")
print("effective_date : 2026-06-25  (future → will route to PENDING)")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Insert into policy_drivers
# MAGIC
# MAGIC Columns: history_id, policy_number, driver_id, is_deleted, driver_name, driver_age,
# MAGIC          transaction_date, transaction_effective_date, transaction_type
# MAGIC
# MAGIC | Driver | is_deleted | Note |
# MAGIC |---|---|---|
# MAGIC | DRV-Sush | 0 | New driver added |
# MAGIC | DRV-Sneha | 0 | New driver added |
# MAGIC | DRV-BOB | 1 | Removed on this endorsement |
# MAGIC | DRV-ALICIA | 0 | Carried forward |
# MAGIC | DRV-TODD | 0 | Carried forward |
# MAGIC
# MAGIC Active drivers after this endorsement (is_deleted=0): Sush, Sneha, Alicia, Todd = **4**

# COMMAND ----------

spark.sql(f"""
INSERT INTO {POLICY_DRIVERS}
(history_id, policy_number, driver_id, is_deleted, driver_name, driver_age,
 transaction_date, transaction_effective_date, transaction_type)
VALUES
('HIST-002', 'POL-1234', 'DRV-SUSH',   0, 'Sush',   28, DATE '2026-06-22', DATE '2026-06-29', 'Endorsement'),
('HIST-002', 'POL-1234', 'DRV-SNEHA',  0, 'Sneha',  35, DATE '2026-06-22', DATE '2026-06-29', 'Endorsement'),
('HIST-002', 'POL-1234', 'DRV-BOB',    1, 'Bob',    35, DATE '2026-06-22', DATE '2026-06-29', 'Endorsement'),
('HIST-002', 'POL-1234', 'DRV-ALICIA', 0, 'Alicia', 28, DATE '2026-06-22', DATE '2026-06-29', 'Endorsement'),
('HIST-002', 'POL-1234', 'DRV-TODD',   0, 'Todd',   42, DATE '2026-06-22', DATE '2026-06-29', 'Endorsement')
""")

print("Inserted 5 driver rows for HIST-002.")
print("  is_deleted=0 count: 4  (Sush, Sneha, Alicia, Todd)")
print("  is_deleted=1 count: 1  (Bob — removed)")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

from pyspark.sql import functions as F

print("=== policy_history ===")
display(spark.table(POLICY_HISTORY).orderBy("transaction_date"))

print("=== policy_drivers for HIST-002 ===")
display(
    spark.table(f"{CATALOG}.{SCHEMA}.policy_drivers")
         .filter(F.col("history_id") == "HIST-002")
         .orderBy("is_deleted", "driver_name")
)

print("\n>>> Next: set history_id = HIST-002 in 03_sp_compute_features and run it <<<")
