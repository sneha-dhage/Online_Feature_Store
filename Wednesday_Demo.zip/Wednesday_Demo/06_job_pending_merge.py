# Databricks notebook source
# MAGIC %md
# MAGIC # 06 — Job: Daily Pending Merge
# MAGIC
# MAGIC Runs at midnight. Promotes pending rows whose `effective_date` has arrived.
# MAGIC
# MAGIC **Steps per due policy:**
# MAGIC 1. Close existing `is_current = true` history row (valid_to = now, is_current = false)
# MAGIC 2. MERGE features into `auto_features_active`
# MAGIC 3. Snapshot updated active → `auto_features_history` (is_current = true)
# MAGIC 4. DELETE processed rows from `auto_features_pending`
# MAGIC
# MAGIC Leave `run_date` blank in production (uses current_date).
# MAGIC Set e.g. `2026-06-25` to simulate a future date in testing.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from datetime import datetime

dbutils.widgets.text("catalog",  "main")
dbutils.widgets.text("schema",   "model")
dbutils.widgets.text("run_date", "")   # format: YYYY-MM-DD  e.g. 2026-06-25

CATALOG     = dbutils.widgets.get("catalog")
SCHEMA      = dbutils.widgets.get("schema")
_date_input = dbutils.widgets.get("run_date").strip()

if _date_input:
    # Accept YYYY-MM-DD, MM-DD-YYYY, MM/DD/YYYY
    for fmt in ("%Y-%m-%d", "%m-%d-%Y", "%m/%d/%Y"):
        try:
            today = datetime.strptime(_date_input, fmt).strftime("%Y-%m-%d")
            break
        except ValueError:
            continue
    else:
        raise ValueError(f"Cannot parse run_date '{_date_input}'. Use format YYYY-MM-DD (e.g. 2026-06-25).")
else:
    today = str(spark.sql("SELECT current_date()").first()[0])

print(f"Run date: {today}")

ACTIVE  = f"{CATALOG}.{SCHEMA}.auto_features_active"
PENDING = f"{CATALOG}.{SCHEMA}.auto_features_pending"
HISTORY = f"{CATALOG}.{SCHEMA}.auto_features_history"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Apply due pending changes

# COMMAND ----------

def apply_due_pending_changes():
    due_df = spark.sql(f"""
        SELECT * FROM {PENDING}
        WHERE effective_date <= '{today}'
    """)

    if due_df.limit(1).count() == 0:
        print(f"No pending changes due on or before {today}. Nothing to do.")
        return

    # If same policy has multiple pending rows due today, pick the latest per policy
    deduped = (
        due_df
        .withColumn("_rn", F.row_number().over(
            Window.partitionBy("auto_policy_id")
                  .orderBy(F.col("effective_date").desc(),
                           F.col("event_received_at").desc())
        ))
        .filter("_rn = 1")
        .drop("_rn")
    )

    count = deduped.count()
    print(f"Applying {count} pending row(s) with effective_date <= {today}.")

    deduped.createOrReplaceTempView("_due_pending")
    deduped.select("auto_policy_id").distinct() \
           .createOrReplaceTempView("_due_policies")

    # Step 1 — Close existing is_current = true history rows
    spark.sql(f"""
        MERGE INTO {HISTORY} AS h
        USING _due_policies AS p
        ON h.auto_policy_id = p.auto_policy_id AND h.is_current = true
        WHEN MATCHED THEN UPDATE SET
            h.is_current = false,
            h.valid_to   = current_timestamp()
    """)
    print("  Step 1: closed is_current history rows.")

    # Step 2 — MERGE features into active
    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING _due_pending AS s
        ON t.auto_policy_id = s.auto_policy_id
        WHEN MATCHED THEN UPDATE SET
            t.no_of_drivers_insured            = COALESCE(s.no_of_drivers_insured,            t.no_of_drivers_insured),
            t.no_of_drivers_latest_transaction = COALESCE(s.no_of_drivers_latest_transaction, t.no_of_drivers_latest_transaction),
            t.no_of_transaction_last_2_weeks   = COALESCE(s.no_of_transaction_last_2_weeks,   t.no_of_transaction_last_2_weeks),
            t.driver_change_last_transaction   = COALESCE(s.driver_change_last_transaction,   t.driver_change_last_transaction),
            t.feature_updated_at               = current_timestamp(),
            t.last_source_event_id             = s.source_event_id
        WHEN NOT MATCHED THEN INSERT (
            auto_policy_id, policyholder_id,
            no_of_drivers_insured, no_of_drivers_latest_transaction,
            no_of_transaction_last_2_weeks, driver_change_last_transaction,
            feature_updated_at, last_source_event_id
        ) VALUES (
            s.auto_policy_id, s.policyholder_id,
            s.no_of_drivers_insured, s.no_of_drivers_latest_transaction,
            s.no_of_transaction_last_2_weeks, s.driver_change_last_transaction,
            current_timestamp(), s.source_event_id
        )
    """)
    print("  Step 2: merged features into auto_features_active.")

    # Step 3 — Snapshot active → history as is_current = true
    spark.sql(f"""
        INSERT INTO {HISTORY}
        SELECT
            a.auto_policy_id, a.policyholder_id,
            a.no_of_drivers_insured, a.no_of_drivers_latest_transaction,
            a.no_of_transaction_last_2_weeks, a.driver_change_last_transaction,
            a.feature_updated_at, a.last_source_event_id,
            current_timestamp()                             AS snapshot_at,
            CONCAT('pending_applied:', p.source_event_id)  AS reason,
            p.source_event_id                              AS event_id,
            'driver'                                       AS changed_feature_group,
            current_timestamp()                            AS valid_from,
            NULL                                           AS valid_to,
            true                                           AS is_current
        FROM {ACTIVE} a
        INNER JOIN _due_pending p ON a.auto_policy_id = p.auto_policy_id
    """)
    print("  Step 3: snapshotted to auto_features_history (is_current=true).")

    # Step 4 — Delete promoted pending rows
    spark.sql(f"""
        DELETE FROM {PENDING}
        WHERE effective_date <= '{today}'
    """)
    print(f"  Step 4: deleted {count} row(s) from auto_features_pending.")
    print(f"\nDone. {count} pending row(s) promoted.")


apply_due_pending_changes()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== auto_features_active ===")
display(spark.table(ACTIVE).orderBy("auto_policy_id"))

print("=== auto_features_pending (remaining) ===")
display(spark.table(PENDING).orderBy("effective_date"))

print("=== auto_features_history (all snapshots) ===")
display(spark.table(HISTORY).orderBy("auto_policy_id", "valid_from"))
