# Databricks notebook source
# MAGIC %md
# MAGIC # 01 — Setup All Tables
# MAGIC
# MAGIC | Table | Type | Role |
# MAGIC |---|---|---|
# MAGIC | `policy_history` | Raw | One row per transaction |
# MAGIC | `policy_vehicles` | Raw | One row per vehicle per transaction |
# MAGIC | `policy_drivers` | Raw | One row per driver per transaction (is_deleted flag) |
# MAGIC | `auto_features_active` | Feature Store | Live features — one row per policy |
# MAGIC | `auto_features_pending` | Feature Store | Future-dated events waiting for effective_date |
# MAGIC | `auto_features_history` | Feature Store | SCD Type 2 full-row snapshots |

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "model")
dbutils.widgets.dropdown("reset", "false", ["false", "true"])

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")
RESET   = dbutils.widgets.get("reset") == "true"

POLICY_HISTORY  = f"{CATALOG}.{SCHEMA}.policy_history"
POLICY_VEHICLES = f"{CATALOG}.{SCHEMA}.policy_vehicles"
POLICY_DRIVERS  = f"{CATALOG}.{SCHEMA}.policy_drivers"
ACTIVE          = f"{CATALOG}.{SCHEMA}.auto_features_active"
PENDING         = f"{CATALOG}.{SCHEMA}.auto_features_pending"
HISTORY         = f"{CATALOG}.{SCHEMA}.auto_features_history"

# COMMAND ----------

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Using: {CATALOG}.{SCHEMA}")

if RESET:
    for tbl in [POLICY_VEHICLES, POLICY_DRIVERS, POLICY_HISTORY, ACTIVE, PENDING, HISTORY]:
        spark.sql(f"DROP TABLE IF EXISTS {tbl}")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}.landing")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}.streaming")
    print("All tables and volumes dropped — will recreate.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 0. Create Volumes
# MAGIC
# MAGIC - `landing`  : JSON event files written by 03_sp_compute_features → picked up by 05_routing_pipeline
# MAGIC - `streaming`: checkpoint for 05_routing_pipeline CDF stream

# COMMAND ----------

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.landing")
spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.streaming")
print(f"Volumes ready:")
print(f"  /Volumes/{CATALOG}/{SCHEMA}/landing   ← SP writes JSON events here")
print(f"  /Volumes/{CATALOG}/{SCHEMA}/streaming ← streaming checkpoint")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 1. policy_history

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {POLICY_HISTORY} (
    history_id            STRING NOT NULL,
    policy_number         STRING NOT NULL,
    quote_id              STRING,
    transaction_type      STRING NOT NULL,
    transaction_date      DATE   NOT NULL,
    effective_date        DATE   NOT NULL,
    policy_effective_date DATE,
    state                 STRING,
    CONSTRAINT policy_history_pk PRIMARY KEY (history_id)
)
USING DELTA
""")
print(f"Created: {POLICY_HISTORY}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 2. policy_vehicles

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {POLICY_VEHICLES} (
    history_id       STRING NOT NULL,
    policy_number    STRING NOT NULL,
    vehicle_id       STRING NOT NULL,
    make             STRING,
    model            STRING,
    year             INT,
    transaction_date DATE   NOT NULL,
    effective_date   DATE   NOT NULL,
    transaction_type STRING
)
USING DELTA
""")
print(f"Created: {POLICY_VEHICLES}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 3. policy_drivers
# MAGIC
# MAGIC `is_deleted = 1` means driver was removed on this transaction.
# MAGIC `transaction_effective_date` = date the change takes effect on the policy.
# MAGIC Feature calculation uses only rows where `is_deleted = 0`.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {POLICY_DRIVERS} (
    history_id                 STRING NOT NULL,
    policy_number              STRING NOT NULL,
    driver_id                  STRING NOT NULL,
    is_deleted                 INT    NOT NULL,
    driver_name                STRING,
    driver_age                 INT,
    transaction_date           DATE   NOT NULL,
    transaction_effective_date DATE   NOT NULL,
    transaction_type           STRING
)
USING DELTA
""")
print(f"Created: {POLICY_DRIVERS}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 4. auto_features_active

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {ACTIVE} (
    auto_policy_id                   STRING    NOT NULL,
    policyholder_id                  STRING,
    no_of_drivers_insured            INT,
    no_of_drivers_latest_transaction INT,
    no_of_transaction_last_2_weeks   INT,
    driver_change_last_transaction   INT,
    feature_updated_at               TIMESTAMP,
    last_source_event_id             STRING,
    CONSTRAINT auto_features_active_pk PRIMARY KEY (auto_policy_id)
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {ACTIVE}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 5. auto_features_pending

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {PENDING} (
    auto_policy_id                   STRING    NOT NULL,
    policyholder_id                  STRING,
    no_of_drivers_insured            INT,
    no_of_drivers_latest_transaction INT,
    no_of_transaction_last_2_weeks   INT,
    driver_change_last_transaction   INT,
    effective_date                   DATE      NOT NULL,
    changed_feature_group            STRING,
    source_event_id                  STRING,
    event_received_at                TIMESTAMP
)
USING DELTA
""")
print(f"Created: {PENDING}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## 6. auto_features_history

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {HISTORY} (
    auto_policy_id                   STRING    NOT NULL,
    policyholder_id                  STRING,
    no_of_drivers_insured            INT,
    no_of_drivers_latest_transaction INT,
    no_of_transaction_last_2_weeks   INT,
    driver_change_last_transaction   INT,
    feature_updated_at               TIMESTAMP,
    last_source_event_id             STRING,
    snapshot_at                      TIMESTAMP NOT NULL,
    reason                           STRING,
    event_id                         STRING,
    changed_feature_group            STRING,
    valid_from                       TIMESTAMP NOT NULL,
    valid_to                         TIMESTAMP,
    is_current                       BOOLEAN   NOT NULL
)
USING DELTA
""")
print(f"Created: {HISTORY}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

for label, tbl in [
    ("policy_history",        POLICY_HISTORY),
    ("policy_vehicles",       POLICY_VEHICLES),
    ("policy_drivers",        POLICY_DRIVERS),
    ("auto_features_active",  ACTIVE),
    ("auto_features_pending", PENDING),
    ("auto_features_history", HISTORY),
]:
    print(f"{label:30s}: {spark.table(tbl).count()} rows")
