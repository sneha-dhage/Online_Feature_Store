# Databricks notebook source
# MAGIC %md
# MAGIC # 03 — SP: Compute Features + Output JSON
# MAGIC
# MAGIC Automatically picks the latest `history_id` from `policy_history` and computes
# MAGIC the 4 driver features. No hardcoded values.
# MAGIC
# MAGIC **Run after 04_ingest_event.**
# MAGIC
# MAGIC ## Feature logic
# MAGIC | Feature | Source | Logic |
# MAGIC |---|---|---|
# MAGIC | `no_of_drivers_insured` | policy_drivers | Count `is_deleted=0` on the latest txn where **effective_date <= today** |
# MAGIC | `no_of_drivers_latest_transaction` | policy_drivers | Count `is_deleted=0` on the latest txn by **transaction_date** |
# MAGIC | `no_of_transaction_last_2_weeks` | policy_history | Count distinct history rows with transaction_date in last 14 days |
# MAGIC | `driver_change_last_transaction` | policy_drivers | `is_deleted=0` count on latest txn minus count on previous txn |

# COMMAND ----------

import json

dbutils.widgets.text("catalog",       "main")
dbutils.widgets.text("schema",        "model")
dbutils.widgets.text("policy_number", "POL-1234")

CATALOG       = dbutils.widgets.get("catalog")
SCHEMA        = dbutils.widgets.get("schema")
POLICY_NUMBER = dbutils.widgets.get("policy_number").strip()

if not POLICY_NUMBER:
    raise ValueError("Set the 'policy_number' widget before running.")

POLICY_HISTORY  = f"{CATALOG}.{SCHEMA}.policy_history"
POLICY_VEHICLES = f"{CATALOG}.{SCHEMA}.policy_vehicles"
POLICY_DRIVERS  = f"{CATALOG}.{SCHEMA}.policy_drivers"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Review all raw tables

# COMMAND ----------

print("=== policy_history ===")
display(spark.table(POLICY_HISTORY).orderBy("transaction_date"))

print("=== policy_vehicles ===")
display(spark.table(POLICY_VEHICLES).orderBy("history_id"))

print("=== policy_drivers ===")
display(spark.table(POLICY_DRIVERS).orderBy("history_id", "is_deleted", "driver_name"))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Pick latest history_id from policy_history

# COMMAND ----------

latest = spark.sql(f"""
    SELECT history_id, policy_number, transaction_date, effective_date, transaction_type
    FROM {POLICY_HISTORY}
    WHERE policy_number = '{POLICY_NUMBER}'
    ORDER BY transaction_date DESC, history_id DESC
    LIMIT 1
""").first()

if latest is None:
    raise ValueError(f"No rows found in {POLICY_HISTORY}. Run 04_ingest_event first.")

HISTORY_ID     = latest["history_id"]
TXN_DATE       = str(latest["transaction_date"])
EFFECTIVE_DATE = str(latest["effective_date"])
TXN_TYPE       = latest["transaction_type"]

print(f"Latest history_id : {HISTORY_ID}")
print(f"policy_number     : {POLICY_NUMBER}")
print(f"transaction_date  : {TXN_DATE}")
print(f"effective_date    : {EFFECTIVE_DATE}")
print(f"transaction_type  : {TXN_TYPE}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 3 — Compute 4 features
# MAGIC
# MAGIC Driver counts filter `is_deleted = 0` and group by `history_id`.

# COMMAND ----------

today = spark.sql("SELECT current_date()").first()[0]

features_row = spark.sql(f"""
WITH
all_txns AS (
    SELECT
        h.history_id,
        h.transaction_date,
        h.effective_date,
        COUNT(d.driver_id) AS driver_count
    FROM {POLICY_HISTORY} h
    LEFT JOIN {POLICY_DRIVERS} d
        ON d.history_id = h.history_id
       AND d.is_deleted = 0
    WHERE h.policy_number = '{POLICY_NUMBER}'
    GROUP BY h.history_id, h.transaction_date, h.effective_date
),
latest_by_txn_date AS (
    SELECT * FROM all_txns
    WHERE transaction_date <= DATE '{today}'
    ORDER BY transaction_date DESC, history_id DESC
    LIMIT 1
),
previous_by_txn_date AS (
    SELECT t.* FROM all_txns t
    WHERE t.transaction_date <= DATE '{today}'
      AND t.history_id != (SELECT history_id FROM latest_by_txn_date)
    ORDER BY t.transaction_date DESC, t.history_id DESC
    LIMIT 1
),
latest_by_effective_date AS (
    -- uses EFFECTIVE_DATE of this transaction, not today
    -- so the event reflects the state when the change actually takes effect
    SELECT * FROM all_txns
    WHERE effective_date <= DATE '{EFFECTIVE_DATE}'
    ORDER BY effective_date DESC, transaction_date DESC, history_id DESC
    LIMIT 1
),
txns_last_2_weeks AS (
    SELECT COUNT(*) AS cnt
    FROM {POLICY_HISTORY}
    WHERE policy_number = '{POLICY_NUMBER}'
      AND transaction_date > DATE '{today}' - INTERVAL 14 DAYS
      AND transaction_date <= DATE '{today}'
),
total_in_latest AS (
    -- all driver rows in the latest transaction (is_deleted 0 and 1)
    SELECT COUNT(*) AS cnt
    FROM {POLICY_DRIVERS}
    WHERE history_id = (SELECT history_id FROM latest_by_txn_date)
),
unchanged_drivers AS (
    -- drivers who exist in both latest and previous txn and are NOT deleted in latest
    -- these are the ones that did NOT change
    SELECT COUNT(*) AS cnt
    FROM {POLICY_DRIVERS} cur
    INNER JOIN {POLICY_DRIVERS} prev
        ON  cur.driver_id   = prev.driver_id
        AND prev.history_id = (SELECT history_id FROM previous_by_txn_date)
        AND prev.is_deleted = 0
    WHERE cur.history_id  = (SELECT history_id FROM latest_by_txn_date)
      AND cur.is_deleted  = 0
)
SELECT
    COALESCE((SELECT driver_count FROM latest_by_effective_date), 0) AS no_of_drivers_insured,
    COALESCE((SELECT driver_count FROM latest_by_txn_date),       0) AS no_of_drivers_latest_transaction,
    COALESCE((SELECT cnt           FROM txns_last_2_weeks),        0) AS no_of_transaction_last_2_weeks,
    -- total rows in latest txn minus unchanged = additions + deletions = true change count
    COALESCE((SELECT cnt FROM total_in_latest),    0)
    - COALESCE((SELECT cnt FROM unchanged_drivers), 0)               AS driver_change_last_transaction
""").first()

v1 = features_row["no_of_drivers_insured"]
v2 = features_row["no_of_drivers_latest_transaction"]
v3 = features_row["no_of_transaction_last_2_weeks"]
v4 = features_row["driver_change_last_transaction"]

print(f"\nComputed features as of {today}:")
print(f"  no_of_drivers_insured            : {v1}")
print(f"  no_of_drivers_latest_transaction : {v2}")
print(f"  no_of_transaction_last_2_weeks   : {v3}")
print(f"  driver_change_last_transaction   : {v4}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 4 — JSON Payload Output

# COMMAND ----------

payload = {
    "event_type":                        "vehicle_event",
    "policy_number":                     POLICY_NUMBER,
    "history_id":                        HISTORY_ID,
    "transaction_effective_date":        EFFECTIVE_DATE,
    "no_of_drivers_insured":             v1,
    "no_of_drivers_latest_transaction":  v2,
    "no_of_transaction_last_2_weeks":    v3,
    "driver_change_last_transaction":    v4
}

print("\n=== Event JSON (Dynamic Payload) ===")
print(json.dumps(payload, indent=2))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 5 — Write JSON to landing Volume
# MAGIC
# MAGIC 05_routing_pipeline picks this file up automatically via cloudFiles stream.

# COMMAND ----------

landing_path = f"/Volumes/{CATALOG}/{SCHEMA}/landing"
file_path    = f"{landing_path}/{HISTORY_ID}.json"

dbutils.fs.put(file_path, json.dumps(payload), overwrite=True)
print(f"\nWritten to landing: {file_path}")
print(">>> Now run 05_routing_pipeline — it will pick up this file automatically <<<")
