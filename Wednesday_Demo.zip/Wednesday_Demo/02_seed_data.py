# Databricks notebook source
# MAGIC %md
# MAGIC # 02 — Seed Data
# MAGIC
# MAGIC Inserts initial **new business** event HIST-001 for POL-1234:
# MAGIC
# MAGIC | Table | Data |
# MAGIC |---|---|
# MAGIC | policy_history | HIST-001, new business, 2026-06-21, state=inforce |
# MAGIC | policy_vehicles | VEH-XYZ (Toyota Camry 2020), VEH-ABC (Honda Civic 2019) |
# MAGIC | policy_drivers | Bob (35), Alicia (28), Todd (42) — all is_deleted=0 |
# MAGIC | auto_features_active | POL-1234 → (3, 3, 1, 3) |
# MAGIC | auto_features_history | POL-1234 → (3, 3, 1, 3) is_current=true |

# COMMAND ----------

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "model")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

POLICY_HISTORY  = f"{CATALOG}.{SCHEMA}.policy_history"
POLICY_VEHICLES = f"{CATALOG}.{SCHEMA}.policy_vehicles"
POLICY_DRIVERS  = f"{CATALOG}.{SCHEMA}.policy_drivers"
ACTIVE          = f"{CATALOG}.{SCHEMA}.auto_features_active"
HISTORY         = f"{CATALOG}.{SCHEMA}.auto_features_history"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Raw tables — HIST-001 (new business)

# COMMAND ----------

if spark.table(POLICY_HISTORY).limit(1).count() == 0:

    spark.sql(f"""
    INSERT INTO {POLICY_HISTORY} VALUES
    ('HIST-001', 'POL-1234', 'QUOTE-001', 'new business',
     DATE '2026-06-21', DATE '2026-06-21', DATE '2026-06-21', 'inforce')
    """)
    print("Inserted HIST-001 into policy_history.")

    spark.sql(f"""
    INSERT INTO {POLICY_VEHICLES} VALUES
    ('HIST-001', 'POL-1234', 'VEH-XYZ', 'Toyota', 'Camry', 2020,
     DATE '2026-06-21', DATE '2026-06-21', 'new business'),
    ('HIST-001', 'POL-1234', 'VEH-ABC', 'Honda',  'Civic', 2019,
     DATE '2026-06-21', DATE '2026-06-21', 'new business')
    """)
    print("Inserted 2 vehicles into policy_vehicles.")

    # columns: history_id, policy_number, driver_id, is_deleted, driver_name, driver_age,
    #          transaction_date, transaction_effective_date, transaction_type
    spark.sql(f"""
    INSERT INTO {POLICY_DRIVERS} VALUES
    ('HIST-001', 'POL-1234', 'DRV-BOB',    0, 'Bob',    35, DATE '2026-06-21', DATE '2026-06-21', 'new business'),
    ('HIST-001', 'POL-1234', 'DRV-ALICIA', 0, 'Alicia', 28, DATE '2026-06-21', DATE '2026-06-21', 'new business'),
    ('HIST-001', 'POL-1234', 'DRV-TODD',   0, 'Todd',   42, DATE '2026-06-21', DATE '2026-06-21', 'new business')
    """)
    print("Inserted 3 drivers into policy_drivers (is_deleted=0).")

else:
    print("policy_history already has data — skipping raw seed.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Feature tables — seed with HIST-001 values
# MAGIC
# MAGIC | Feature | Value | Logic |
# MAGIC |---|---|---|
# MAGIC | no_of_drivers_insured | 3 | eff_date 2026-06-21 <= today, is_deleted=0 → 3 |
# MAGIC | no_of_drivers_latest_transaction | 3 | HIST-001 is only txn, is_deleted=0 → 3 |
# MAGIC | no_of_transaction_last_2_weeks | 1 | Only HIST-001 in last 14 days |
# MAGIC | driver_change_last_transaction | 3 | 3 − 0 (no prior txn) = 3 |

# COMMAND ----------

if spark.table(ACTIVE).limit(1).count() == 0:
    spark.sql(f"""
    INSERT INTO {ACTIVE}
    (auto_policy_id, policyholder_id,
     no_of_drivers_insured, no_of_drivers_latest_transaction,
     no_of_transaction_last_2_weeks, driver_change_last_transaction,
     feature_updated_at, last_source_event_id)
    VALUES
    ('POL-1234', NULL, 3, 3, 1, 3,
     TIMESTAMP '2026-06-21 00:00:00', 'HIST-001')
    """)
    print("Seeded auto_features_active: POL-1234 → (3, 3, 1, 3)")
else:
    print("auto_features_active already has data — skipping.")

if spark.table(HISTORY).limit(1).count() == 0:
    spark.sql(f"""
    INSERT INTO {HISTORY}
    (auto_policy_id, policyholder_id,
     no_of_drivers_insured, no_of_drivers_latest_transaction,
     no_of_transaction_last_2_weeks, driver_change_last_transaction,
     feature_updated_at, last_source_event_id,
     snapshot_at, reason, event_id, changed_feature_group,
     valid_from, valid_to, is_current)
    VALUES
    ('POL-1234', NULL, 3, 3, 1, 3,
     TIMESTAMP '2026-06-21 00:00:00', 'HIST-001',
     TIMESTAMP '2026-06-21 00:00:00', 'new_business_seed',
     'HIST-001', 'driver',
     TIMESTAMP '2026-06-21 00:00:00', NULL, true)
    """)
    print("Seeded auto_features_history: POL-1234 → (3, 3, 1, 3) is_current=true")
else:
    print("auto_features_history already has data — skipping.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== policy_history ===")
display(spark.table(POLICY_HISTORY))

print("=== policy_vehicles ===")
display(spark.table(POLICY_VEHICLES))

print("=== policy_drivers ===")
display(spark.table(POLICY_DRIVERS))

print("=== auto_features_active ===")
display(spark.table(ACTIVE))

print("=== auto_features_history ===")
display(spark.table(HISTORY))
