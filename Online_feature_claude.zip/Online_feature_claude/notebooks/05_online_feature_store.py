# Databricks notebook source
# MAGIC %md
# MAGIC # 05 — Online Feature Store
# MAGIC
# MAGIC **No pip install needed** — uses only pre-installed `databricks.sdk` and REST APIs.
# MAGIC
# MAGIC ```
# MAGIC auto_features_active (Delta + UC)
# MAGIC         │  registered as Feature Spec
# MAGIC         ▼
# MAGIC Feature Serving Endpoint  →  {"auto_policy_id": "POL001"}  →  11 features in ~50ms
# MAGIC ```

# COMMAND ----------

import time, requests, json
from urllib.parse import quote


dbutils.widgets.text("catalog",       "ws_prd_analytics")
dbutils.widgets.text("schema",        "default")
dbutils.widgets.text("endpoint_name", "auto-insurance-feature-serving")

CATALOG       = dbutils.widgets.get("catalog")
SCHEMA        = dbutils.widgets.get("schema")
ENDPOINT_NAME = dbutils.widgets.get("endpoint_name")

ACTIVE_TABLE      = f"{CATALOG}.{SCHEMA}.auto_features_active"
FEATURE_SPEC_NAME = f"{CATALOG}.{SCHEMA}.auto_policy_feature_spec"

HOST    = spark.conf.get("spark.databricks.workspaceUrl")
TOKEN   = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

FEATURE_COLUMNS = [
    "no_of_vehicles", "newest_vehicle_age", "oldest_vehicle_age", "avg_vehicle_age",
    "no_of_drivers",  "avg_driver_age",     "youngest_driver_age","oldest_driver_age",
    "login_count_24h","login_count_7d",     "last_login_time",
]

print(f"Active table  : {ACTIVE_TABLE}")
print(f"Feature spec  : {FEATURE_SPEC_NAME}")
print(f"Endpoint      : {ENDPOINT_NAME}")
print(f"Workspace URL : {HOST}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Create Feature Spec
# MAGIC
# MAGIC Defines the lookup: key = `auto_policy_id`, return all 11 feature columns.
# MAGIC Safe to re-run — skips if already exists.

# COMMAND ----------

def create_feature_spec():
    # Check via Unity Catalog functions API
    encoded = quote(FEATURE_SPEC_NAME, safe="")
    check = requests.get(
        f"https://{HOST}/api/2.1/unity-catalog/functions/{encoded}",
        headers=HEADERS
    )
    if check.status_code == 200:
        print(f"Feature spec already exists: {FEATURE_SPEC_NAME}")
        return

    # Create via Feature Store REST API
    body = {
        "name": FEATURE_SPEC_NAME,
        "features": [
            {
                "table_name":    ACTIVE_TABLE,
                "lookup_key":    ["auto_policy_id"],
                "feature_names": FEATURE_COLUMNS,
            }
        ],
    }
    resp = requests.post(
        f"https://{HOST}/api/2.0/feature-store/feature-specs",
        headers=HEADERS, json=body
    )
    if resp.status_code in (200, 201):
        print(f"Feature spec created: {FEATURE_SPEC_NAME}")
    elif "already" in resp.text.lower() or resp.status_code == 409:
        print(f"Feature spec already exists: {FEATURE_SPEC_NAME}")
    else:
        print(f"REST API {resp.status_code}: {resp.text[:400]}")
        print("If the spec already exists from a previous run, ignore the error above and continue.")

create_feature_spec()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Create Feature Serving Endpoint
# MAGIC
# MAGIC Uses the pre-installed `databricks.sdk` — no pip install required.
# MAGIC Safe to re-run — skips if already exists.

# COMMAND ----------

def create_endpoint():
    # Check if endpoint already exists via REST
    resp = requests.get(
        f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
        headers=HEADERS
    )
    if resp.status_code == 200:
        state = resp.json().get("state", {}).get("ready", "unknown")
        print(f"Endpoint already exists: {ENDPOINT_NAME}  state: {state}")
        return

    # Create via REST API (works regardless of SDK version)
    print(f"Creating endpoint: {ENDPOINT_NAME} ...")
    body = {
        "name": ENDPOINT_NAME,
        "config": {
            "served_entities": [
                {
                    "name": "auto-policy-features",
                    "entity_name": FEATURE_SPEC_NAME,
                    "workload_size": "Small",
                    "scale_to_zero_enabled": True,
                }
            ]
        },
    }
    create_resp = requests.post(
        f"https://{HOST}/api/2.0/serving-endpoints",
        headers=HEADERS, json=body
    )
    if create_resp.status_code not in (200, 201):
        raise RuntimeError(f"Endpoint create failed {create_resp.status_code}: {create_resp.text[:400]}")
    print(f"Endpoint created. Waiting for READY state (up to 20 min)...")
    for i in range(60):
        poll = requests.get(
            f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
            headers=HEADERS
        )
        ep_state   = poll.json().get("state", {})
        ready      = ep_state.get("ready", "unknown")
        cfg_update = ep_state.get("config_update", "")
        print(f"  [{i*20}s] ready={ready}  config_update={cfg_update}")
        if ready == "READY":
            print("Endpoint is READY.")
            break
        if cfg_update == "UPDATE_FAILED":
            print("Endpoint provisioning FAILED. Check Databricks UI > Serving Endpoints for error details.")
            break
        time.sleep(20)

create_endpoint()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 3 — Query: pass `auto_policy_id`, get all 11 features

# COMMAND ----------

def query_features(auto_policy_id: str):
    url     = f"https://{HOST}/serving-endpoints/{ENDPOINT_NAME}/invocations"
    payload = {"dataframe_records": [{"auto_policy_id": auto_policy_id}]}

    start    = time.time()
    response = requests.post(url, headers=HEADERS, json=payload, timeout=10)
    latency  = round((time.time() - start) * 1000, 1)

    if response.status_code != 200:
        raise RuntimeError(f"{response.status_code}: {response.text}")

    features = response.json()["outputs"][0]

    print(f"Policy ID  : {auto_policy_id}")
    print(f"Latency    : {latency} ms")
    print("─" * 45)
    for col in FEATURE_COLUMNS:
        print(f"  {col:<35} = {features.get(col)}")
    return features


result = query_features("POL001")
print(f"\nlogin_count_7d for POL001 = {result.get('login_count_7d')}")
