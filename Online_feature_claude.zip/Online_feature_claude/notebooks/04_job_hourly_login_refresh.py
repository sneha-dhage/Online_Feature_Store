# Databricks notebook source
# MAGIC %md
# MAGIC # 04 — Job 2: Hourly Login Feature Refresh
# MAGIC
# MAGIC Recomputes `login_count_24h`, `login_count_7d`, and `last_login_time` for every
# MAGIC policy by reading `auto_policy_login_events`.  Only policies whose computed values
# MAGIC differ from the current active values are written — no spurious history rows.
# MAGIC
# MAGIC **Why no streaming MERGE for login events?**
# MAGIC Login counts are time-windowed aggregates that decay naturally — a login from 25 hours
# MAGIC ago falls out of the 24h window even with no new event.  Recomputing from raw events
# MAGIC on a schedule is the only way to handle that decay correctly.
# MAGIC
# MAGIC **Update order (only for policies where counts changed)**
# MAGIC 1. Close existing `is_current = true` history row
# MAGIC 2. Partial MERGE: update only login columns in `auto_features_active`
# MAGIC 3. Insert updated active snapshot into `auto_features_history` as new `is_current = true`

# COMMAND ----------

from pyspark.sql import functions as F

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "auto_insurance_features")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

ACTIVE       = f"{CATALOG}.{SCHEMA}.auto_features_active"
HISTORY      = f"{CATALOG}.{SCHEMA}.auto_features_history"
LOGIN_EVENTS = f"{CATALOG}.{SCHEMA}.auto_policy_login_events"

# COMMAND ----------
# MAGIC %md
# MAGIC ## Refresh login features

# COMMAND ----------

def refresh_login_features():
    # ------------------------------------------------------------------ #
    # Recompute counts from raw events using current_timestamp() as the   #
    # reference point so windows are always relative to "right now".      #
    # ------------------------------------------------------------------ #
    computed = spark.sql(f"""
        SELECT
            a.auto_policy_id,
            COUNT_IF(e.login_timestamp > current_timestamp() - INTERVAL 24 HOURS
                     AND e.login_timestamp <= current_timestamp())     AS new_login_count_24h,
            COUNT_IF(e.login_timestamp > current_timestamp() - INTERVAL 7 DAYS
                     AND e.login_timestamp <= current_timestamp())     AS new_login_count_7d,
            MAX(CASE WHEN e.login_timestamp <= current_timestamp()
                     THEN e.login_timestamp END)                       AS new_last_login_time
        FROM {ACTIVE} a
        LEFT JOIN {LOGIN_EVENTS} e ON a.auto_policy_id = e.auto_policy_id
        GROUP BY a.auto_policy_id
    """)

    # ------------------------------------------------------------------ #
    # Find policies where at least one login column actually changed.     #
    # eqNullSafe handles NULL == NULL correctly (returns true, not NULL). #
    # ------------------------------------------------------------------ #
    active_df = spark.table(ACTIVE)

    changed = (
        computed.alias("c")
        .join(active_df.alias("a"), "auto_policy_id")
        .where(
            ~F.col("c.new_login_count_24h").eqNullSafe(F.col("a.login_count_24h"))
            | ~F.col("c.new_login_count_7d").eqNullSafe(F.col("a.login_count_7d"))
            | ~F.col("c.new_last_login_time").eqNullSafe(F.col("a.last_login_time"))
        )
        .select(
            F.col("c.auto_policy_id"),
            F.col("c.new_login_count_24h"),
            F.col("c.new_login_count_7d"),
            F.col("c.new_last_login_time"),
        )
    )

    count = changed.count()
    if count == 0:
        print("No login features changed this hour. Skipping archive and MERGE.")
        return

    print(f"Login features changed for {count} policy/policies — archiving and merging.")

    changed.createOrReplaceTempView("_changed_login")
    changed.select("auto_policy_id").distinct().createOrReplaceTempView("_changed_login_policies")

    # ------------------------------------------------------------------ #
    # Step 1 — Close existing is_current = true history rows              #
    # ------------------------------------------------------------------ #
    spark.sql(f"""
        MERGE INTO {HISTORY} AS h
        USING _changed_login_policies AS p
        ON h.auto_policy_id = p.auto_policy_id AND h.is_current = true
        WHEN MATCHED THEN UPDATE SET
            h.is_current = false,
            h.valid_to   = current_timestamp()
    """)

    # ------------------------------------------------------------------ #
    # Step 2 — Partial MERGE: only login columns + login metadata         #
    # Vehicle and driver columns are left completely untouched.           #
    # ------------------------------------------------------------------ #
    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING _changed_login AS s
        ON t.auto_policy_id = s.auto_policy_id
        WHEN MATCHED THEN UPDATE SET
            t.login_count_24h          = s.new_login_count_24h,
            t.login_count_7d           = s.new_login_count_7d,
            t.last_login_time          = s.new_last_login_time,
            t.login_features_updated_at = current_timestamp(),
            t.feature_updated_at       = current_timestamp()
    """)

    # ------------------------------------------------------------------ #
    # Step 3 — Snapshot updated active values into history                #
    # ------------------------------------------------------------------ #
    spark.sql(f"""
        INSERT INTO {HISTORY}
        SELECT
            a.auto_policy_id,
            a.policyholder_id,
            a.no_of_vehicles,
            a.newest_vehicle_age,
            a.oldest_vehicle_age,
            a.avg_vehicle_age,
            a.no_of_drivers,
            a.avg_driver_age,
            a.youngest_driver_age,
            a.oldest_driver_age,
            a.login_count_24h,
            a.login_count_7d,
            a.last_login_time,
            a.feature_updated_at,
            a.vehicle_features_updated_at,
            a.driver_features_updated_at,
            a.login_features_updated_at,
            a.last_source_event_id,
            current_timestamp()  AS snapshot_at,
            'hourly_login_refresh' AS reason,
            NULL                 AS event_id,
            'login'              AS changed_feature_group,
            current_timestamp()  AS valid_from,
            NULL                 AS valid_to,
            true                 AS is_current
        FROM {ACTIVE} a
        INNER JOIN _changed_login_policies p ON a.auto_policy_id = p.auto_policy_id
    """)

    print(f"Done. {count} policy/policies updated. History archived.")


refresh_login_features()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== auto_features_active (login columns) ===")
display(
    spark.table(ACTIVE)
         .select("auto_policy_id", "login_count_24h", "login_count_7d",
                 "last_login_time", "login_features_updated_at")
         .orderBy("auto_policy_id")
)

print("=== auto_features_history (login refresh rows) ===")
display(
    spark.table(HISTORY)
         .filter(F.col("changed_feature_group") == "login")
         .orderBy("auto_policy_id", "valid_from")
)
