# Databricks notebook source
# MAGIC %md
# MAGIC # 05 — Online Feature Store (Online Table approach)
# MAGIC
# MAGIC **What this does:**
# MAGIC ```
# MAGIC auto_features_active (Delta + CDF)
# MAGIC         │
# MAGIC         │  continuous sync
# MAGIC         ▼
# MAGIC auto_features_active_online   ← Databricks-managed key-value store
# MAGIC         │
# MAGIC         │  {"auto_policy_id": "POL001"}
# MAGIC         ▼
# MAGIC Feature Serving Endpoint  →  all 11 features in ~10ms
# MAGIC ```
# MAGIC
# MAGIC **Requirements:**
# MAGIC - Databricks workspace that supports Online Tables
# MAGIC - `auto_features_active` must have `delta.enableChangeDataFeed = true`
# MAGIC - Run after `01_setup_tables.py`
# MAGIC
# MAGIC **Note:** Online Tables require a paid Databricks workspace (AWS/Azure/GCP).
# MAGIC University/free-tier workspaces may have this feature blocked.

# COMMAND ----------

# MAGIC %pip install "databricks-feature-engineering" "typing_extensions>=4.12.0" "protobuf>=5.29.4"

# COMMAND ----------

import time, requests, json
from urllib.parse import quote

dbutils.widgets.text("catalog",       "main")
dbutils.widgets.text("schema",        "auto_insurance_features")
dbutils.widgets.text("endpoint_name", "auto-insurance-feature-serving")

CATALOG       = dbutils.widgets.get("catalog")
SCHEMA        = dbutils.widgets.get("schema")
ENDPOINT_NAME = dbutils.widgets.get("endpoint_name")

ACTIVE_TABLE      = f"{CATALOG}.{SCHEMA}.auto_features_active"
ONLINE_TABLE_NAME = f"{CATALOG}.{SCHEMA}.auto_features_active_online"
FEATURE_SPEC_NAME = f"{CATALOG}.{SCHEMA}.auto_policy_feature_spec"

HOST    = spark.conf.get("spark.databricks.workspaceUrl")
TOKEN   = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

FEATURE_COLUMNS = [
    "no_of_vehicles", "newest_vehicle_age", "oldest_vehicle_age", "avg_vehicle_age",
    "no_of_drivers",  "avg_driver_age",     "youngest_driver_age","oldest_driver_age",
    "login_count_24h","login_count_7d",     "last_login_time",
]

print(f"Active table  : {ACTIVE_TABLE}")
print(f"Online table  : {ONLINE_TABLE_NAME}")
print(f"Feature spec  : {FEATURE_SPEC_NAME}")
print(f"Endpoint      : {ENDPOINT_NAME}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Create Online Table
# MAGIC
# MAGIC Online Table = Databricks-managed key-value store.
# MAGIC Syncs from `auto_features_active` via CDF continuously.
# MAGIC Gives millisecond lookup by `auto_policy_id`.

# COMMAND ----------

def create_online_table():
    # Check if already exists
    resp = requests.get(
        f"https://{HOST}/api/2.0/online-tables/{ONLINE_TABLE_NAME}",
        headers=HEADERS
    )
    if resp.status_code == 200:
        state = resp.json().get("status", {}).get("detailed_state", "unknown")
        print(f"Online table already exists — state: {state}")
        return

    # Try SQL DDL
    try:
        spark.sql(f"""
            CREATE ONLINE TABLE IF NOT EXISTS {ONLINE_TABLE_NAME}
            PRIMARY KEYS (auto_policy_id)
            AS SELECT * FROM {ACTIVE_TABLE}
        """)
        print(f"Online table created via SQL DDL: {ONLINE_TABLE_NAME}")
        return
    except Exception as e:
        print(f"SQL DDL failed: {e}")

    # Try REST API
    try:
        body = {
            "name": ONLINE_TABLE_NAME,
            "spec": {
                "source_table_full_name": ACTIVE_TABLE,
                "primary_key_columns": ["auto_policy_id"],
                "run_continuously": {}
            }
        }
        resp = requests.post(
            f"https://{HOST}/api/2.0/online-tables",
            headers=HEADERS, json=body
        )
        if resp.status_code in (200, 201):
            print(f"Online table created via REST API: {ONLINE_TABLE_NAME}")
            return
        else:
            print(f"REST API {resp.status_code}: {resp.text[:300]}")
    except Exception as e:
        print(f"REST API failed: {e}")

    # UI fallback
    print("""
─────────────────────────────────────────────────────────
 Create Online Table via Catalog Explorer UI
─────────────────────────────────────────────────────────
 1. Databricks → Catalog Explorer (left sidebar)
 2. Navigate to:
      main → auto_insurance_features → auto_features_active
 3. Click ⋮ (three-dot menu) → "Create online table"
 4. Fill in:
      Name        : auto_features_active_online
      Primary key : auto_policy_id
      Sync mode   : Continuous
 5. Click Create
 6. Re-run Step 1b once status = ACTIVE
─────────────────────────────────────────────────────────
    """)


create_online_table()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1b — Wait for Online Table to become ACTIVE
# MAGIC
# MAGIC Run this after creating the Online Table (via code or UI).
# MAGIC Polls every 15 seconds for up to 5 minutes.

# COMMAND ----------

print("Checking online table status...")
for i in range(20):
    resp = requests.get(
        f"https://{HOST}/api/2.0/online-tables/{ONLINE_TABLE_NAME}",
        headers=HEADERS
    )
    if resp.status_code == 200:
        status = resp.json().get("status", {})
        state  = status.get("detailed_state", "unknown")
        print(f"  [{i*15}s] State: {state}")
        if state in ("ACTIVE", "ONLINE", "ACTIVE_CONTINUOUS"):
            print("Online table is READY.")
            break
    else:
        print(f"  [{i*15}s] Not found yet — create it via UI if SQL/REST failed.")
    time.sleep(15)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Create Feature Spec
# MAGIC
# MAGIC Registers the lookup definition in Unity Catalog:
# MAGIC - Source table : `auto_features_active`
# MAGIC - Lookup key  : `auto_policy_id`
# MAGIC - Features    : all 11 columns

# COMMAND ----------

from databricks.feature_engineering import FeatureEngineeringClient
from databricks.feature_engineering.entities.feature_lookup import FeatureLookup
from databricks.feature_engineering.entities.feature_serving_endpoint import (
    EndpointCoreConfig, ServedEntity,
)

fe = FeatureEngineeringClient()

try:
    fe.get_feature_spec(name=FEATURE_SPEC_NAME)
    print(f"Feature spec already exists: {FEATURE_SPEC_NAME}")
except Exception:
    try:
        fe.create_feature_spec(
            name=FEATURE_SPEC_NAME,
            features=[
                FeatureLookup(
                    table_name=ACTIVE_TABLE,
                    lookup_key="auto_policy_id",
                    feature_names=FEATURE_COLUMNS,
                )
            ],
        )
        print(f"Feature spec created: {FEATURE_SPEC_NAME}")
    except Exception as create_err:
        if "already exists" in str(create_err).lower() or "RESOURCE_ALREADY_EXISTS" in str(create_err):
            print(f"Feature spec already exists: {FEATURE_SPEC_NAME}")
        else:
            raise

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 3 — Create Feature Serving Endpoint
# MAGIC
# MAGIC The REST endpoint that external systems call with `auto_policy_id`
# MAGIC and get all 11 features back in milliseconds via the Online Table.

# COMMAND ----------

# Check if endpoint already exists via REST
ep_resp = requests.get(
    f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
    headers=HEADERS
)

if ep_resp.status_code == 200:
    state = ep_resp.json().get("state", {}).get("ready", "unknown")
    print(f"Endpoint already exists: {ENDPOINT_NAME}  state: {state}")
else:
    fe.create_feature_serving_endpoint(
        name=ENDPOINT_NAME,
        config=EndpointCoreConfig(
            served_entities=ServedEntity(
                feature_spec_name=FEATURE_SPEC_NAME,
                workload_size="Small",
                scale_to_zero_enabled=True,
            )
        ),
    )
    print(f"Endpoint created: {ENDPOINT_NAME}")
    print("Waiting for READY state (up to 5 minutes)...")
    for _ in range(20):
        poll = requests.get(
            f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
            headers=HEADERS
        )
        state = poll.json().get("state", {}).get("ready", "unknown")
        print(f"  State: {state}")
        if state == "READY":
            print("Endpoint is READY.")
            break
        time.sleep(20)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 4 — Query: pass `auto_policy_id`, get all 11 features in ~10ms

# COMMAND ----------

def query_features(auto_policy_id: str):
    url     = f"https://{HOST}/serving-endpoints/{ENDPOINT_NAME}/invocations"
    payload = {"dataframe_records": [{"auto_policy_id": auto_policy_id}]}

    start    = time.time()
    response = requests.post(url, headers=HEADERS, json=payload, timeout=10)
    latency  = round((time.time() - start) * 1000, 1)

    if response.status_code != 200:
        raise RuntimeError(f"{response.status_code}: {response.text}")

    features = response.json()["outputs"][0]

    print(f"Policy ID  : {auto_policy_id}")
    print(f"Latency    : {latency} ms")
    print("─" * 45)
    for col in FEATURE_COLUMNS:
        print(f"  {col:<35} = {features.get(col)}")
    return features


result = query_features("POL001")
print(f"\nlogin_count_7d for POL001 = {result.get('login_count_7d')}")
