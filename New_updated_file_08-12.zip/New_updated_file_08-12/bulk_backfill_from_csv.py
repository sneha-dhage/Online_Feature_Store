# Databricks notebook source
# MAGIC %md
# MAGIC # Bulk Backfill — Load ~10K Transactions from a CSV Export
# MAGIC
# MAGIC For a one-time bulk load (e.g. ~10,000 historical transactions exported to CSV, one row per
# MAGIC transaction, with the full transaction JSON sitting in a single `JSON_FIELD` column) — writes
# MAGIC directly into `RAW_POLICY_EVENTS` in one bulk `write`, instead of looping 10K individual
# MAGIC `spark.sql(INSERT ...)` calls (what `03_autoloader_landing_zone.py` does per file — fine for
# MAGIC one-at-a-time landing, too slow for a 10K-row backfill) or writing 10K separate files to the
# MAGIC `incoming_json` volume and waiting for Auto Loader to discover them all.
# MAGIC
# MAGIC Standalone — does not modify `01`-`09`. After this runs, skip `03` entirely for this batch
# MAGIC (the rows are already in `RAW_POLICY_EVENTS`). Go straight to `04_sp_compute_features` →
# MAGIC `05_routing_pipeline`, unmodified, same as any other new transactions.
# MAGIC
# MAGIC ## Expected CSV columns (from the Excel/CSV export)
# MAGIC ```
# MAGIC SRC_HH_NUM | PLCY_CNTRCT_NUM | PLCY_ID_SK | SRC_TRANS_TMSP | EFF_DT | AUTO_PLCY_TRANS_SK | JSON_FIELD
# MAGIC ```
# MAGIC `JSON_FIELD` is treated as the source of truth for every field it already contains (including
# MAGIC `1_vehicle_snapshot` / `2_driver_snapshot` / `3_coverage_snapshot`). Any of the 6 header fields
# MAGIC `JSON_FIELD` is missing are filled in from their own CSV columns before the row is stored — so
# MAGIC this works whether the export embedded the full self-contained transaction JSON, or just the
# MAGIC three snapshot arrays.

# COMMAND ----------

import json
from datetime import datetime
from pyspark.sql import Row
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

dbutils.widgets.text("catalog",  "main")
dbutils.widgets.text("schema",   "final_database")
dbutils.widgets.text("csv_path", "/Volumes/main/final_database/incoming_json/bulk_transactions.csv")

CATALOG  = dbutils.widgets.get("catalog")
SCHEMA   = dbutils.widgets.get("schema")
CSV_PATH = dbutils.widgets.get("csv_path")

RAW_EVENTS = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
DLQ        = f"{CATALOG}.{SCHEMA}.RAW_EVENTS_DLQ"

print(f"Reading CSV : {CSV_PATH}")
print(f"Target      : {RAW_EVENTS}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Read the CSV
# MAGIC
# MAGIC `multiLine=True` + explicit quote/escape are required because the `JSON_FIELD` cell contains
# MAGIC embedded newlines, commas, and double quotes (it's a pretty-printed JSON blob) — Excel's CSV
# MAGIC export wraps that whole cell in `"..."` and escapes internal `"` as `""`, which is standard
# MAGIC RFC 4180 and Spark's CSV reader handles it correctly with these options.

# COMMAND ----------

raw_df = (
    spark.read
    .option("header", True)
    .option("multiLine", True)
    .option("quote", '"')
    .option("escape", '"')
    .csv(CSV_PATH)
)

print(f"Rows in CSV: {raw_df.count()}")
raw_df.printSchema()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Date normalizer
# MAGIC
# MAGIC Excel commonly exports dates in the local format (e.g. `7/4/2025`) rather than ISO — this
# MAGIC tries the formats we're likely to see and always emits `YYYY-MM-DD HH:MM:SS`.

# COMMAND ----------

_DATE_FORMATS = [
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d",
    "%m/%d/%Y %H:%M:%S",
    "%m/%d/%Y",
]


def normalize_ts(value):
    v = str(value).strip()
    if not v:
        return None
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(v, fmt).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
    return None  # unparseable — row will be routed to DLQ


# COMMAND ----------
# MAGIC %md
# MAGIC ## Parse every row: reconstruct RAW_PAYLOAD, extract header fields, or route to DLQ

# COMMAND ----------

REQUIRED_HEADER_FIELDS = ["auto_plcy_trans_sk", "plcy_id_sk", "eff_dt", "src_trans_tmsp"]

good_rows = []
dlq_rows  = []

for r in raw_df.toLocalIterator():
    src_hh_num   = (r["SRC_HH_NUM"] or "").strip()
    cntrct_num   = (r["PLCY_CNTRCT_NUM"] or "").strip()
    policy_id    = (r["PLCY_ID_SK"] or "").strip()
    trans_tmsp   = (r["SRC_TRANS_TMSP"] or "").strip()
    eff_dt       = (r["EFF_DT"] or "").strip()
    trans_id     = (r["AUTO_PLCY_TRANS_SK"] or "").strip()
    json_field   = r["JSON_FIELD"]

    source_label = trans_id or f"row(policy={policy_id})"

    try:
        event = json.loads(json_field)

        # Fill in any header field the JSON blob itself didn't carry, from its own CSV column.
        if not event.get("auto_plcy_trans_sk"):
            event["auto_plcy_trans_sk"] = trans_id
        if not event.get("plcy_id_sk"):
            event["plcy_id_sk"] = policy_id
        if not event.get("plcy_cntrct_num"):
            event["plcy_cntrct_num"] = cntrct_num
        if not event.get("src_hh_num"):
            event["src_hh_num"] = src_hh_num
        if not event.get("eff_dt"):
            event["eff_dt"] = eff_dt
        if not event.get("src_trans_tmsp"):
            event["src_trans_tmsp"] = trans_tmsp

        missing = [f for f in REQUIRED_HEADER_FIELDS if not str(event.get(f, "")).strip()]
        if missing:
            raise ValueError(f"Missing header fields after merge: {missing}")

        if not isinstance(event.get("1_vehicle_snapshot"), list) or not event["1_vehicle_snapshot"]:
            raise ValueError("1_vehicle_snapshot is missing or empty")

        eff_dt_norm     = normalize_ts(event["eff_dt"])
        trans_tmsp_norm = normalize_ts(event["src_trans_tmsp"])
        if eff_dt_norm is None:
            raise ValueError(f"Unparseable eff_dt: {event['eff_dt']!r}")
        if trans_tmsp_norm is None:
            raise ValueError(f"Unparseable src_trans_tmsp: {event['src_trans_tmsp']!r}")

        good_rows.append(Row(
            TRANS_ID       = str(event["auto_plcy_trans_sk"]).strip(),
            AUTO_POLICY_ID = str(event["plcy_id_sk"]).strip(),
            PLCY_CNTRCT_NUM= str(event.get("plcy_cntrct_num") or "").strip(),
            SRC_HH_NUM     = str(event.get("src_hh_num") or "").strip(),
            EFF_DT         = eff_dt_norm,
            SRC_TRANS_TMSP = trans_tmsp_norm,
            RAW_PAYLOAD    = json.dumps(event),
        ))

    except Exception as e:
        dlq_rows.append(Row(
            RAW_PAYLOAD   = json_field if isinstance(json_field, str) else str(json_field),
            ERROR_MESSAGE = str(e),
            SOURCE_NAME   = f"bulk_csv_backfill:{source_label}",
        ))

print(f"Parsed OK : {len(good_rows)}")
print(f"Failed    : {len(dlq_rows)}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Dedupe against TRANS_IDs already landed, then bulk-write both good rows and DLQ rows

# COMMAND ----------

if good_rows:
    good_schema = StructType([
        StructField("TRANS_ID",        StringType(), False),
        StructField("AUTO_POLICY_ID",  StringType(), False),
        StructField("PLCY_CNTRCT_NUM", StringType(), True),
        StructField("SRC_HH_NUM",      StringType(), True),
        StructField("EFF_DT",          StringType(), False),
        StructField("SRC_TRANS_TMSP",  StringType(), False),
        StructField("RAW_PAYLOAD",     StringType(), False),
    ])
    good_df = spark.createDataFrame(good_rows, schema=good_schema)

    existing_ids = spark.table(RAW_EVENTS).select("TRANS_ID").distinct()
    new_df = good_df.join(existing_ids, on="TRANS_ID", how="left_anti")

    skipped = good_df.count() - new_df.count()
    if skipped:
        print(f"Skipping {skipped} row(s) already present in {RAW_EVENTS} (idempotent re-run).")

    final_df = (
        new_df
        .withColumn("EFF_DT",         new_df["EFF_DT"].cast(TimestampType()))
        .withColumn("SRC_TRANS_TMSP", new_df["SRC_TRANS_TMSP"].cast(TimestampType()))
        .withColumn("INGESTED_AT",    F.current_timestamp())
    )

    final_df.write.format("delta").mode("append").saveAsTable(RAW_EVENTS)
    print(f"Inserted {final_df.count()} new row(s) into {RAW_EVENTS}")
else:
    print("No valid rows to insert.")

if dlq_rows:
    dlq_schema = StructType([
        StructField("RAW_PAYLOAD",   StringType(), True),
        StructField("ERROR_MESSAGE", StringType(), True),
        StructField("SOURCE_NAME",   StringType(), True),
    ])
    dlq_df = spark.createDataFrame(dlq_rows, schema=dlq_schema)
    dlq_df = dlq_df.withColumn("FAILED_AT", F.current_timestamp())
    dlq_df.write.format("delta").mode("append").saveAsTable(DLQ)
    print(f"Routed {dlq_df.count()} malformed row(s) to {DLQ} — check ERROR_MESSAGE for details.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== Recently landed RAW_POLICY_EVENTS ===")
display(spark.table(RAW_EVENTS).orderBy(F.col("INGESTED_AT").desc()).limit(20))

print("=== Recent DLQ entries ===")
display(spark.sql(f"SELECT * FROM {DLQ} ORDER BY FAILED_AT DESC LIMIT 20"))

print("\n>>> Next: skip 03 for this batch (already in RAW_POLICY_EVENTS) — run 04_sp_compute_features, then 05_routing_pipeline <<<")
