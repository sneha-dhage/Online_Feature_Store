# Databricks notebook source
# MAGIC %md
# MAGIC # 08 — Online Feature Store (Lakebase)
# MAGIC
# MAGIC Publishes `AUTO_FEATURES_ACTIVE` into a Lakebase online store and exposes it for
# MAGIC low-latency lookup by `AUTO_POLICY_ID` via a Feature Serving Endpoint — pass a policy
# MAGIC id, get all 30 GROUP_A/GROUP_B feature values back over REST.
# MAGIC
# MAGIC ```
# MAGIC Step 1: Create Lakebase Online Store
# MAGIC Step 2: Publish AUTO_FEATURES_ACTIVE → Lakebase Online Store
# MAGIC Step 3: Create Feature Spec  (key=AUTO_POLICY_ID, 30 features)
# MAGIC Step 4: Create Feature Serving Endpoint  (entity_name = Feature Spec)
# MAGIC Step 5: Query → pass AUTO_POLICY_ID → get all 30 features
# MAGIC ```
# MAGIC
# MAGIC Deliberately no `psycopg2`/direct-Postgres connection here — that path caused a kernel
# MAGIC crash (SIGABRT) on this workspace's Serverless compute, since `psycopg2-binary` bundles a
# MAGIC compiled native extension that doesn't coexist well with Serverless's sandboxing. This
# MAGIC design stays pure-HTTP (`requests`) end to end, same as it always was for `01`-`07`.

# COMMAND ----------

# MAGIC %pip install "databricks-feature-engineering>=0.13.0"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import time, requests
from databricks.feature_engineering import FeatureEngineeringClient
from databricks.feature_engineering.entities.feature_lookup import FeatureLookup

dbutils.widgets.text("catalog",       "main")
dbutils.widgets.text("schema",        "final_database")
dbutils.widgets.text("endpoint_name", "auto-policy-feature-serving")
dbutils.widgets.text("online_store",  "auto-policy-online-store")

CATALOG       = dbutils.widgets.get("catalog")
SCHEMA        = dbutils.widgets.get("schema")
ENDPOINT_NAME = dbutils.widgets.get("endpoint_name")
ONLINE_STORE  = dbutils.widgets.get("online_store")

ACTIVE_TABLE      = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
ONLINE_TABLE_NAME = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE_ONLINE"
FEATURE_SPEC_NAME = f"{CATALOG}.{SCHEMA}.AUTO_POLICY_FEATURE_SPEC"
LOOKUP_KEY        = "AUTO_POLICY_ID"

HOST    = spark.conf.get("spark.databricks.workspaceUrl")
TOKEN   = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

fe = FeatureEngineeringClient()

# Same GROUP_A + GROUP_B column list as 01_setup_tables.py — the 30 real feature columns.
GROUP_A_COLUMN_NAMES = [
    "TXN_CNT_1D", "TXN_CNT_1W", "TXN_CNT_1M",
    "OUTSTANDING_TXN_IND", "TENURE_YRS",
]
GROUP_B_COLUMN_NAMES = [
    "VEH_CNT", "AVG_VEH_AGE", "VEH_ADDED_LATEST_TXN",
    "DRVR_CNT", "MAX_DRVR_AGE", "MIN_DRVR_AGE", "AVG_DRVR_AGE", "DRVRS_ADDED_LATEST_TXN",
    "PREM_CHANGE_AMT",
    "BI_COVERAGE_ADDED", "BI_COVERAGE_REMOVED",
    "PD_COVERAGE_ADDED", "PD_COVERAGE_REMOVED",
    "MD_COVERAGE_ADDED", "MD_COVERAGE_REMOVED",
    "COLL_COVERAGE_ADDED", "COLL_COVERAGE_REMOVED",
    "COMP_COVERAGE_ADDED", "COMP_COVERAGE_REMOVED",
    "PIP_COVERAGE_ADDED", "PIP_COVERAGE_REMOVED",
    "COMP_DED_CHANGE_IND", "COLL_DED_CHANGE_IND", "GNDR_CHANGE_IND", "MRTL_CHANGE_IND",
]
FEATURE_COLUMNS = GROUP_A_COLUMN_NAMES + GROUP_B_COLUMN_NAMES

print(f"Active table      : {ACTIVE_TABLE}")
print(f"Online table name : {ONLINE_TABLE_NAME}")
print(f"Feature spec      : {FEATURE_SPEC_NAME}")
print(f"Online store      : {ONLINE_STORE}")
print(f"Endpoint          : {ENDPOINT_NAME}")
print(f"Lookup key        : {LOOKUP_KEY}")
print(f"Feature columns   : {len(FEATURE_COLUMNS)}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 1 — Create Lakebase Online Store
# MAGIC
# MAGIC Provisions the Lakebase instance that backs fast feature lookups.
# MAGIC Skip if already exists.

# COMMAND ----------

try:
    existing = fe.get_online_store(name=ONLINE_STORE)
    print(f"Online store already exists: {ONLINE_STORE}  state={existing.state}")
except Exception:
    print(f"Creating online store: {ONLINE_STORE} ...")
    try:
        store = fe.create_online_store(
            name=ONLINE_STORE,
            capacity="CU_1"
        )
        print(f"Online store created: {store.name}  state={store.state}")
    except Exception as e:
        if "already exists" in str(e).lower():
            print(f"Online store already exists: {ONLINE_STORE}")
        else:
            raise

# Wait for store to be ACTIVE
print("Waiting for online store to be ACTIVE...")
for i in range(30):
    try:
        store = fe.get_online_store(name=ONLINE_STORE)
        print(f"  [{i*10}s] state={store.state}")
        if any(s in str(store.state).upper() for s in ("ACTIVE", "AVAILABLE", "RUNNING", "ONLINE")):
            print(f"Online store is ready: {store.state}")
            break
    except Exception as e:
        print(f"  [{i*10}s] checking... ({e})")
    time.sleep(10)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 2 — Publish AUTO_FEATURES_ACTIVE to the Online Store
# MAGIC
# MAGIC Requires the source table to have a primary key and CDF enabled —
# MAGIC `01_setup_tables.py` already sets both (`AUTO_FEATURES_ACTIVE_PK` on `AUTO_POLICY_ID`,
# MAGIC `delta.enableChangeDataFeed`). Sets up continuous sync so the online store stays fresh
# MAGIC as `05`/`06`/`07` update ACTIVE.

# COMMAND ----------

online_store = fe.get_online_store(name=ONLINE_STORE)
print(f"Using online store: {online_store.name}  state={online_store.state}")

try:
    fe.publish_table(
        online_store=online_store,
        source_table_name=ACTIVE_TABLE,
        online_table_name=ONLINE_TABLE_NAME,
    )
    print(f"Table published: {ONLINE_TABLE_NAME}")
except Exception as e:
    if "already exists" in str(e).lower() or "RESOURCE_ALREADY_EXISTS" in str(e):
        print(f"Online table already published: {ONLINE_TABLE_NAME}")
    else:
        print(f"Publish error: {e}")
        raise

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 3 — Create Feature Spec
# MAGIC
# MAGIC Registers the lookup definition: key=AUTO_POLICY_ID, return all 30 GROUP_A/GROUP_B columns.

# COMMAND ----------

try:
    fe.get_feature_spec(name=FEATURE_SPEC_NAME)
    print(f"Feature spec already exists: {FEATURE_SPEC_NAME}")
except Exception:
    try:
        fe.create_feature_spec(
            name=FEATURE_SPEC_NAME,
            features=[
                FeatureLookup(
                    table_name=ACTIVE_TABLE,
                    lookup_key=LOOKUP_KEY,
                    feature_names=FEATURE_COLUMNS,
                )
            ],
        )
        print(f"Feature spec created: {FEATURE_SPEC_NAME}")
    except Exception as e:
        if "already exists" in str(e).lower() or "RESOURCE_ALREADY_EXISTS" in str(e):
            print(f"Feature spec already exists: {FEATURE_SPEC_NAME}")
        else:
            raise

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 4 — Create Feature Serving Endpoint
# MAGIC
# MAGIC Deletes the old failed endpoint if present, then creates fresh.

# COMMAND ----------

ep_resp = requests.get(
    f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
    headers=HEADERS
)

if ep_resp.status_code == 200:
    ep_state  = ep_resp.json().get("state", {})
    ep_ready  = ep_state.get("ready", "unknown")
    ep_update = ep_state.get("config_update", "")
    print(f"Endpoint exists: ready={ep_ready}  config_update={ep_update}")

    if ep_update == "UPDATE_FAILED":
        print("Deleting failed endpoint and recreating...")
        del_resp = requests.delete(
            f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
            headers=HEADERS
        )
        if del_resp.status_code in (200, 202, 204):
            print("Deleted. Waiting 10s...")
            time.sleep(10)
            ep_resp = requests.get(
                f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
                headers=HEADERS
            )
        else:
            print(f"Delete failed: {del_resp.status_code} {del_resp.text[:200]}")
    elif ep_ready == "READY":
        print("Endpoint already READY — skip to Step 5.")

if ep_resp.status_code != 200:
    print(f"Creating endpoint: {ENDPOINT_NAME} ...")
    body = {
        "name": ENDPOINT_NAME,
        "config": {
            "served_entities": [
                {
                    "name": "auto-policy-features",
                    "entity_name": FEATURE_SPEC_NAME,
                    "workload_size": "Small",
                    "scale_to_zero_enabled": True,
                }
            ]
        }
    }
    cr = requests.post(
        f"https://{HOST}/api/2.0/serving-endpoints",
        headers=HEADERS, json=body
    )
    if cr.status_code not in (200, 201):
        raise RuntimeError(f"Create failed {cr.status_code}: {cr.text[:400]}")

    print("Endpoint created. Waiting for READY (up to 20 min)...")
    for i in range(60):
        poll = requests.get(
            f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
            headers=HEADERS
        )
        ep     = poll.json().get("state", {})
        ready  = ep.get("ready", "unknown")
        update = ep.get("config_update", "")
        print(f"  [{i*20}s] ready={ready}  config_update={update}")
        if ready == "READY":
            print("\nEndpoint is READY.")
            break
        if update == "UPDATE_FAILED":
            print("\nFAILED. Check Databricks UI > Serving > Logs.")
            break
        time.sleep(20)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Step 5 — Query: pass `AUTO_POLICY_ID`, get all 30 features back

# COMMAND ----------

# Verify endpoint is READY
ep_check = requests.get(
    f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
    headers=HEADERS
)
if ep_check.status_code != 200:
    raise RuntimeError(f"Endpoint '{ENDPOINT_NAME}' not found. Run Step 4 first.")

ep_state = ep_check.json().get("state", {})
ready    = ep_state.get("ready", "unknown")
update   = ep_state.get("config_update", "")
print(f"Endpoint state: ready={ready}  config_update={update}")

if ready != "READY":
    raise RuntimeError(
        f"Endpoint not ready (ready={ready}).\n"
        "  → Wait a few minutes and re-run this cell."
    )

print("Endpoint is READY — querying now...\n")


def get_features(auto_policy_id: str):
    url     = f"https://{HOST}/serving-endpoints/{ENDPOINT_NAME}/invocations"
    payload = {"dataframe_records": [{LOOKUP_KEY: auto_policy_id}]}

    start    = time.time()
    response = requests.post(url, headers=HEADERS, json=payload, timeout=120)
    latency  = round((time.time() - start) * 1000, 1)

    if response.status_code != 200:
        raise RuntimeError(f"{response.status_code}: {response.text}")

    features = response.json()["outputs"][0]

    print(f"AUTO_POLICY_ID : {auto_policy_id}")
    print(f"Latency        : {latency} ms")
    print("-" * 45)
    for col in FEATURE_COLUMNS:
        print(f"  {col:<30} = {features.get(col)}")
    return features


result = get_features("503203043")
