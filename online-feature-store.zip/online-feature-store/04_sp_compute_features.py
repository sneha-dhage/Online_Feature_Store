# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC # 04 — PySpark: Compute Features → COMPUTED_FEATURE_EVENTS (Silver) [OPTIMIZED]
# MAGIC
# MAGIC Streams new transactions from `RAW_POLICY_EVENTS` via CDF. Unlike the original design,
# MAGIC this version does **not** re-read a policy's entire transaction history on every new
# MAGIC transaction. Instead it looks up that policy's current snapshot in
# MAGIC `AUTO_POLICY_SNAPSHOT_STATE` (one row per policy, not one row per transaction), diffs the
# MAGIC new transaction against it, and writes the new snapshot back in one batched `MERGE` per
# MAGIC micro-batch. See `ARCHITECTURE.md` in this folder for the full design rationale.
# MAGIC
# MAGIC **Requires `AUTO_POLICY_SNAPSHOT_STATE` to already reflect every existing policy's true
# MAGIC current state.** If this schema already has transaction history, run
# MAGIC `bootstrap_snapshot_state.py` ONCE before relying on this notebook — that's the only place
# MAGIC a full history read still happens, and it happens exactly once per policy, ever.
# MAGIC
# MAGIC ## The core mechanism
# MAGIC ```
# MAGIC new_events (this micro-batch only, already carries RAW_PAYLOAD)
# MAGIC       │
# MAGIC       ├──► explode + aggregate THIS transaction's own snapshot (same formulas as before)
# MAGIC       │
# MAGIC AUTO_POLICY_SNAPSHOT_STATE ──► broadcast join on touched policies ──► one "prior state" row per policy
# MAGIC       │
# MAGIC       ▼
# MAGIC unionByName(prior_state_rows, new_snapshot_rows)
# MAGIC       │
# MAGIC       ▼
# MAGIC Window.partitionBy(AUTO_POLICY_ID).orderBy(IS_STATE_ROW desc, SRC_TRANS_TMSP asc) + lag()
# MAGIC       │        (SAME array_except / map_change_ind formulas as the original design --
# MAGIC       │         only the INPUT is smaller: 1 state row + this batch's new txns per policy,
# MAGIC       │         not a policy's entire lifetime history)
# MAGIC       ▼
# MAGIC filter out synthetic state rows ──► write COMPUTED_FEATURE_EVENTS
# MAGIC       │
# MAGIC       └──► take each policy's LAST row ──► ONE batched MERGE ──► AUTO_POLICY_SNAPSHOT_STATE
# MAGIC ```
# MAGIC
# MAGIC The synthetic "prior state" row is ordered *before* any real transaction in the window,
# MAGIC so `lag()` chains correctly even if a policy gets two new transactions in the same
# MAGIC micro-batch: the second transaction's "previous" becomes the first transaction's snapshot,
# MAGIC not the old state row. No imperative per-key loop is needed for this — it's the same
# MAGIC declarative window-function mechanism the original design already used, just fed a much
# MAGIC smaller input.
# MAGIC
# MAGIC ## Which features need state, and which don't
# MAGIC 7 features are a pure function of the current transaction alone (no state needed):
# MAGIC `VEH_CNT`, `AVG_VEH_AGE`, `DRVR_CNT`, `MAX/MIN/AVG_DRVR_AGE`, `PREM_CHANGE_AMT`,
# MAGIC `OUTSTANDING_TXN_IND`. 18 features need the previous snapshot (the lag/array_except/
# MAGIC map_change_ind ones). `TXN_CNT_1D/1W/1M` and `TENURE_YRS` need small *bounded* state
# MAGIC (`RECENT_TXN_TMSPS`, `POLICY_INCEPTION_EFF_DT`) — not full history, just a trailing window.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, ArrayType

dbutils.widgets.text("catalog",         "workspace")
dbutils.widgets.text("schema",          "featurestore_test")
dbutils.widgets.text("checkpoint_path", "/Volumes/workspace/featurestore_test/checkpoints/sp_compute")

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")

RAW_EVENTS = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
COMPUTED   = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"
STATE      = f"{CATALOG}.{SCHEMA}.AUTO_POLICY_SNAPSHOT_STATE"

CVG_CATEGORIES = ["BI", "PD", "MD", "COLL", "COMP", "PIP"]

# Trailing window kept in RECENT_TXN_TMSPS -- must be > 1 month (TXN_CNT_1M's own lookback)
# with a safety margin, since it's pruned every batch to stay bounded.
RECENT_TMSP_WINDOW_DAYS = 35

# COMMAND ----------

# MAGIC %md
# MAGIC ## JSON Schema (partial — only the fields features are computed from) — unchanged

# COMMAND ----------

VEHICLE_SCHEMA = StructType([
    StructField("vin",               StringType()),
    StructField("mdl_yr",            IntegerType()),
    StructField("auto_soi_trans_sk", StringType()),
])

DRIVER_SCHEMA = StructType([
    StructField("drvr_id_sk",   StringType()),
    StructField("drvr_brth_dt", StringType()),
    StructField("drvr_gndr_cd", StringType()),
    StructField("drvr_mrtl_cd", StringType()),
])

COVERAGE_SCHEMA = StructType([
    StructField("auto_soi_trans_sk",       StringType()),
    StructField("mva_cvg_ctgy_cd",         StringType()),
    StructField("cvg_typ_cd",              StringType()),
    StructField("ded_amt",                 DoubleType()),
    StructField("old_full_term_prem_amt",  DoubleType()),
    StructField("new_full_term_prem_amt",  DoubleType()),
])

ARRAYS_SCHEMA = StructType([
    StructField("1_vehicle_snapshot",  ArrayType(VEHICLE_SCHEMA)),
    StructField("2_driver_snapshot",   ArrayType(DRIVER_SCHEMA)),
    StructField("3_coverage_snapshot", ArrayType(COVERAGE_SCHEMA)),
])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper: map-based change indicator — unchanged
# MAGIC
# MAGIC 1 if any key present in BOTH maps has a different value between current and previous transaction.

# COMMAND ----------

def map_change_ind(cur_map, prev_map):
    return F.when(
        F.expr(f"""
            exists(map_entries({cur_map}), e ->
                {prev_map}[e.key] IS NOT NULL
                AND e.value IS NOT NULL
                AND {prev_map}[e.key] != e.value)
        """), F.lit(1)).otherwise(F.lit(0))

# COMMAND ----------

# MAGIC %md
# MAGIC ## foreachBatch — Compute Using Snapshot State (no full-history re-read)

# COMMAND ----------

def compute_batch(df, batch_id):
    new_events = df.filter(F.col("_change_type") == "insert")
    count = new_events.count()
    print(f"\n[batch {batch_id}] {count} new raw event(s)")
    if count == 0:
        return

    new_trans_ids = [r["TRANS_ID"] for r in new_events.select("TRANS_ID").distinct().collect()]
    touched_policies_df = new_events.select("AUTO_POLICY_ID").distinct()
    print(f"  policies touched : {touched_policies_df.count()}")
    print(f"  new transactions : {len(new_trans_ids)}")

    txn_keys = ["TRANS_ID", "AUTO_POLICY_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM", "EFF_DT", "SRC_TRANS_TMSP"]

    # ── Parse ONLY the new events -- they already carry RAW_PAYLOAD from the CDF feed,
    #    so no re-read of RAW_POLICY_EVENTS' history happens here at all ──
    new_base = (
        new_events
        .withColumn("arrays", F.from_json(F.col("RAW_PAYLOAD"), ARRAYS_SCHEMA))
        .select(
            *txn_keys,
            F.col("arrays.`1_vehicle_snapshot`").alias("vehicles"),
            F.col("arrays.`2_driver_snapshot`").alias("drivers"),
            F.col("arrays.`3_coverage_snapshot`").alias("coverages"),
        )
    )

    # ── Explode the three snapshot arrays (identical logic to the original design,
    #    just scoped to this batch's new transactions instead of full history) ──
    df_veh = (
        new_base.select(*txn_keys, F.explode_outer("vehicles").alias("v"))
        .select(*txn_keys,
                F.col("v.vin").alias("vin"),
                F.col("v.mdl_yr").alias("mdl_yr"),
                F.col("v.auto_soi_trans_sk").alias("auto_soi_trans_sk"))
    )

    df_drv = (
        new_base.select(*txn_keys, F.explode_outer("drivers").alias("d"))
        .select(*txn_keys,
                F.col("d.drvr_id_sk").alias("drvr_id_sk"),
                F.to_date("d.drvr_brth_dt").alias("drvr_brth_dt"),
                F.col("d.drvr_gndr_cd").alias("drvr_gndr_cd"),
                F.col("d.drvr_mrtl_cd").alias("drvr_mrtl_cd"))
    )

    df_cvg = (
        new_base.select(*txn_keys, F.explode_outer("coverages").alias("c"))
        .select(*txn_keys,
                F.col("c.auto_soi_trans_sk").alias("auto_soi_trans_sk"),
                F.col("c.mva_cvg_ctgy_cd").alias("cvg_ctgy"),
                F.col("c.cvg_typ_cd").alias("cvg_typ_cd"),
                F.col("c.ded_amt").alias("ded_amt"),
                F.col("c.old_full_term_prem_amt").alias("old_ft_prem"),
                F.col("c.new_full_term_prem_amt").alias("new_ft_prem"))
        .join(df_veh.select("TRANS_ID", "auto_soi_trans_sk", "vin"),
              on=["TRANS_ID", "auto_soi_trans_sk"], how="left")
    )

    # ── Snapshot aggregates per NEW transaction (unchanged formulas) ──
    agg_veh = (
        df_veh.groupBy(*txn_keys)
        .agg(F.countDistinct("vin").alias("veh_cnt"),
             F.floor(F.avg(F.year(F.current_date()) - F.col("mdl_yr"))).alias("avg_veh_age"),
             F.collect_set("vin").alias("vin_set"))
    )

    agg_drv = (
        df_drv
        .withColumn("drvr_age", F.floor(F.months_between(F.current_date(), "drvr_brth_dt") / 12))
        .groupBy(*txn_keys)
        .agg(F.countDistinct("drvr_id_sk").alias("drvr_cnt"),
             F.max("drvr_age").alias("max_drvr_age"),
             F.min("drvr_age").alias("min_drvr_age"),
             F.floor(F.avg("drvr_age")).alias("avg_drvr_age"),
             F.map_from_entries(F.collect_list(
                 F.struct(F.col("drvr_id_sk").cast("string"), F.col("drvr_gndr_cd")))).alias("gndr_map"),
             F.map_from_entries(F.collect_list(
                 F.struct(F.col("drvr_id_sk").cast("string"), F.col("drvr_mrtl_cd")))).alias("mrtl_map"),
             F.collect_set(F.col("drvr_id_sk").cast("string")).alias("drvr_id_set"))
    )

    agg_prem = (
        df_cvg.groupBy(*txn_keys)
        .agg(F.sum(F.coalesce(F.col("new_ft_prem"), F.lit(0.0)) - F.coalesce(F.col("old_ft_prem"), F.lit(0.0)))
              .alias("prem_change_amt"))
    )

    df_cvg_scoped = (
        df_cvg.filter(F.col("cvg_ctgy").isin(CVG_CATEGORIES))
              .withColumn("cvg_key", F.concat_ws("|", F.col("vin"), F.col("cvg_typ_cd")))
    )

    agg_cvg = (
        df_cvg_scoped.groupBy(*txn_keys)
        .agg(
            *[F.collect_set(F.when(F.col("cvg_ctgy") == cat, F.col("cvg_key"))).alias(f"{cat}_key_set")
              for cat in CVG_CATEGORIES],
            F.map_from_entries(F.collect_list(
                F.when(F.col("cvg_ctgy") == "COMP", F.struct(F.col("cvg_key"), F.col("ded_amt")))
            )).alias("comp_ded_map"),
            F.map_from_entries(F.collect_list(
                F.when(F.col("cvg_ctgy") == "COLL", F.struct(F.col("cvg_key"), F.col("ded_amt")))
            )).alias("coll_ded_map"),
        )
    )

    new_snapshot = (
        new_base.select(*txn_keys)
        .join(agg_veh, txn_keys, "left")
        .join(agg_drv, txn_keys, "left")
        .join(agg_prem, txn_keys, "left")
        .join(agg_cvg, txn_keys, "left")
        .withColumn("IS_STATE_ROW", F.lit(False))
    )

    # ── Look up prior state for TOUCHED policies only -- broadcast join against the small
    #    per-policy state table, not an .isin() list against the full raw table ──
    #
    # LAG_COLS need the previous snapshot for array_except/map_change_ind comparisons.
    # NO_STATE_COLS are a pure function of the current transaction alone (VEH_CNT,
    # PREM_CHANGE_AMT, etc.) -- they don't need state, but still have to survive the
    # union below as real (non-null) values on the new-snapshot side, since the final
    # output for real transaction rows reads them straight off this same dataframe.
    LAG_COLS = ["vin_set", "drvr_id_set", "gndr_map", "mrtl_map", "comp_ded_map", "coll_ded_map"] + \
               [f"{cat}_key_set" for cat in CVG_CATEGORIES]
    NO_STATE_COLS = ["veh_cnt", "avg_veh_age", "drvr_cnt", "max_drvr_age", "min_drvr_age",
                     "avg_drvr_age", "prem_change_amt"]
    snapshot_cols = LAG_COLS + NO_STATE_COLS

    prior_state = (
        spark.table(STATE)
        .join(F.broadcast(touched_policies_df), "AUTO_POLICY_ID", "inner")
        .select(
            "AUTO_POLICY_ID",
            F.col("VIN_SET").alias("vin_set"),
            F.col("DRVR_ID_SET").alias("drvr_id_set"),
            F.col("GNDR_MAP").alias("gndr_map"),
            F.col("MRTL_MAP").alias("mrtl_map"),
            F.col("COMP_DED_MAP").alias("comp_ded_map"),
            F.col("COLL_DED_MAP").alias("coll_ded_map"),
            F.col("BI_KEY_SET").alias("BI_key_set"),
            F.col("PD_KEY_SET").alias("PD_key_set"),
            F.col("MD_KEY_SET").alias("MD_key_set"),
            F.col("COLL_KEY_SET").alias("COLL_key_set"),
            F.col("COMP_KEY_SET").alias("COMP_key_set"),
            F.col("PIP_KEY_SET").alias("PIP_key_set"),
            F.col("RECENT_TXN_TMSPS").alias("state_recent_tmsps"),
            F.col("POLICY_INCEPTION_EFF_DT").alias("state_inception_eff_dt"),
        )
        .withColumn("TRANS_ID", F.lit(None).cast("string"))
        .withColumn("PLCY_CNTRCT_NUM", F.lit(None).cast("string"))
        .withColumn("SRC_HH_NUM", F.lit(None).cast("string"))
        .withColumn("EFF_DT", F.lit(None).cast("timestamp"))
        # Sentinel timestamp, guaranteed earlier than any real transaction -- combined with
        # IS_STATE_ROW desc as the primary sort key below, this just needs to be non-null
        # and orderable; the exact value never leaks into output (state rows get filtered
        # out before COMPUTED_FEATURE_EVENTS is written).
        .withColumn("SRC_TRANS_TMSP", F.lit("1900-01-01 00:00:00").cast("timestamp"))
        .withColumn("IS_STATE_ROW", F.lit(True))
        # NO_STATE_COLS placeholders -- irrelevant for the state row itself (it's filtered
        # out before these would ever be read), only present so unionByName lines up.
        # Types must match what the aggregations below actually produce: countDistinct()
        # and floor() both return LongType, sum() over DoubleType columns returns DoubleType.
        .withColumn("veh_cnt", F.lit(None).cast("long"))
        .withColumn("avg_veh_age", F.lit(None).cast("long"))
        .withColumn("drvr_cnt", F.lit(None).cast("long"))
        .withColumn("max_drvr_age", F.lit(None).cast("long"))
        .withColumn("min_drvr_age", F.lit(None).cast("long"))
        .withColumn("avg_drvr_age", F.lit(None).cast("long"))
        .withColumn("prem_change_amt", F.lit(None).cast("double"))
    )
    # Policies with NO existing state row simply have no prior_state row at all -- lag()
    # naturally returns NULL for their first transaction, handled by the same
    # F.coalesce(..., F.array()) / F.coalesce(..., F.create_map()) pattern used below,
    # exactly like "first transaction ever" behaved in the original full-history design.

    prior_state_for_union = prior_state.select(*txn_keys, *snapshot_cols, "IS_STATE_ROW")
    new_snapshot_for_union = new_snapshot.select(*txn_keys, *snapshot_cols, "IS_STATE_ROW")

    combined = prior_state_for_union.unionByName(new_snapshot_for_union)

    # ── LAG layer: prior state (if any) then this batch's new txns, in order --
    #    same window mechanism as the original design, now over a handful of rows per
    #    policy instead of its entire history. TRANS_ID is a secondary sort key purely to
    #    keep ordering deterministic on a SRC_TRANS_TMSP tie -- same defensive tie-break the
    #    original per-event design used (`orderBy("SRC_TRANS_TMSP", "TRANS_ID")`). ──
    w_asc = Window.partitionBy("AUTO_POLICY_ID").orderBy(
        F.col("IS_STATE_ROW").desc(), F.col("SRC_TRANS_TMSP").asc(), F.col("TRANS_ID").asc())

    txn_lag = (
        combined
        .withColumn("prev_vin_set",      F.lag("vin_set").over(w_asc))
        .withColumn("prev_drvr_id_set",  F.lag("drvr_id_set").over(w_asc))
        .withColumn("prev_gndr_map",     F.lag("gndr_map").over(w_asc))
        .withColumn("prev_mrtl_map",     F.lag("mrtl_map").over(w_asc))
        .withColumn("prev_comp_ded_map", F.lag("comp_ded_map").over(w_asc))
        .withColumn("prev_coll_ded_map", F.lag("coll_ded_map").over(w_asc))
    )
    for cat in CVG_CATEGORIES:
        txn_lag = txn_lag.withColumn(f"prev_{cat}_key_set", F.lag(f"{cat}_key_set").over(w_asc))

    # veh/drvr "added" = count of genuinely NEW vin/drvr_id_sk values vs the previous
    # transaction (array_except, not a net count delta) -- identical formulas to the
    # original design.
    txn_lag = (
        txn_lag
        .withColumn("drvrs_added_latest_txn",
                    F.size(F.array_except(F.coalesce(F.col("drvr_id_set"), F.array()),
                                           F.coalesce(F.col("prev_drvr_id_set"), F.array()))))
        .withColumn("veh_added_latest_txn",
                    F.size(F.array_except(F.coalesce(F.col("vin_set"), F.array()),
                                           F.coalesce(F.col("prev_vin_set"), F.array()))))
        .withColumn("gndr_change_ind",        map_change_ind("gndr_map", "prev_gndr_map"))
        .withColumn("mrtl_change_ind",        map_change_ind("mrtl_map", "prev_mrtl_map"))
        .withColumn("comp_ded_change_ind",    map_change_ind("comp_ded_map", "prev_comp_ded_map"))
        .withColumn("coll_ded_change_ind",    map_change_ind("coll_ded_map", "prev_coll_ded_map"))
    )

    for cat in CVG_CATEGORIES:
        cur_set, prev_set = f"{cat}_key_set", f"prev_{cat}_key_set"
        txn_lag = (
            txn_lag
            .withColumn(f"{cat}_coverage_added",
                        (F.size(F.array_except(F.coalesce(F.col(cur_set), F.array()),
                                                F.coalesce(F.col(prev_set), F.array()))) > 0).cast("int"))
            .withColumn(f"{cat}_coverage_removed",
                        (F.size(F.array_except(F.coalesce(F.col(prev_set), F.array()),
                                                F.coalesce(F.col(cur_set), F.array()))) > 0).cast("int"))
        )

    # Only real new transactions from here on -- the synthetic state rows have done their
    # job feeding the lag() chain and are dropped before anything gets written out.
    txn_lag = txn_lag.filter(F.col("IS_STATE_ROW") == False).drop("IS_STATE_ROW")

    # ── HISTORY (GROUP_A) layer: state's bounded recent-timestamp list + this batch's new
    #    timestamps -- NOT a full RAW_POLICY_EVENTS re-read. Same "everyone processed in
    #    this batch gets the same count, right now" semantics the original design had. ──
    state_tmsps = prior_state.select("AUTO_POLICY_ID", F.explode_outer("state_recent_tmsps").alias("TMSP"))
    new_tmsps   = new_events.select("AUTO_POLICY_ID", F.col("SRC_TRANS_TMSP").alias("TMSP"))
    all_recent_tmsps = state_tmsps.unionByName(new_tmsps).filter(F.col("TMSP").isNotNull())

    hist_agg = (
        all_recent_tmsps.groupBy("AUTO_POLICY_ID")
        .agg(
            F.sum(F.when(F.col("TMSP") >= F.expr("current_timestamp() - interval 1 day"), 1)
                   .otherwise(0)).alias("txn_cnt_1d"),
            F.sum(F.when(F.col("TMSP") >= F.expr("current_timestamp() - interval 7 days"), 1)
                   .otherwise(0)).alias("txn_cnt_1w"),
            F.sum(F.when(F.col("TMSP") >= F.expr("current_timestamp() - interval 1 month"), 1)
                   .otherwise(0)).alias("txn_cnt_1m"),
        )
    )

    inception_agg = (
        new_events.groupBy("AUTO_POLICY_ID").agg(F.min("EFF_DT").alias("batch_min_eff_dt"))
        .join(prior_state.select("AUTO_POLICY_ID", "state_inception_eff_dt"), "AUTO_POLICY_ID", "left")
        .withColumn("policy_inception_eff_dt",
                    F.coalesce(F.col("state_inception_eff_dt"), F.col("batch_min_eff_dt")))
        .select("AUTO_POLICY_ID", "policy_inception_eff_dt")
    )

    # ── Final: only newly-landed TRANS_IDs, GROUP_A + GROUP_B side by side ──
    final = (
        txn_lag
        .withColumn("outstanding_txn_ind", (F.col("EFF_DT") > F.current_date()).cast("int"))
        .join(hist_agg, "AUTO_POLICY_ID", "left")
        .join(inception_agg, "AUTO_POLICY_ID", "left")
        .withColumn("tenure_yrs", F.floor(F.months_between(F.current_date(), F.col("policy_inception_eff_dt")) / 12))
        .select(
            "TRANS_ID", "AUTO_POLICY_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM",
            "SRC_TRANS_TMSP", "EFF_DT",
            # GROUP_A
            "txn_cnt_1d", "txn_cnt_1w", "txn_cnt_1m", "outstanding_txn_ind", "tenure_yrs",
            # GROUP_B
            "veh_cnt", "avg_veh_age", "veh_added_latest_txn",
            "drvr_cnt", "max_drvr_age", "min_drvr_age", "avg_drvr_age", "drvrs_added_latest_txn",
            "prem_change_amt",
            *[c for cat in CVG_CATEGORIES for c in (f"{cat}_coverage_added", f"{cat}_coverage_removed")],
            "comp_ded_change_ind", "coll_ded_change_ind", "gndr_change_ind", "mrtl_change_ind",
        )
        .withColumn("COMPUTED_AT", F.current_timestamp())
    )

    # Rename to match COMPUTED_FEATURE_EVENTS DDL exactly (uppercase columns)
    rename_map = {c: c.upper() for c in final.columns if c != c.upper()}
    for old, new in rename_map.items():
        final = final.withColumnRenamed(old, new)

    written = final.count()
    if written == 0:
        print(f"[batch {batch_id}] nothing to write (all new events failed to join back).")
        return

    final.write.format("delta").mode("append").saveAsTable(COMPUTED)

    for row in final.select("TRANS_ID", "AUTO_POLICY_ID", "VEH_CNT", "DRVR_CNT",
                             "PREM_CHANGE_AMT", "TXN_CNT_1D", "OUTSTANDING_TXN_IND").collect():
        print(f"  [{row['TRANS_ID']}] policy={row['AUTO_POLICY_ID']} | veh_cnt={row['VEH_CNT']} | "
              f"drvr_cnt={row['DRVR_CNT']} | prem_change={row['PREM_CHANGE_AMT']} | "
              f"txn_cnt_1d={row['TXN_CNT_1D']} | outstanding={row['OUTSTANDING_TXN_IND']}")

    print(f"\n[batch {batch_id}] wrote {written} row(s) to COMPUTED_FEATURE_EVENTS.")

    # ── Batched state write-back: ONE MERGE for the whole micro-batch, not one per event ──
    _update_snapshot_state(txn_lag, new_events, prior_state, inception_agg)


def _update_snapshot_state(txn_lag, new_events, prior_state, inception_agg):
    """Each touched policy's new state = its LAST new transaction in this batch, by time.
    (If a policy had only one new transaction this batch -- the common case -- this is just
    that transaction's snapshot.)"""
    w_last = Window.partitionBy("AUTO_POLICY_ID").orderBy(
        F.col("SRC_TRANS_TMSP").desc(), F.col("TRANS_ID").desc())
    latest_snapshot = (
        txn_lag
        .withColumn("_rn", F.row_number().over(w_last))
        .filter(F.col("_rn") == 1)
        .select("AUTO_POLICY_ID", "TRANS_ID",
                "vin_set", "drvr_id_set", "gndr_map", "mrtl_map", "comp_ded_map", "coll_ded_map",
                *[f"{cat}_key_set" for cat in CVG_CATEGORIES])
    )

    # Prune RECENT_TXN_TMSPS to the trailing window for the write-back (state's old list +
    # this batch's new timestamps, filtered) -- keeps the state table's per-policy size
    # bounded regardless of how long the policy has existed.
    state_tmsps = prior_state.select("AUTO_POLICY_ID", F.explode_outer("state_recent_tmsps").alias("TMSP"))
    new_tmsps   = new_events.select("AUTO_POLICY_ID", F.col("SRC_TRANS_TMSP").alias("TMSP"))
    pruned_tmsps = (
        state_tmsps.unionByName(new_tmsps)
        .filter(F.col("TMSP").isNotNull())
        .filter(F.col("TMSP") >= F.expr(f"current_timestamp() - interval {RECENT_TMSP_WINDOW_DAYS} days"))
        .groupBy("AUTO_POLICY_ID")
        .agg(F.collect_set("TMSP").alias("RECENT_TXN_TMSPS"))
    )

    new_state = (
        latest_snapshot
        .join(pruned_tmsps, "AUTO_POLICY_ID", "left")
        .join(inception_agg, "AUTO_POLICY_ID", "left")
        .select(
            "AUTO_POLICY_ID",
            F.col("vin_set").alias("VIN_SET"),
            F.col("drvr_id_set").alias("DRVR_ID_SET"),
            F.col("gndr_map").alias("GNDR_MAP"),
            F.col("mrtl_map").alias("MRTL_MAP"),
            F.col("comp_ded_map").alias("COMP_DED_MAP"),
            F.col("coll_ded_map").alias("COLL_DED_MAP"),
            F.col("BI_key_set").alias("BI_KEY_SET"),
            F.col("PD_key_set").alias("PD_KEY_SET"),
            F.col("MD_key_set").alias("MD_KEY_SET"),
            F.col("COLL_key_set").alias("COLL_KEY_SET"),
            F.col("COMP_key_set").alias("COMP_KEY_SET"),
            F.col("PIP_key_set").alias("PIP_KEY_SET"),
            F.coalesce(F.col("RECENT_TXN_TMSPS"), F.array()).alias("RECENT_TXN_TMSPS"),
            F.col("policy_inception_eff_dt").alias("POLICY_INCEPTION_EFF_DT"),
            F.col("TRANS_ID").alias("LAST_TRANS_ID"),
            F.current_timestamp().alias("STATE_UPDATED_AT"),
        )
    )

    new_state.createOrReplaceTempView("_new_state_batch")

    spark.sql(f"""
        MERGE INTO {STATE} AS t
        USING _new_state_batch AS s
        ON t.AUTO_POLICY_ID = s.AUTO_POLICY_ID
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)
    print(f"  Batched MERGE: updated snapshot state for {new_state.count()} polic(y/ies).")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Start Streaming from RAW_POLICY_EVENTS via CDF

# COMMAND ----------

query = (
    spark.readStream
         .format("delta")
         .option("readChangeFeed",  "true")
         .option("startingVersion", "0")
         .table(RAW_EVENTS)
         .writeStream
         .foreachBatch(compute_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nPySpark compute — finished.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== COMPUTED_FEATURE_EVENTS ===")
display(spark.table(COMPUTED).orderBy("COMPUTED_AT"))

print("=== AUTO_POLICY_SNAPSHOT_STATE (sample) ===")
display(spark.table(STATE).orderBy("STATE_UPDATED_AT", ascending=False).limit(20))

print("\n>>> Next: Run 05_routing_pipeline <<<")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) AS computed_rows FROM workspace.featurestore_test.COMPUTED_FEATURE_EVENTS;
# MAGIC -- SELECT COUNT(*) AS state_rows FROM workspace.featurestore_test.AUTO_POLICY_SNAPSHOT_STATE;
# MAGIC

# COMMAND ----------

