# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC # 05 — Routing Pipeline [OPTIMIZED — batch-wide, not per-event]
# MAGIC
# MAGIC Reads COMPUTED_FEATURE_EVENTS via CDF stream, same as the original design. The
# MAGIC difference is *how* a micro-batch gets processed: instead of collecting every event to
# MAGIC the driver and looping through them one at a time (each issuing ~4 sequential
# MAGIC `spark.sql()` calls), this version generates all `AUTO_FEATURES_HISTORY` rows for the
# MAGIC whole batch in one window-function pass, and does one `MERGE` per feature group into
# MAGIC `AUTO_FEATURES_ACTIVE` / `AUTO_FEATURES_PENDING` for the whole batch — the same batched
# MAGIC shape `06_job_daily_promotion.py` already uses. See `ARCHITECTURE.md` for the full design.
# MAGIC
# MAGIC **`AUTO_FEATURES_HISTORY` still gets exactly one row per individual transaction** — this
# MAGIC redesign changes how those rows get computed, not how many there are.
# MAGIC
# MAGIC ## The mechanism, step by step
# MAGIC 1. Per (event, feature group): immediate vs pending — same registry-driven rule as before,
# MAGIC    now evaluated for the whole batch at once (cheap, vectorized — never the bottleneck).
# MAGIC 2. Collapse multiple immediate groups on the SAME event into one closing point:
# MAGIC    `earliest_eff = MIN(effective date across that event's immediate groups)` — same rule
# MAGIC    that avoided the negative-validity-window bug in the original per-event design.
# MAGIC 3. **`AUTO_FEATURES_ACTIVE`**: one `MERGE` per feature group, using each policy's LATEST
# MAGIC    immediate event in the batch. Delta's own column-level `UPDATE SET` semantics leave
# MAGIC    other groups' columns untouched automatically — no extra logic needed for that.
# MAGIC 4. **`AUTO_FEATURES_HISTORY`**: trickier. Each history row must be a FULL point-in-time
# MAGIC    snapshot of every column (not just the columns that changed on that specific event) —
# MAGIC    same as the original design. If a policy has two triggering transactions in the SAME
# MAGIC    micro-batch, and the first only changes GROUP_A while the second only changes GROUP_B,
# MAGIC    the first row's snapshot must still show GROUP_B's *old* value, and the second row's
# MAGIC    snapshot must carry forward the first row's *new* GROUP_A value. This is a running
# MAGIC    "last known value per column" computation — solved by unioning in the OLD (pre-batch)
# MAGIC    `ACTIVE` row as a sentinel baseline, then `last(col, ignorenulls=True)` over a running
# MAGIC    window ordered by effective date. `lead()` on that same ordering gives each row's
# MAGIC    `VALID_TRANSACTION_TO` (the next row's start, minus 1ms) — including the sentinel row's
# MAGIC    own `lead()`, which is exactly the boundary needed to close the OLD `IS_CURRENT` row.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from datetime import datetime

dbutils.widgets.text("catalog",         "workspace")
dbutils.widgets.text("schema",          "featurestore_test")
dbutils.widgets.text("checkpoint_path", "/Volumes/workspace/featurestore_test/checkpoints/routing_v2")
dbutils.widgets.text("sim_date",        "")   # YYYY-MM-DD HH:MM:SS or blank for real time

CATALOG         = dbutils.widgets.get("catalog")
SCHEMA          = dbutils.widgets.get("schema")
CHECKPOINT_PATH = dbutils.widgets.get("checkpoint_path")
_sim            = dbutils.widgets.get("sim_date").strip()

if _sim:
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            EFFECTIVE_TS = datetime.strptime(_sim, fmt)
            break
        except ValueError:
            continue
    else:
        raise ValueError(f"Cannot parse sim_date '{_sim}'. Use YYYY-MM-DD HH:MM:SS")
    print(f"Routing date : {EFFECTIVE_TS}  ← sim_date override")
else:
    EFFECTIVE_TS = datetime.now()
    print(f"Routing date : {EFFECTIVE_TS}  ← real current_timestamp()")

COMPUTED = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"
ACTIVE   = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
PENDING  = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_PENDING"
HISTORY  = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"
REGISTRY = f"{CATALOG}.{SCHEMA}.FEATURE_GROUP_REGISTRY"

# COMMAND ----------

# MAGIC %md
# MAGIC ## foreachBatch — Registry-Driven, Batch-Wide Routing

# COMMAND ----------

def process_micro_batch(df, batch_id):
    import traceback
    try:
        df = df.filter(F.col("_change_type") == "insert")
        count = df.count()
        print(f"\n[batch {batch_id}] {count} computed event(s)")
        if count == 0:
            return

        registry = spark.table(REGISTRY).collect()
        group_names = [reg["FEATURE_GROUP"] for reg in registry]

        # ── Step 1: per (event, feature group) -- immediate vs pending, for the WHOLE batch ──
        group_routing = None
        for reg in registry:
            group      = reg["FEATURE_GROUP"]
            is_always_immediate = reg["ROUTING_TYPE"] == "immediate"
            eff_col    = reg["EFFECTIVE_DATE_COL"]

            g = (
                df.select("TRANS_ID", "AUTO_POLICY_ID", F.col(eff_col).alias("group_eff_dt"))
                .withColumn("FEATURE_GROUP", F.lit(group))
                .withColumn("IS_IMMEDIATE",
                            F.lit(is_always_immediate) | (F.col("group_eff_dt") <= F.lit(EFFECTIVE_TS)))
            )
            group_routing = g if group_routing is None else group_routing.unionByName(g)

        immediate_by_event = group_routing.filter("IS_IMMEDIATE")
        pending_by_event   = group_routing.filter("NOT IS_IMMEDIATE")

        # ── Step 2: collapse multiple immediate groups on the SAME event into one closing
        #    point -- earliest effective date across that event's immediate groups. This is
        #    exactly the rule the original per-event design used to avoid the
        #    negative-validity-window bug (e.g. new business where SRC_TRANS_TMSP == EFF_DT). ──
        closing_meta = (
            immediate_by_event.groupBy("TRANS_ID", "AUTO_POLICY_ID")
            .agg(F.min("group_eff_dt").alias("earliest_eff"),
                 F.concat_ws(",", F.collect_set("FEATURE_GROUP")).alias("CHANGED_FEATURE_GROUP"))
        )

        # Which (event, group) pairs are immediate -- pivoted to wide flag columns, kept
        # separately from the masked feature values so ACTIVE's per-group merge below can
        # filter cleanly without guessing from null-ness of a feature value.
        immediate_flags = (
            immediate_by_event.groupBy("TRANS_ID", "AUTO_POLICY_ID")
            .pivot("FEATURE_GROUP", group_names)
            .agg(F.lit(True))
        )
        for group in group_names:
            immediate_flags = immediate_flags.withColumnRenamed(group, f"_is_immediate_{group}")

        # ── Step 3 setup: closing_rows = events with >=1 immediate group, with each group's
        #    OWNED_COLUMNS nulled out on rows where that specific group ISN'T immediate for
        #    THAT event -- so the carry-forward step below correctly reuses the prior value
        #    for any group not touched by a given event. ──
        closing_rows = (
            df.join(closing_meta, ["TRANS_ID", "AUTO_POLICY_ID"], "inner")
              .join(immediate_flags, ["TRANS_ID", "AUTO_POLICY_ID"], "left")
        )

        for reg in registry:
            group      = reg["FEATURE_GROUP"]
            owned_cols = reg["OWNED_COLUMNS"]
            flag_col   = F.col(f"_is_immediate_{group}").isNotNull()
            for c in owned_cols:
                closing_rows = closing_rows.withColumn(c, F.when(flag_col, F.col(c)).otherwise(F.lit(None)))
            closing_rows = closing_rows.withColumn(
                f"{group}_UPDATED_AT",
                F.when(flag_col, F.current_timestamp()).otherwise(F.lit(None).cast("timestamp"))
            )

        closing_rows = (
            closing_rows
            .withColumn("LAST_SOURCE_EVENT_ID", F.col("TRANS_ID"))
            .withColumn("FEATURE_UPDATED_AT", F.current_timestamp())
            .withColumn("IS_SENTINEL", F.lit(False))
        )

        active_cols = ["AUTO_POLICY_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM", "TRANS_ID"]
        for reg in registry:
            active_cols += reg["OWNED_COLUMNS"] + [f"{reg['FEATURE_GROUP']}_UPDATED_AT"]
        active_cols += ["FEATURE_UPDATED_AT", "LAST_SOURCE_EVENT_ID"]

        closing_rows = closing_rows.select(*active_cols, "earliest_eff", "CHANGED_FEATURE_GROUP", "IS_SENTINEL")

        # ── Step 4a: read the OLD (pre-batch) ACTIVE row for touched policies -- BEFORE any
        #    writes happen this batch -- as the carry-forward baseline. A policy with no prior
        #    ACTIVE row (brand new, first transaction(s) all in this batch) simply has no
        #    sentinel row; carry-forward then has nothing to reuse for an untouched group,
        #    same as the original per-event design leaving those columns NULL on first insert. ──
        touched_with_immediate = closing_meta.select("AUTO_POLICY_ID").distinct()

        old_active_sentinel = (
            spark.table(ACTIVE)
            .join(F.broadcast(touched_with_immediate), "AUTO_POLICY_ID", "inner")
            .select(*active_cols)
            .withColumn("earliest_eff", F.lit(None).cast("timestamp"))
            .withColumn("CHANGED_FEATURE_GROUP", F.lit(None).cast("string"))
            .withColumn("IS_SENTINEL", F.lit(True))
        )

        # ── Step 4b: union sentinel + closing rows, carry forward every column's last known
        #    non-null value, and compute each row's validity window via lead(). ──
        combined = old_active_sentinel.unionByName(closing_rows)

        # TRANS_ID is a secondary sort key purely to keep ordering deterministic if two
        # closing events for the same policy tie on earliest_eff -- same defensive tie-break
        # the original per-event design used (`orderBy("SRC_TRANS_TMSP", "TRANS_ID")`).
        w_running = (
            Window.partitionBy("AUTO_POLICY_ID")
            .orderBy(F.col("IS_SENTINEL").desc(), F.col("earliest_eff").asc(), F.col("TRANS_ID").asc())
            .rowsBetween(Window.unboundedPreceding, Window.currentRow)
        )
        carry_forward_cols = []
        for reg in registry:
            carry_forward_cols += reg["OWNED_COLUMNS"] + [f"{reg['FEATURE_GROUP']}_UPDATED_AT"]

        for c in carry_forward_cols:
            combined = combined.withColumn(c, F.last(F.col(c), ignorenulls=True).over(w_running))

        w_order = Window.partitionBy("AUTO_POLICY_ID").orderBy(
            F.col("IS_SENTINEL").desc(), F.col("earliest_eff").asc(), F.col("TRANS_ID").asc())
        combined = (
            combined
            .withColumn("next_eff", F.lead("earliest_eff").over(w_order))
            .withColumn("VALID_TRANSACTION_TO",
                        F.when(F.col("next_eff").isNotNull(),
                               F.col("next_eff") - F.expr("INTERVAL 1 MILLISECOND")))
            .withColumn("IS_CURRENT", F.col("next_eff").isNull())
        )

        # ── Step 5: ONE batched close of old IS_CURRENT rows -- the sentinel's own next_eff
        #    IS exactly "the first real closing event's earliest_eff", which is the correct
        #    close boundary for whatever was current before this batch. Same MERGE-based
        #    per-policy-close pattern 06_job_daily_promotion.py already uses. ──
        close_boundaries = (
            combined.filter(F.col("IS_SENTINEL") & F.col("next_eff").isNotNull())
            .select("AUTO_POLICY_ID", F.col("VALID_TRANSACTION_TO").alias("close_to"))
        )

        if close_boundaries.limit(1).count() > 0:
            close_boundaries.createOrReplaceTempView("_close_boundaries")
            spark.sql(f"""
                MERGE INTO {HISTORY} AS h
                USING _close_boundaries AS s
                ON h.AUTO_POLICY_ID = s.AUTO_POLICY_ID AND h.IS_CURRENT = true
                WHEN MATCHED THEN UPDATE SET
                    h.IS_CURRENT           = false,
                    h.VALID_TRANSACTION_TO = s.close_to
            """)
            print(f"  Step 5: Closed IS_CURRENT history rows for {close_boundaries.count()} polic(y/ies).")

        # ── Step 6: ONE batched INSERT of every new HISTORY row for this batch -- still one
        #    row per individual transaction, just computed for the whole batch at once. ──
        new_history_rows = (
            combined.filter(~F.col("IS_SENTINEL"))
            .withColumn("SNAPSHOT_AT", F.current_timestamp())
            .withColumn("REASON", F.lit("immediate_merge"))
            .withColumn("EVENT_ID", F.col("TRANS_ID"))
            .withColumn("VALID_TRANSACTION_FROM", F.col("earliest_eff"))
            .select(*active_cols, "SNAPSHOT_AT", "REASON", "EVENT_ID", "CHANGED_FEATURE_GROUP",
                    "VALID_TRANSACTION_FROM", "VALID_TRANSACTION_TO", "IS_CURRENT")
        )
        new_history_rows.write.format("delta").mode("append").saveAsTable(HISTORY)
        print(f"  Step 6: Inserted {new_history_rows.count()} row(s) into AUTO_FEATURES_HISTORY "
              f"(one per transaction).")

        # ── Step 7: ONE MERGE per feature group into ACTIVE, whole batch at once -- Delta's
        #    own column-level UPDATE SET semantics leave other groups' columns untouched, so
        #    no carry-forward is needed here (only HISTORY's point-in-time snapshots needed it). ──
        for reg in registry:
            group      = reg["FEATURE_GROUP"]
            owned_cols = reg["OWNED_COLUMNS"]
            updated_at_col = f"{group}_UPDATED_AT"

            group_latest = (
                closing_rows.filter(F.col(f"{group}_UPDATED_AT").isNotNull())
                .withColumn("_rn", F.row_number().over(
                    Window.partitionBy("AUTO_POLICY_ID")
                    .orderBy(F.col("earliest_eff").desc(), F.col("TRANS_ID").desc())))
                .filter(F.col("_rn") == 1)
                .select("AUTO_POLICY_ID", "TRANS_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM", *owned_cols)
            )

            if group_latest.limit(1).count() == 0:
                print(f"  Step 7: [{group}] no immediate events this batch — skipped.")
                continue

            group_latest.createOrReplaceTempView("_group_latest")
            set_clause  = ", ".join(f"t.{c} = s.{c}" for c in owned_cols)
            insert_cols = ", ".join(owned_cols)
            insert_vals = ", ".join(f"s.{c}" for c in owned_cols)

            spark.sql(f"""
                MERGE INTO {ACTIVE} AS t
                USING _group_latest AS s
                ON t.AUTO_POLICY_ID = s.AUTO_POLICY_ID
                WHEN MATCHED THEN UPDATE SET
                    {set_clause},
                    t.PLCY_CNTRCT_NUM       = s.PLCY_CNTRCT_NUM,
                    t.SRC_HH_NUM            = s.SRC_HH_NUM,
                    t.TRANS_ID               = s.TRANS_ID,
                    t.{updated_at_col}       = current_timestamp(),
                    t.FEATURE_UPDATED_AT     = current_timestamp(),
                    t.LAST_SOURCE_EVENT_ID   = s.TRANS_ID
                WHEN NOT MATCHED THEN INSERT (
                    AUTO_POLICY_ID, TRANS_ID, PLCY_CNTRCT_NUM, SRC_HH_NUM, {insert_cols}, {updated_at_col},
                    FEATURE_UPDATED_AT, LAST_SOURCE_EVENT_ID
                ) VALUES (
                    s.AUTO_POLICY_ID, s.TRANS_ID, s.PLCY_CNTRCT_NUM, s.SRC_HH_NUM, {insert_vals}, current_timestamp(),
                    current_timestamp(), s.TRANS_ID
                )
            """)
            print(f"  Step 7: [{group}] merged {len(owned_cols)} column(s) into ACTIVE "
                  f"for {group_latest.count()} polic(y/ies).")

        # ── Step 8: ONE MERGE per feature group into PENDING, whole batch at once. ──
        for reg in registry:
            group      = reg["FEATURE_GROUP"]
            owned_cols = reg["OWNED_COLUMNS"]

            group_pending = (
                pending_by_event.filter(F.col("FEATURE_GROUP") == group)
                .join(df.select("TRANS_ID", "AUTO_POLICY_ID", *owned_cols), ["TRANS_ID", "AUTO_POLICY_ID"], "inner")
                .select("AUTO_POLICY_ID", "TRANS_ID", *owned_cols, F.col("group_eff_dt").alias("EFFECTIVE_DATE"))
            )

            if group_pending.limit(1).count() == 0:
                continue

            group_pending.createOrReplaceTempView("_group_pending")
            set_clause  = ", ".join(f"t.{c} = s.{c}" for c in owned_cols)
            insert_cols = ", ".join(owned_cols)
            insert_vals = ", ".join(f"s.{c}" for c in owned_cols)

            spark.sql(f"""
                MERGE INTO {PENDING} AS t
                USING _group_pending AS s
                ON  t.AUTO_POLICY_ID  = s.AUTO_POLICY_ID
                AND t.SOURCE_EVENT_ID = s.TRANS_ID
                WHEN MATCHED THEN UPDATE SET
                    {set_clause},
                    t.EVENT_RECEIVED_AT = current_timestamp()
                WHEN NOT MATCHED THEN INSERT (
                    AUTO_POLICY_ID, TRANS_ID, {insert_cols}, EFFECTIVE_DATE, CHANGED_FEATURE_GROUP,
                    SOURCE_EVENT_ID, EVENT_RECEIVED_AT
                ) VALUES (
                    s.AUTO_POLICY_ID, s.TRANS_ID, {insert_vals}, s.EFFECTIVE_DATE, '{group}',
                    s.TRANS_ID, current_timestamp()
                )
            """)
            print(f"  Step 8: [{group}] merged {group_pending.count()} row(s) into PENDING.")

        print(f"\n[batch {batch_id}] done.")

    except Exception as e:
        print(f"[ERROR] batch {batch_id}: {e}")
        traceback.print_exc()
        raise

# COMMAND ----------

# MAGIC %md
# MAGIC ## Start Streaming from COMPUTED_FEATURE_EVENTS via CDF

# COMMAND ----------

query = (
    spark.readStream
         .format("delta")
         .option("readChangeFeed", "true")
         .option("startingVersion", "0")
         .table(COMPUTED)
         .writeStream
         .foreachBatch(process_micro_batch)
         .option("checkpointLocation", CHECKPOINT_PATH)
         .trigger(availableNow=True)
         .start()
)

query.awaitTermination()
print("\nRouting pipeline finished.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== AUTO_FEATURES_ACTIVE ===")
display(spark.table(ACTIVE).orderBy("AUTO_POLICY_ID"))

print("=== AUTO_FEATURES_PENDING (future-dated) ===")
display(spark.table(PENDING).orderBy("EFFECTIVE_DATE"))

print("=== AUTO_FEATURES_HISTORY (all snapshots) ===")
display(spark.table(HISTORY).orderBy("AUTO_POLICY_ID", "VALID_TRANSACTION_FROM"))

# COMMAND ----------



spark.sql("select count(*) from workspace.featurestore_test.AUTO_FEATURES_ACTIVE").show()

# COMMAND ----------

