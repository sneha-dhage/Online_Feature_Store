# Databricks notebook source
# MAGIC %md
# MAGIC # Bootstrap AUTO_POLICY_SNAPSHOT_STATE (one-time migration)
# MAGIC
# MAGIC Run this **once**, before relying on the optimized `04_sp_compute_features.py`, if this
# MAGIC schema already has transaction history in `RAW_POLICY_EVENTS`. It seeds
# MAGIC `AUTO_POLICY_SNAPSHOT_STATE` with every existing policy's true current snapshot, computed
# MAGIC the same way the *original* (full-history-reread) `04` design always did it.
# MAGIC
# MAGIC **This is the last time that expensive full-history computation ever runs.** After this,
# MAGIC `04` only ever reads new events plus this state table — never `RAW_POLICY_EVENTS`'s full
# MAGIC history again.
# MAGIC
# MAGIC Safe to re-run — `MERGE`-based, idempotent, overwrites rather than appends.
# MAGIC
# MAGIC Brand-new policies with no prior transactions need no bootstrap at all; their first real
# MAGIC transaction creates their first state row naturally via `04`'s own batched `MERGE`.
# MAGIC
# MAGIC If this is a fresh schema with no history yet (a brand-new deployment), skip this
# MAGIC notebook entirely — there's nothing to bootstrap.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, ArrayType

dbutils.widgets.text("catalog", "main")
dbutils.widgets.text("schema",  "final_database")

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")

RAW_EVENTS = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
STATE      = f"{CATALOG}.{SCHEMA}.AUTO_POLICY_SNAPSHOT_STATE"

CVG_CATEGORIES = ["BI", "PD", "MD", "COLL", "COMP", "PIP"]
RECENT_TMSP_WINDOW_DAYS = 35

# COMMAND ----------
# MAGIC %md
# MAGIC ## JSON Schema (same as 04_sp_compute_features.py)

# COMMAND ----------

VEHICLE_SCHEMA = StructType([
    StructField("vin",               StringType()),
    StructField("mdl_yr",            IntegerType()),
    StructField("auto_soi_trans_sk", StringType()),
])

DRIVER_SCHEMA = StructType([
    StructField("drvr_id_sk",   StringType()),
    StructField("drvr_brth_dt", StringType()),
    StructField("drvr_gndr_cd", StringType()),
    StructField("drvr_mrtl_cd", StringType()),
])

COVERAGE_SCHEMA = StructType([
    StructField("auto_soi_trans_sk",       StringType()),
    StructField("mva_cvg_ctgy_cd",         StringType()),
    StructField("cvg_typ_cd",              StringType()),
    StructField("ded_amt",                 DoubleType()),
    StructField("old_full_term_prem_amt",  DoubleType()),
    StructField("new_full_term_prem_amt",  DoubleType()),
])

ARRAYS_SCHEMA = StructType([
    StructField("1_vehicle_snapshot",  ArrayType(VEHICLE_SCHEMA)),
    StructField("2_driver_snapshot",   ArrayType(DRIVER_SCHEMA)),
    StructField("3_coverage_snapshot", ArrayType(COVERAGE_SCHEMA)),
])

# COMMAND ----------
# MAGIC %md
# MAGIC ## Full-history read — the one and only time this runs

# COMMAND ----------

total_policies = spark.table(RAW_EVENTS).select("AUTO_POLICY_ID").distinct().count()
print(f"Bootstrapping snapshot state from full RAW_POLICY_EVENTS history "
      f"({total_policies} polic(y/ies) with existing transactions)...")
print("This is the ONLY time this full-history computation runs -- 04 stays incremental after this.")

txn_keys = ["TRANS_ID", "AUTO_POLICY_ID", "PLCY_CNTRCT_NUM", "SRC_HH_NUM", "EFF_DT", "SRC_TRANS_TMSP"]

txn_base = (
    spark.table(RAW_EVENTS)
    .withColumn("arrays", F.from_json(F.col("RAW_PAYLOAD"), ARRAYS_SCHEMA))
    .select(*txn_keys,
            F.col("arrays.`1_vehicle_snapshot`").alias("vehicles"),
            F.col("arrays.`2_driver_snapshot`").alias("drivers"),
            F.col("arrays.`3_coverage_snapshot`").alias("coverages"))
)

df_veh = (
    txn_base.select(*txn_keys, F.explode_outer("vehicles").alias("v"))
    .select(*txn_keys,
            F.col("v.vin").alias("vin"),
            F.col("v.mdl_yr").alias("mdl_yr"),
            F.col("v.auto_soi_trans_sk").alias("auto_soi_trans_sk"))
)

df_drv = (
    txn_base.select(*txn_keys, F.explode_outer("drivers").alias("d"))
    .select(*txn_keys,
            F.col("d.drvr_id_sk").alias("drvr_id_sk"),
            F.col("d.drvr_gndr_cd").alias("drvr_gndr_cd"),
            F.col("d.drvr_mrtl_cd").alias("drvr_mrtl_cd"))
)

df_cvg = (
    txn_base.select(*txn_keys, F.explode_outer("coverages").alias("c"))
    .select(*txn_keys,
            F.col("c.auto_soi_trans_sk").alias("auto_soi_trans_sk"),
            F.col("c.mva_cvg_ctgy_cd").alias("cvg_ctgy"),
            F.col("c.cvg_typ_cd").alias("cvg_typ_cd"),
            F.col("c.ded_amt").alias("ded_amt"))
    .join(df_veh.select("TRANS_ID", "auto_soi_trans_sk", "vin"),
          on=["TRANS_ID", "auto_soi_trans_sk"], how="left")
)

# ── Snapshot aggregates per transaction (only the fields AUTO_POLICY_SNAPSHOT_STATE needs --
#    no need to compute veh_cnt/avg_veh_age/etc. here, those are re-derived per-event by 04
#    going forward, this table only needs the raw sets/maps used for lag comparison) ──
agg_veh = df_veh.groupBy(*txn_keys).agg(F.collect_set("vin").alias("vin_set"))

agg_drv = (
    df_drv.groupBy(*txn_keys)
    .agg(
        F.map_from_entries(F.collect_list(
            F.struct(F.col("drvr_id_sk").cast("string"), F.col("drvr_gndr_cd")))).alias("gndr_map"),
        F.map_from_entries(F.collect_list(
            F.struct(F.col("drvr_id_sk").cast("string"), F.col("drvr_mrtl_cd")))).alias("mrtl_map"),
        F.collect_set(F.col("drvr_id_sk").cast("string")).alias("drvr_id_set"),
    )
)

df_cvg_scoped = (
    df_cvg.filter(F.col("cvg_ctgy").isin(CVG_CATEGORIES))
          .withColumn("cvg_key", F.concat_ws("|", F.col("vin"), F.col("cvg_typ_cd")))
)

agg_cvg = (
    df_cvg_scoped.groupBy(*txn_keys)
    .agg(
        *[F.collect_set(F.when(F.col("cvg_ctgy") == cat, F.col("cvg_key"))).alias(f"{cat}_key_set")
          for cat in CVG_CATEGORIES],
        F.map_from_entries(F.collect_list(
            F.when(F.col("cvg_ctgy") == "COMP", F.struct(F.col("cvg_key"), F.col("ded_amt")))
        )).alias("comp_ded_map"),
        F.map_from_entries(F.collect_list(
            F.when(F.col("cvg_ctgy") == "COLL", F.struct(F.col("cvg_key"), F.col("ded_amt")))
        )).alias("coll_ded_map"),
    )
)

txn_snapshot = (
    txn_base.select(*txn_keys)
    .join(agg_veh, txn_keys, "left")
    .join(agg_drv, txn_keys, "left")
    .join(agg_cvg, txn_keys, "left")
)

# ── Take each policy's LATEST transaction as its bootstrap snapshot ──
w_last = Window.partitionBy("AUTO_POLICY_ID").orderBy(F.col("SRC_TRANS_TMSP").desc())
latest_snapshot = (
    txn_snapshot
    .withColumn("_rn", F.row_number().over(w_last))
    .filter(F.col("_rn") == 1)
)

# ── Recent timestamps (pruned to the trailing window) + inception date, from full history --
#    this one time only ──
recent_tmsps = (
    txn_base
    .filter(F.col("SRC_TRANS_TMSP") >= F.expr(f"current_timestamp() - interval {RECENT_TMSP_WINDOW_DAYS} days"))
    .groupBy("AUTO_POLICY_ID")
    .agg(F.collect_set("SRC_TRANS_TMSP").alias("RECENT_TXN_TMSPS"))
)
inception = txn_base.groupBy("AUTO_POLICY_ID").agg(F.min("EFF_DT").alias("POLICY_INCEPTION_EFF_DT"))

bootstrap_state = (
    latest_snapshot
    .join(recent_tmsps, "AUTO_POLICY_ID", "left")
    .join(inception, "AUTO_POLICY_ID", "left")
    .select(
        "AUTO_POLICY_ID",
        F.col("vin_set").alias("VIN_SET"),
        F.col("drvr_id_set").alias("DRVR_ID_SET"),
        F.col("gndr_map").alias("GNDR_MAP"),
        F.col("mrtl_map").alias("MRTL_MAP"),
        F.col("comp_ded_map").alias("COMP_DED_MAP"),
        F.col("coll_ded_map").alias("COLL_DED_MAP"),
        F.col("BI_key_set").alias("BI_KEY_SET"),
        F.col("PD_key_set").alias("PD_KEY_SET"),
        F.col("MD_key_set").alias("MD_KEY_SET"),
        F.col("COLL_key_set").alias("COLL_KEY_SET"),
        F.col("COMP_key_set").alias("COMP_KEY_SET"),
        F.col("PIP_key_set").alias("PIP_KEY_SET"),
        F.coalesce(F.col("RECENT_TXN_TMSPS"), F.array()).alias("RECENT_TXN_TMSPS"),
        "POLICY_INCEPTION_EFF_DT",
        F.col("TRANS_ID").alias("LAST_TRANS_ID"),
        F.current_timestamp().alias("STATE_UPDATED_AT"),
    )
)

bootstrap_state.createOrReplaceTempView("_bootstrap_state")

spark.sql(f"""
    MERGE INTO {STATE} AS t
    USING _bootstrap_state AS s
    ON t.AUTO_POLICY_ID = s.AUTO_POLICY_ID
    WHEN MATCHED THEN UPDATE SET *
    WHEN NOT MATCHED THEN INSERT *
""")

n = bootstrap_state.count()
print(f"Bootstrapped {n} polic(y/ies) into {STATE}.")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== AUTO_POLICY_SNAPSHOT_STATE (sample) ===")
display(spark.table(STATE).limit(20))

print(f"\nTotal rows in {STATE}: {spark.table(STATE).count()}")
print(f"Total distinct policies in {RAW_EVENTS}: {total_policies}")
print("\n>>> Bootstrap complete. 04_sp_compute_features.py can now run incrementally. <<<")
