# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///
# MAGIC %md
# MAGIC # 01 — Setup Tables (optimized compute/routing design)
# MAGIC
# MAGIC | Table | Type | Role |
# MAGIC |---|---|---|
# MAGIC | `RAW_POLICY_EVENTS` | Bronze | Raw transaction JSON — append only, one row per transaction |
# MAGIC | `RAW_EVENTS_DLQ` | Bronze | Dead letter queue for malformed events |
# MAGIC | `AUTO_POLICY_SNAPSHOT_STATE` | **NEW** | One row per policy — the last-known snapshot `04` diffs new transactions against, instead of re-reading full history |
# MAGIC | `COMPUTED_FEATURE_EVENTS` | Silver | PySpark-computed features with per-group effective dates |
# MAGIC | `AUTO_FEATURES_ACTIVE` | Feature Store | Live features — one row per policy |
# MAGIC | `AUTO_FEATURES_PENDING` | Feature Store | Future-dated GROUP_B features waiting for EFF_DT |
# MAGIC | `AUTO_FEATURES_HISTORY` | Feature Store | SCD Type 2 full-row snapshots — still one row per transaction |
# MAGIC | `FEATURE_GROUP_REGISTRY` | Feature Store | Registry — routing type per feature group |
# MAGIC
# MAGIC ## What's different from the original design
# MAGIC
# MAGIC Only `04_sp_compute_features.py` and `05_routing_pipeline.py` change behavior, and only
# MAGIC one new table (`AUTO_POLICY_SNAPSHOT_STATE`) is added. `03` (ingestion, Auto Loader),
# MAGIC `06`, `07`, `08`, `09` are unchanged. See `ARCHITECTURE.md` in this folder for the full
# MAGIC design rationale.
# MAGIC
# MAGIC - `04` no longer re-reads a policy's entire `RAW_POLICY_EVENTS` history on every new
# MAGIC   transaction. It looks up that policy's current snapshot in `AUTO_POLICY_SNAPSHOT_STATE`
# MAGIC   instead (a small, well-clustered, single-row-per-policy table), computes the new
# MAGIC   transaction's delta against it, and writes the new snapshot back in one batched `MERGE`
# MAGIC   per micro-batch.
# MAGIC - `05` no longer processes events one at a time on the driver. It generates all
# MAGIC   `HISTORY` rows for a micro-batch in one batch-wide window-function pass, and does one
# MAGIC   `MERGE` per feature group into `ACTIVE` for the whole batch — same shape `06` already
# MAGIC   uses for pending promotions.
# MAGIC - `AUTO_FEATURES_HISTORY` still gets exactly one row per individual transaction — this
# MAGIC   redesign does not reduce audit granularity, only how those rows get computed.

# COMMAND ----------

dbutils.widgets.text("catalog", "workspace")
dbutils.widgets.text("schema",  "featurestore_test")
dbutils.widgets.dropdown("reset", "true", ["false", "true"])

CATALOG = dbutils.widgets.get("catalog")
SCHEMA  = dbutils.widgets.get("schema")
RESET   = dbutils.widgets.get("reset") == "true"

# Bronze
RAW_EVENTS  = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
DLQ         = f"{CATALOG}.{SCHEMA}.RAW_EVENTS_DLQ"

# NEW -- snapshot state (the "poor man's state store")
STATE       = f"{CATALOG}.{SCHEMA}.AUTO_POLICY_SNAPSHOT_STATE"

# Silver
COMPUTED    = f"{CATALOG}.{SCHEMA}.COMPUTED_FEATURE_EVENTS"

# Feature Store
ACTIVE      = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
PENDING     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_PENDING"
HISTORY     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"
REGISTRY    = f"{CATALOG}.{SCHEMA}.FEATURE_GROUP_REGISTRY"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Feature Column Definitions
# MAGIC
# MAGIC Defined once here as SQL fragments and reused across every table so `ACTIVE`, `PENDING`,
# MAGIC `HISTORY` and `COMPUTED_FEATURE_EVENTS` never drift out of sync with each other.

# COMMAND ----------

# GROUP_A — immediate, driven by SRC_TRANS_TMSP. Recomputed daily regardless of new events.
GROUP_A_COLUMNS_DDL = """
    TXN_CNT_1D                   INT,
    TXN_CNT_1W                   INT,
    TXN_CNT_1M                   INT,
    OUTSTANDING_TXN_IND          INT,
    TENURE_YRS                   INT"""

GROUP_A_COLUMN_NAMES = [
    "TXN_CNT_1D", "TXN_CNT_1W", "TXN_CNT_1M",
    "OUTSTANDING_TXN_IND", "TENURE_YRS",
]

# GROUP_B — effective_date, driven by EFF_DT. Only group that can land in PENDING.
GROUP_B_COLUMNS_DDL = """
    VEH_CNT                      INT,
    AVG_VEH_AGE                  DOUBLE,
    VEH_ADDED_LATEST_TXN         INT,
    DRVR_CNT                     INT,
    MAX_DRVR_AGE                 INT,
    MIN_DRVR_AGE                 INT,
    AVG_DRVR_AGE                 DOUBLE,
    DRVRS_ADDED_LATEST_TXN       INT,
    PREM_CHANGE_AMT              DOUBLE,
    BI_COVERAGE_ADDED            INT,
    BI_COVERAGE_REMOVED          INT,
    PD_COVERAGE_ADDED            INT,
    PD_COVERAGE_REMOVED          INT,
    MD_COVERAGE_ADDED            INT,
    MD_COVERAGE_REMOVED          INT,
    COLL_COVERAGE_ADDED          INT,
    COLL_COVERAGE_REMOVED        INT,
    COMP_COVERAGE_ADDED          INT,
    COMP_COVERAGE_REMOVED        INT,
    PIP_COVERAGE_ADDED           INT,
    PIP_COVERAGE_REMOVED         INT,
    COMP_DED_CHANGE_IND          INT,
    COLL_DED_CHANGE_IND          INT,
    GNDR_CHANGE_IND              INT,
    MRTL_CHANGE_IND              INT"""

GROUP_B_COLUMN_NAMES = [
    "VEH_CNT", "AVG_VEH_AGE", "VEH_ADDED_LATEST_TXN",
    "DRVR_CNT", "MAX_DRVR_AGE", "MIN_DRVR_AGE", "AVG_DRVR_AGE", "DRVRS_ADDED_LATEST_TXN",
    "PREM_CHANGE_AMT",
    "BI_COVERAGE_ADDED", "BI_COVERAGE_REMOVED",
    "PD_COVERAGE_ADDED", "PD_COVERAGE_REMOVED",
    "MD_COVERAGE_ADDED", "MD_COVERAGE_REMOVED",
    "COLL_COVERAGE_ADDED", "COLL_COVERAGE_REMOVED",
    "COMP_COVERAGE_ADDED", "COMP_COVERAGE_REMOVED",
    "PIP_COVERAGE_ADDED", "PIP_COVERAGE_REMOVED",
    "COMP_DED_CHANGE_IND", "COLL_DED_CHANGE_IND", "GNDR_CHANGE_IND", "MRTL_CHANGE_IND",
]

CVG_CATEGORIES = ["BI", "PD", "MD", "COLL", "COMP", "PIP"]

print(f"GROUP_A: {len(GROUP_A_COLUMN_NAMES)} columns")
print(f"GROUP_B: {len(GROUP_B_COLUMN_NAMES)} columns")

# COMMAND ----------

# MAGIC %md
# MAGIC ## PRE-FLIGHT CHECKS

# COMMAND ----------

import re

print("=" * 60)
print("  PRE-FLIGHT VALIDATION")
print("=" * 60)

errors   = []
warnings = []

# ── CHECK 1: Databricks Runtime Version ─────────────────────────
try:
    dbr_version = spark.conf.get("spark.databricks.clusterUsageTags.sparkVersion", "")
    if not dbr_version:
        dbr_version = spark.version
    major = int(re.search(r"(\d+)\.", dbr_version).group(1))
    if major >= 13:
        print(f"✅  CHECK 1 — Databricks Runtime : {dbr_version} (>= 13.3 required for Liquid Clustering)")
    else:
        errors.append(f"DBR {dbr_version} is below 13.3. AUTO_POLICY_SNAPSHOT_STATE needs Liquid Clustering (CLUSTER BY).")
        print(f"❌  CHECK 1 — Databricks Runtime : {dbr_version} — UPGRADE REQUIRED (need >= 13.3)")
except Exception as e:
    warnings.append(f"Could not determine DBR version: {e}")
    print(f"⚠️   CHECK 1 — Databricks Runtime : Could not verify — proceeding with caution")

# ── CHECK 2: Unity Catalog Enabled ──────────────────────────────
try:
    spark.sql("SHOW CATALOGS").collect()
    print(f"✅  CHECK 2 — Unity Catalog       : Enabled")
except Exception:
    errors.append("Unity Catalog is not enabled. 3-level namespace (catalog.schema.table) will not work.")
    print(f"❌  CHECK 2 — Unity Catalog       : NOT ENABLED — required for {CATALOG}.{SCHEMA}.*")

# ── CHECK 3: Catalog Exists ──────────────────────────────────────
try:
    catalogs = [r[0] for r in spark.sql("SHOW CATALOGS").collect()]
    if CATALOG in catalogs:
        print(f"✅  CHECK 3 — Catalog '{CATALOG}'    : Exists")
    else:
        errors.append(f"Catalog '{CATALOG}' does not exist. Create it or change the catalog widget.")
        print(f"❌  CHECK 3 — Catalog '{CATALOG}'    : NOT FOUND")
        print(f"    Available catalogs: {catalogs}")
        print(f"    Fix: CREATE CATALOG {CATALOG};  OR change the catalog widget value.")
except Exception as e:
    errors.append(f"Could not check catalog: {e}")
    print(f"❌  CHECK 3 — Catalog check failed : {e}")

# ── CHECK 4: Schema Exists ───────────────────────────────────────
try:
    schemas = [r[0] for r in spark.sql(f"SHOW SCHEMAS IN {CATALOG}").collect()]
    if SCHEMA in schemas:
        print(f"✅  CHECK 4 — Schema '{SCHEMA}'     : Exists in {CATALOG}")
    else:
        errors.append(f"Schema '{SCHEMA}' does not exist in catalog '{CATALOG}'.")
        print(f"❌  CHECK 4 — Schema '{SCHEMA}'     : NOT FOUND in {CATALOG}")
        print(f"    Fix: CREATE SCHEMA {CATALOG}.{SCHEMA};  OR change the schema widget value.")
except Exception as e:
    errors.append(f"Could not check schema: {e}")
    print(f"❌  CHECK 4 — Schema check failed  : {e}")

# ── CHECK 5: Write Permission on Schema ──────────────────────────
try:
    _test_tbl = f"{CATALOG}.{SCHEMA}._preflight_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"CREATE TABLE IF NOT EXISTS {_test_tbl} (x INT) USING DELTA")
    spark.sql(f"DROP TABLE IF EXISTS {_test_tbl}")
    print(f"✅  CHECK 5 — Write Permission    : Can create/drop tables in {CATALOG}.{SCHEMA}")
except Exception as e:
    errors.append(f"No write permission on {CATALOG}.{SCHEMA}: {e}")
    print(f"❌  CHECK 5 — Write Permission    : FAILED — {e}")

# ── CHECK 6: CDF Supported ───────────────────────────────────────
try:
    _cdf_test = f"{CATALOG}.{SCHEMA}._cdf_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"""
        CREATE TABLE IF NOT EXISTS {_cdf_test} (x INT)
        USING DELTA
        TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
    """)
    spark.sql(f"DROP TABLE IF EXISTS {_cdf_test}")
    print(f"✅  CHECK 6 — CDF Support         : Change Data Feed supported")
except Exception as e:
    errors.append(f"CDF (Change Data Feed) not supported: {e}")
    print(f"❌  CHECK 6 — CDF Support         : FAILED — {e}")

# ── CHECK 7: Volume Support (for checkpoints) ────────────────────
try:
    spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}._preflight_vol_check")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}._preflight_vol_check")
    print(f"✅  CHECK 7 — Volume Support      : Can create Volumes in {CATALOG}.{SCHEMA}")
except Exception as e:
    warnings.append(f"Volume creation failed — checkpoint path may not work: {e}")
    print(f"⚠️   CHECK 7 — Volume Support      : WARNING — {e}")

# ── CHECK 8: Liquid Clustering Supported (needed for AUTO_POLICY_SNAPSHOT_STATE) ──
try:
    _lc_test = f"{CATALOG}.{SCHEMA}._lc_test_{abs(hash(CATALOG+SCHEMA)) % 10000}"
    spark.sql(f"CREATE TABLE IF NOT EXISTS {_lc_test} (x STRING) USING DELTA CLUSTER BY (x)")
    spark.sql(f"DROP TABLE IF EXISTS {_lc_test}")
    print(f"✅  CHECK 8 — Liquid Clustering   : Supported")
except Exception as e:
    warnings.append(
        f"Liquid Clustering (CLUSTER BY) not supported on this DBR: {e}. "
        f"AUTO_POLICY_SNAPSHOT_STATE will be created without it — use Z-ORDER + OPTIMIZE "
        f"manually instead to keep policy lookups cheap as it grows."
    )
    print(f"⚠️   CHECK 8 — Liquid Clustering   : NOT SUPPORTED — {e}")
    print(f"    Falling back to a plain Delta table; run Z-ORDER BY AUTO_POLICY_ID manually.")

# ── CHECK 9: Existing Tables (warn if RESET=false) ───────────────
try:
    existing_tables = [r[1] for r in spark.sql(f"SHOW TABLES IN {CATALOG}.{SCHEMA}").collect()]
    feature_tables  = ["RAW_POLICY_EVENTS", "RAW_EVENTS_DLQ", "AUTO_POLICY_SNAPSHOT_STATE",
                        "COMPUTED_FEATURE_EVENTS", "AUTO_FEATURES_ACTIVE", "AUTO_FEATURES_PENDING",
                        "AUTO_FEATURES_HISTORY", "FEATURE_GROUP_REGISTRY"]
    already_exist   = [t for t in feature_tables if t in existing_tables]
    if already_exist and not RESET:
        warnings.append(f"Tables already exist: {already_exist}. Using CREATE IF NOT EXISTS — no data will be lost. Set reset=true to drop and recreate.")
        print(f"⚠️   CHECK 9 — Existing Tables    : {len(already_exist)} table(s) already exist — will be skipped (reset=false)")
        for t in already_exist:
            print(f"    → {t}")
    elif already_exist and RESET:
        print(f"⚠️   CHECK 9 — Existing Tables    : {len(already_exist)} table(s) will be DROPPED (reset=true)")
        for t in already_exist:
            print(f"    → {t}")
    else:
        print(f"✅  CHECK 9 — Existing Tables    : No conflicts — fresh setup")
except Exception as e:
    warnings.append(f"Could not check existing tables: {e}")
    print(f"⚠️   CHECK 9 — Existing Tables    : Could not verify — {e}")

# ── SUMMARY ─────────────────────────────────────────────────────
print()
print("=" * 60)
if errors:
    print(f"  RESULT: ❌  {len(errors)} ERROR(S) — CANNOT PROCEED")
    print("=" * 60)
    for i, err in enumerate(errors, 1):
        print(f"  [{i}] {err}")
    print()
    raise Exception(
        f"Pre-flight failed with {len(errors)} error(s). "
        f"Fix the issues above before running this notebook."
    )
elif warnings:
    print(f"  RESULT: ⚠️   PASSED WITH {len(warnings)} WARNING(S) — proceeding")
    print("=" * 60)
    for i, w in enumerate(warnings, 1):
        print(f"  [{i}] {w}")
    print()
    print("  Proceeding to table creation...")
else:
    print("  RESULT: ✅  ALL CHECKS PASSED — proceeding")
    print("=" * 60)
    print()
    print("  Proceeding to table creation...")

LIQUID_CLUSTERING_SUPPORTED = not any("Liquid Clustering" in w for w in warnings)

# COMMAND ----------

spark.sql(f"USE CATALOG {CATALOG}")
spark.sql(f"USE SCHEMA {SCHEMA}")
print(f"Using: {CATALOG}.{SCHEMA}")

if RESET:
    for tbl in [RAW_EVENTS, DLQ, STATE, COMPUTED, ACTIVE, PENDING, HISTORY, REGISTRY]:
        spark.sql(f"DROP TABLE IF EXISTS {tbl}")
    spark.sql(f"DROP VOLUME IF EXISTS {CATALOG}.{SCHEMA}.checkpoints")
    print("All tables dropped — will recreate.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 0. Create Checkpoint Volume

# COMMAND ----------

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.checkpoints")
print(f"Volume ready: /Volumes/{CATALOG}/{SCHEMA}/checkpoints")

spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{SCHEMA}.incoming_json")
print(f"Volume ready: /Volumes/{CATALOG}/{SCHEMA}/incoming_json  ← drop transaction JSON files here (Auto Loader landing zone)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. RAW_POLICY_EVENTS (Bronze)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {RAW_EVENTS} (
    TRANS_ID                STRING    NOT NULL,
    AUTO_POLICY_ID           STRING    NOT NULL,
    PLCY_CNTRCT_NUM          STRING,
    SRC_HH_NUM               STRING,
    EFF_DT                   TIMESTAMP NOT NULL,
    SRC_TRANS_TMSP           TIMESTAMP NOT NULL,
    RAW_PAYLOAD               STRING    NOT NULL,
    INGESTED_AT               TIMESTAMP NOT NULL
)
USING DELTA
TBLPROPERTIES (
    'delta.appendOnly'           = 'true',
    'delta.enableChangeDataFeed' = 'true'
)
""")
print(f"Created: {RAW_EVENTS}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. RAW_EVENTS_DLQ (Dead Letter Queue)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {DLQ} (
    RAW_PAYLOAD           STRING,
    ERROR_MESSAGE         STRING,
    FAILED_AT             TIMESTAMP NOT NULL,
    SOURCE_NAME           STRING
)
USING DELTA
""")
print(f"Created: {DLQ}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. AUTO_POLICY_SNAPSHOT_STATE (NEW — the "poor man's state store")
# MAGIC
# MAGIC One row per policy — the last-known snapshot `04` diffs each new transaction against.
# MAGIC Size tracks the number of policies, not the number of transactions, since it's
# MAGIC overwritten (not appended to) on every update. Only ever written by `04`'s single
# MAGIC streaming query, one batched `MERGE` per micro-batch — no concurrent-writer conflicts
# MAGIC to design around.
# MAGIC
# MAGIC `RECENT_TXN_TMSPS` is a bounded array (pruned to the trailing ~35 days by `04`) used to
# MAGIC compute `TXN_CNT_1D/1W/1M` without re-reading full history. `POLICY_INCEPTION_EFF_DT` is
# MAGIC set once, on a policy's first-ever transaction, and never changes after that.
# MAGIC
# MAGIC Must stay clustered on `AUTO_POLICY_ID` — every lookup and merge is keyed by policy.

# COMMAND ----------

cluster_clause = "CLUSTER BY (AUTO_POLICY_ID)" if LIQUID_CLUSTERING_SUPPORTED else ""

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {STATE} (
    AUTO_POLICY_ID              STRING              NOT NULL,
    VIN_SET                     ARRAY<STRING>,
    DRVR_ID_SET                 ARRAY<STRING>,
    GNDR_MAP                    MAP<STRING, STRING>,
    MRTL_MAP                    MAP<STRING, STRING>,
    COMP_DED_MAP                MAP<STRING, DOUBLE>,
    COLL_DED_MAP                MAP<STRING, DOUBLE>,
    BI_KEY_SET                  ARRAY<STRING>,
    PD_KEY_SET                  ARRAY<STRING>,
    MD_KEY_SET                  ARRAY<STRING>,
    COLL_KEY_SET                ARRAY<STRING>,
    COMP_KEY_SET                ARRAY<STRING>,
    PIP_KEY_SET                 ARRAY<STRING>,
    RECENT_TXN_TMSPS            ARRAY<TIMESTAMP>,
    POLICY_INCEPTION_EFF_DT     TIMESTAMP,
    LAST_TRANS_ID                STRING,
    STATE_UPDATED_AT             TIMESTAMP,
    CONSTRAINT AUTO_POLICY_SNAPSHOT_STATE_PK PRIMARY KEY (AUTO_POLICY_ID)
)
USING DELTA
{cluster_clause}
""")
print(f"Created: {STATE}" + (" (Liquid Clustered on AUTO_POLICY_ID)" if LIQUID_CLUSTERING_SUPPORTED else " (no clustering — run Z-ORDER manually)"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. COMPUTED_FEATURE_EVENTS (Silver)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {COMPUTED} (
    TRANS_ID                 STRING    NOT NULL,
    AUTO_POLICY_ID            STRING    NOT NULL,
    PLCY_CNTRCT_NUM           STRING,
    SRC_HH_NUM                STRING,

    SRC_TRANS_TMSP            TIMESTAMP NOT NULL,
    EFF_DT                    TIMESTAMP NOT NULL,
    {GROUP_A_COLUMNS_DDL},
    {GROUP_B_COLUMNS_DDL},

    COMPUTED_AT                TIMESTAMP NOT NULL
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {COMPUTED}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. AUTO_FEATURES_ACTIVE (Feature Store)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {ACTIVE} (
    -- Identity
    AUTO_POLICY_ID                 STRING    NOT NULL,
    PLCY_CNTRCT_NUM                 STRING,
    SRC_HH_NUM                      STRING,
    TRANS_ID                        STRING,

    -- GROUP_A features (routing_type = immediate)
    {GROUP_A_COLUMNS_DDL},
    GROUP_A_UPDATED_AT              TIMESTAMP,

    -- GROUP_B features (routing_type = effective_date)
    {GROUP_B_COLUMNS_DDL},
    GROUP_B_UPDATED_AT              TIMESTAMP,

    -- Metadata
    FEATURE_UPDATED_AT              TIMESTAMP,
    LAST_SOURCE_EVENT_ID            STRING,

    CONSTRAINT AUTO_FEATURES_ACTIVE_PK PRIMARY KEY (AUTO_POLICY_ID)
)
USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"Created: {ACTIVE}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. AUTO_FEATURES_PENDING (Feature Store)

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {PENDING} (
    -- Identity
    AUTO_POLICY_ID                 STRING    NOT NULL,
    TRANS_ID                        STRING,

    -- GROUP_B features only (only effective_date group lands here)
    {GROUP_B_COLUMNS_DDL},

    -- Scheduling
    EFFECTIVE_DATE                  TIMESTAMP NOT NULL,
    CHANGED_FEATURE_GROUP           STRING,
    SOURCE_EVENT_ID                 STRING,
    EVENT_RECEIVED_AT               TIMESTAMP
)
USING DELTA
""")
print(f"Created: {PENDING}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. AUTO_FEATURES_HISTORY (Feature Store)
# MAGIC
# MAGIC Unchanged schema and unchanged granularity — still one row per individual transaction.
# MAGIC `05`'s redesign changes *how* these rows get computed (batch-wide window functions
# MAGIC instead of a per-event driver loop), not what gets stored.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {HISTORY} (
    -- Identity
    AUTO_POLICY_ID                 STRING    NOT NULL,
    PLCY_CNTRCT_NUM                 STRING,
    SRC_HH_NUM                      STRING,
    TRANS_ID                        STRING,

    -- GROUP_A features
    {GROUP_A_COLUMNS_DDL},
    GROUP_A_UPDATED_AT              TIMESTAMP,

    -- GROUP_B features
    {GROUP_B_COLUMNS_DDL},
    GROUP_B_UPDATED_AT              TIMESTAMP,

    -- Metadata
    FEATURE_UPDATED_AT              TIMESTAMP,
    LAST_SOURCE_EVENT_ID            STRING,

    -- SCD Type 2 validity window (TIMESTAMP — minute precision)
    SNAPSHOT_AT                     TIMESTAMP NOT NULL,
    REASON                          STRING,
    EVENT_ID                        STRING,
    CHANGED_FEATURE_GROUP           STRING,
    VALID_TRANSACTION_FROM          TIMESTAMP NOT NULL,
    VALID_TRANSACTION_TO            TIMESTAMP,
    IS_CURRENT                      BOOLEAN   NOT NULL
)
USING DELTA
""")
print(f"Created: {HISTORY}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. FEATURE_GROUP_REGISTRY

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {REGISTRY} (
    FEATURE_GROUP        STRING        NOT NULL,
    OWNED_COLUMNS         ARRAY<STRING> NOT NULL,
    ROUTING_TYPE          STRING        NOT NULL,
    EFFECTIVE_DATE_COL     STRING        NOT NULL,
    DESCRIPTION            STRING,
    CONSTRAINT FEATURE_GROUP_REGISTRY_PK PRIMARY KEY (FEATURE_GROUP)
)
USING DELTA
""")

if spark.table(REGISTRY).limit(1).count() == 0:
    group_a_array = ", ".join(f"'{c}'" for c in GROUP_A_COLUMN_NAMES)
    group_b_array = ", ".join(f"'{c}'" for c in GROUP_B_COLUMN_NAMES)
    spark.sql(f"""
    INSERT INTO {REGISTRY} VALUES
    (
        'GROUP_A',
        ARRAY({group_a_array}),
        'immediate',
        'SRC_TRANS_TMSP',
        'Transaction-clock features (txn counts, tenure, outstanding flag) — always immediate, drift daily on wall-clock time.'
    ),
    (
        'GROUP_B',
        ARRAY({group_b_array}),
        'effective_date',
        'EFF_DT',
        'Policy-effective-date features (vehicle/driver/coverage snapshot + lag deltas) — respect EFF_DT, may be future-dated.'
    )
    """)
    print("Registry seeded with 2 feature groups.")

print(f"Created: {REGISTRY}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Verify All Tables

# COMMAND ----------

tables = [
    ("RAW_POLICY_EVENTS",         RAW_EVENTS),
    ("RAW_EVENTS_DLQ",            DLQ),
    ("AUTO_POLICY_SNAPSHOT_STATE", STATE),
    ("COMPUTED_FEATURE_EVENTS",   COMPUTED),
    ("AUTO_FEATURES_ACTIVE",      ACTIVE),
    ("AUTO_FEATURES_PENDING",     PENDING),
    ("AUTO_FEATURES_HISTORY",     HISTORY),
    ("FEATURE_GROUP_REGISTRY",    REGISTRY),
]

print("=== Table Row Counts ===")
for label, tbl in tables:
    print(f"  {label:30s}: {spark.table(tbl).count()} rows")

print("\n=== FEATURE_GROUP_REGISTRY ===")
display(spark.table(REGISTRY))

print("\n>>> Next: 02_seed_data, then 03_autoloader_landing_zone (unchanged) <<<")
print(">>> If this schema already has transaction history, run bootstrap_snapshot_state.py")
print(">>> ONCE before relying on 04_sp_compute_features -- it seeds AUTO_POLICY_SNAPSHOT_STATE <<<")