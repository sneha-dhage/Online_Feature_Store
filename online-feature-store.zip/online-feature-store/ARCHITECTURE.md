# Optimized Compute & Routing — End-to-End Design

Scope: fix the two dominant bottlenecks (`04`'s full-history recompute, `05`'s
per-event driver loop) while staying fully inside the existing Delta/declarative-
DataFrame paradigm — no Kafka, no Spark-native stateful streaming API. Ingestion
(`03`) stays exactly as it is today: Auto Loader watching the `incoming_json` volume.

## 1. What changes, what doesn't

| Notebook | Status |
|---|---|
| `01_setup_tables.py` | **Extended** — one new table: `AUTO_POLICY_SNAPSHOT_STATE` |
| `02_seed_data.py` | **Extended** — seed the new table alongside `ACTIVE`/`HISTORY` |
| `03_autoloader_landing_zone.py` | **Unchanged** — still Auto Loader, still file-drop |
| `04_sp_compute_features.py` | **Redesigned** — reads a small state table instead of re-reading full history |
| `05_routing_pipeline.py` | **Redesigned** — batch-wide window functions instead of a per-event loop |
| `06`, `07`, `08`, `09` | **Unchanged** |
| `FEATURE_GROUP_REGISTRY`, `RAW_POLICY_EVENTS`, `COMPUTED_FEATURE_EVENTS`, `AUTO_FEATURES_ACTIVE/PENDING/HISTORY` | **Unchanged schemas** |

One new one-time step: a **backfill job** to bootstrap `AUTO_POLICY_SNAPSHOT_STATE`
for policies that already have history (Section 6) — after that, `04` never does a
full history re-read again.

## 2. Pipeline diagram

```mermaid
flowchart TD
    JSON["Transaction JSON files"] --> AL["03_autoloader_landing_zone.py<br/>(UNCHANGED)"]
    AL --> RAW[("RAW_POLICY_EVENTS")]

    RAW -->|CDF: new rows only| C04["04_sp_compute_features.py<br/>(REDESIGNED)"]
    STATE[("AUTO_POLICY_SNAPSHOT_STATE<br/>NEW — one row per policy")] <-->|point lookup + batched MERGE| C04
    C04 --> COMPUTED[("COMPUTED_FEATURE_EVENTS")]

    COMPUTED -->|CDF| C05["05_routing_pipeline.py<br/>(REDESIGNED)"]
    C05 --> ACTIVE[("AUTO_FEATURES_ACTIVE")]
    C05 --> PENDING[("AUTO_FEATURES_PENDING")]
    C05 --> HISTORY[("AUTO_FEATURES_HISTORY<br/>one row per transaction, preserved")]

    ACTIVE --> C08["08_online_feature_store.py<br/>(UNCHANGED)"]
```

## 3. New table: `AUTO_POLICY_SNAPSHOT_STATE`

The "poor-man's state store" from the design discussion — a Delta table holding
**only the latest snapshot per policy**, not history. Its size tracks the number of
policies, not the number of transactions.

```
AUTO_POLICY_ID              STRING     NOT NULL   -- PK, Liquid Clustering key
VIN_SET                     ARRAY<STRING>
DRVR_ID_SET                 ARRAY<STRING>
GNDR_MAP                    MAP<STRING, STRING>
MRTL_MAP                    MAP<STRING, STRING>
COMP_DED_MAP                MAP<STRING, DOUBLE>
COLL_DED_MAP                MAP<STRING, DOUBLE>
BI_KEY_SET                  ARRAY<STRING>
PD_KEY_SET                  ARRAY<STRING>
MD_KEY_SET                  ARRAY<STRING>
COLL_KEY_SET                ARRAY<STRING>
COMP_KEY_SET                ARRAY<STRING>
PIP_KEY_SET                 ARRAY<STRING>
RECENT_TXN_TMSPS            ARRAY<TIMESTAMP>   -- pruned to trailing ~35 days
POLICY_INCEPTION_EFF_DT     TIMESTAMP          -- set once, never overwritten
LAST_TRANS_ID                STRING            -- audit: which txn produced this row
STATE_UPDATED_AT             TIMESTAMP
```

Must be **Liquid Clustered on `AUTO_POLICY_ID`** (or Z-ORDERed + regularly
`OPTIMIZE`d) — every lookup and merge against this table is keyed by policy, and
clustering is what keeps those operations cheap as the table grows to millions of
rows.

Only a **single writer** touches this table (the `04` streaming query, one batched
`MERGE` per micro-batch) — so there's no concurrent-write conflict risk to design
around, unlike a multi-writer scenario.

## 4. `04` redesign — the core trick

**Which features actually need "previous transaction" state, and which don't:**

| Needs no state — pure function of the current transaction | Needs the previous snapshot |
|---|---|
| `VEH_CNT`, `AVG_VEH_AGE`, `DRVR_CNT`, `MAX/MIN/AVG_DRVR_AGE`, `PREM_CHANGE_AMT`, `OUTSTANDING_TXN_IND` (7 features) | `VEH_ADDED_LATEST_TXN`, `DRVRS_ADDED_LATEST_TXN`, all 12 `*_COVERAGE_ADDED/REMOVED`, `COMP_DED_CHANGE_IND`, `COLL_DED_CHANGE_IND`, `GNDR_CHANGE_IND`, `MRTL_CHANGE_IND` (18 features) |
| `TXN_CNT_1D/1W/1M`, `TENURE_YRS` need bounded state (`RECENT_TXN_TMSPS`, `POLICY_INCEPTION_EFF_DT`) — small, not full history | |

**The mechanism — union the small "prior state" with the small "new events," then run the exact same `lag()`/`Window` logic `04` already has, over a much smaller input:**

```mermaid
flowchart LR
    NEW["new_events (this micro-batch only)<br/>already carries RAW_PAYLOAD from CDF"]
    NEW --> SNAP["explode + aggregate<br/>THIS transaction's own snapshot<br/>(same logic as today, smaller input)"]

    LOOKUP["broadcast join: touched policies<br/>-> AUTO_POLICY_SNAPSHOT_STATE"]
    LOOKUP --> PRIOR["one synthetic 'prior state' row per touched<br/>policy that HAS existing state --<br/>no row at all for a brand-new policy"]

    SNAP --> UNION["unionByName(prior_state_rows, new_snapshot_rows)"]
    PRIOR --> UNION

    UNION --> WIN["Window.partitionBy(AUTO_POLICY_ID)<br/>.orderBy(IS_STATE_ROW desc, SRC_TRANS_TMSP asc, TRANS_ID asc)<br/>+ lag() -- SAME formulas as today's 04"]

    WIN --> OUT["filter out synthetic state rows<br/>-> write COMPUTED_FEATURE_EVENTS"]
    WIN --> NEWSTATE["take each policy's LAST row in order<br/>-> ONE batched MERGE<br/>-> AUTO_POLICY_SNAPSHOT_STATE"]
```

Why this preserves correctness automatically, including "two new transactions for
the same policy in one micro-batch": the synthetic prior-state row is ordered
**before** any real transaction (via `IS_STATE_ROW desc`), so `lag()` naturally
chains — the second new transaction's "previous" becomes the first new
transaction's snapshot, not the old state row, exactly as it should. This is the
same declarative window-function mechanism `04` already uses today; only the input
size shrinks, from "this policy's entire history" to "1 state row + however many
new transactions this policy got in this batch."

`array_except`/`map_change_ind` formulas for the 18 state-dependent features are
**unchanged** from today's `04` — same code, smaller input.

**GROUP_A features**, computed from state instead of a full re-scan:
- `TXN_CNT_1D/1W/1M`: explode `state.RECENT_TXN_TMSPS` to rows, `unionByName` with this
  batch's own new transaction timestamps, filter to each rolling window, `groupBy` +
  count — one batched operation covering every touched policy at once, not a
  per-event lookup. Matches the original design's "everyone processed in this batch
  gets the same count, right now" semantics exactly.
- `TENURE_YRS`: `COALESCE(state.POLICY_INCEPTION_EFF_DT, MIN(new EFF_DT this batch))`.
- `OUTSTANDING_TXN_IND`: unchanged — always came from the current transaction alone.

**State write-back**: one batched `MERGE INTO AUTO_POLICY_SNAPSHOT_STATE` per
micro-batch, using each touched policy's final snapshot (the last row in its
ordered sequence) — not one `MERGE` per event.

## 5. `05` redesign — batch-wide, same per-transaction `HISTORY` granularity

Requirement carried over unchanged: **one `HISTORY` row per individual
transaction** — this redesign doesn't reduce that, it only changes *how* those rows
get computed (batch-wide window functions instead of a per-event driver loop).

```mermaid
flowchart TD
    BATCH["new computed events (whole micro-batch)"]
    BATCH --> ROUTE["per event, per feature group:<br/>immediate vs pending<br/>(cheap, vectorized -- not the bottleneck)"]
    ROUTE --> COLLAPSE["collapse multiple immediate groups<br/>on the SAME event into ONE closing point:<br/>earliest_eff = MIN(effective date across groups).<br/>Each group's OWNED_COLUMNS are nulled out on any<br/>event where that specific group ISN'T immediate."]
    COLLAPSE --> OLDROW["union in the current ACTIVE row per touched<br/>policy as a sentinel baseline (mirrors HISTORY's<br/>IS_CURRENT row) -- same trick as 04's prior-state union"]
    OLDROW --> CARRY["carry forward every column's last known<br/>NON-NULL value: F.last(col, ignorenulls=True)<br/>over Window...orderBy(IS_SENTINEL desc, earliest_eff,<br/>TRANS_ID).rowsBetween(unboundedPreceding, currentRow)"]
    CARRY --> LEAD["lead(earliest_eff) on the SAME ordering<br/>-> VALID_TRANSACTION_TO, IS_CURRENT<br/>(the sentinel's own lead() = the old row's close boundary)"]
    LEAD --> HIST["ONE batched INSERT<br/>-> AUTO_FEATURES_HISTORY<br/>(one FULLY-RECONSTRUCTED row per transaction)"]
    LEAD --> CLOSE["ONE batched UPDATE<br/>closes old IS_CURRENT rows"]
    COLLAPSE --> LATEST["per policy, per feature group:<br/>row_number()==1 by earliest_eff desc<br/>(Delta's own column-level UPDATE SET<br/>preserves untouched groups -- no carry-forward needed here)"]
    LATEST --> MERGE["ONE MERGE per feature group<br/>-> AUTO_FEATURES_ACTIVE<br/>(same batched shape 06 already uses)"]
    ROUTE --> PEND["pending groups -> batched MERGE<br/>-> AUTO_FEATURES_PENDING"]
```

**Why the carry-forward step exists, concretely**: each `HISTORY` row must be a
*full* point-in-time snapshot of all 30 feature columns, not just the ones that
changed on that specific transaction — same as the original per-event design. If a
policy has two triggering transactions in the same micro-batch, and the first only
touches GROUP_A while the second only touches GROUP_B, the first row's snapshot
must still show GROUP_B's *old* value, and the second row's snapshot must carry
forward the first row's *new* GROUP_A value. `F.last(col, ignorenulls=True)` over a
running window (unbounded-preceding-to-current-row, ordered the same way
throughout) does exactly this — each row reuses whatever value was most recently
non-null for that column, starting from the sentinel's real (non-null) baseline.
Note `ACTIVE`'s own update (the `LATEST`/`MERGE` branch) does **not** need this
carry-forward at all: Delta's column-level `UPDATE SET` already leaves untouched
columns alone, so only `HISTORY`'s point-in-time snapshots need the extra step.

This turns "N events × ~4 sequential `spark.sql()` calls" into a small constant
number of operations per batch — 1 `UPDATE`, 1 `INSERT`, and one `MERGE` per
feature group (2 today: GROUP_A, GROUP_B) — regardless of how many events were in
the batch. The negative-validity-window bug is still avoided the same way it is
today: by collapsing multi-group same-event routing to one earliest-effective-date
closing point *before* generating history rows, not by processing serially.
`TRANS_ID` is a tertiary sort key throughout purely to keep ordering deterministic
on an `earliest_eff` tie — the same defensive tie-break the original per-event
design used (`orderBy("SRC_TRANS_TMSP", "TRANS_ID")`).

## 6. Migration: bootstrapping `AUTO_POLICY_SNAPSHOT_STATE`

`04` can only stop re-reading full history once every existing policy already has a
current-snapshot row. This is a **one-time** job (same shape as
`bulk_backfill_from_csv.py`, not a new pattern):

1. Read all of `RAW_POLICY_EVENTS`, grouped by `AUTO_POLICY_ID`.
2. For each policy, run the *existing* full-history snapshot + `lag()` logic one
   last time to find its true latest state (this is the last time this expensive
   path ever runs).
3. Write the result straight into `AUTO_POLICY_SNAPSHOT_STATE` as the initial load.
4. From then on, `04` only ever reads new events + this state table — never
   `RAW_POLICY_EVENTS`'s full history again.

Brand-new policies with no prior transactions need no bootstrap — their first
transaction naturally creates their first state row via the normal batched `MERGE`.

## 7. What this design deliberately does NOT do

- **No Kafka** — ingestion stays exactly as `03` does it today (Auto Loader, file
  drop). This design is orthogonal to ingestion mechanism; it would work unchanged
  if `03` were later replaced with a Kafka-based landing job.
- **No Spark-native stateful streaming API** (`flatMapGroupsWithState`) — the state
  table plays that role instead, trading a small amount of raw latency for staying
  in the existing declarative/SQL paradigm, plain queryability, and trivial schema
  evolution (`ALTER TABLE ADD COLUMN` instead of a state-store rebuild).
- **No reduction in `HISTORY` granularity** — still one row per transaction, per
  the explicit requirement.

## 8. Net effect

| | Before | After |
|---|---|---|
| `04` cost per new transaction | O(that policy's entire history) | O(1) — a small state lookup + this transaction's own arrays |
| `04`'s `.isin(touched_policies)` giant list | Present | Gone — replaced by a broadcast join against the small state table |
| `05` cost per micro-batch | O(events) sequential SQL calls (~4 per event) | O(1) — a small constant number of batched SQL operations, regardless of event count |
| `HISTORY` granularity | One row per transaction | Unchanged — one row per transaction |
| New standing cost | — | `AUTO_POLICY_SNAPSHOT_STATE`: ~1-3 KB × number of policies, well-clustered Delta table |
