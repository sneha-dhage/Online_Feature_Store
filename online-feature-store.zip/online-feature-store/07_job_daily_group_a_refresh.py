# Databricks notebook source
# MAGIC %md
# MAGIC # 07 — Job: Daily GROUP_A Refresh
# MAGIC
# MAGIC GROUP_A (`TXN_CNT_1D`, `TXN_CNT_1W`, `TXN_CNT_1M`, `OUTSTANDING_TXN_IND`, `TENURE_YRS`) is
# MAGIC driven by **wall-clock time**, not by new events — `tenure_yrs` ticks up every year and
# MAGIC `txn_cnt_1d/1w/1m` drop off as time passes, even if a policy has had zero new transactions.
# MAGIC
# MAGIC The CDF-driven pipelines (`04`/`05`) only fire when a new transaction lands, so nothing else
# MAGIC in this pipeline ever revisits a quiet policy. This job runs **daily** via Databricks Workflows
# MAGIC and recomputes GROUP_A directly from `RAW_POLICY_EVENTS` history for every policy, independent
# MAGIC of `AUTO_FEATURES_PENDING` / daily promotion (06), which only ever concerns GROUP_B.
# MAGIC
# MAGIC ## Steps
# MAGIC 1. Recompute GROUP_A from `RAW_POLICY_EVENTS` for every policy, as of `run_date` (today by default)
# MAGIC 2. Diff against the GROUP_A values currently in `AUTO_FEATURES_ACTIVE` — skip policies with no change
# MAGIC 3. MERGE the changed GROUP_A columns into `AUTO_FEATURES_ACTIVE`
# MAGIC 4. Close existing `IS_CURRENT` history rows for changed policies (`VALID_TRANSACTION_TO = run_date - 1ms`)
# MAGIC 5. Snapshot updated `AUTO_FEATURES_ACTIVE` → `AUTO_FEATURES_HISTORY` (`REASON = 'group_a_daily_refresh'`)
# MAGIC
# MAGIC Leave `run_date` blank in production (uses current_timestamp).
# MAGIC Set e.g. `2026-07-25 00:00:00` to simulate a future date in testing.
# MAGIC
# MAGIC **Unchanged in this redesign** — this job intentionally still scans `RAW_POLICY_EVENTS` in
# MAGIC full once a day; it's a batch job, not a per-event bottleneck, so it was out of scope for the
# MAGIC `04`/`05` optimization. It could later be pointed at `AUTO_POLICY_SNAPSHOT_STATE.RECENT_TXN_TMSPS`
# MAGIC instead for a further speedup, but that's a separate follow-up, not included here.

# COMMAND ----------

from pyspark.sql import functions as F
from datetime import datetime

dbutils.widgets.text("catalog",  "main")
dbutils.widgets.text("schema",   "final_database")
dbutils.widgets.text("run_date", "")  # format: YYYY-MM-DD HH:MM:SS

CATALOG     = dbutils.widgets.get("catalog")
SCHEMA      = dbutils.widgets.get("schema")
_date_input = dbutils.widgets.get("run_date").strip()

if _date_input:
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m-%d-%Y", "%m/%d/%Y"):
        try:
            run_ts = datetime.strptime(_date_input, fmt).strftime("%Y-%m-%d %H:%M:%S")
            break
        except ValueError:
            continue
    else:
        raise ValueError(f"Cannot parse run_date '{_date_input}'. Use YYYY-MM-DD HH:MM:SS.")
else:
    run_ts = str(spark.sql("SELECT current_timestamp()").first()[0])

print(f"Run timestamp: {run_ts}")

RAW_EVENTS = f"{CATALOG}.{SCHEMA}.RAW_POLICY_EVENTS"
ACTIVE     = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_ACTIVE"
HISTORY    = f"{CATALOG}.{SCHEMA}.AUTO_FEATURES_HISTORY"

GROUP_A_COLUMNS = ["TXN_CNT_1D", "TXN_CNT_1W", "TXN_CNT_1M", "OUTSTANDING_TXN_IND", "TENURE_YRS"]

# COMMAND ----------
# MAGIC %md
# MAGIC ## Recompute GROUP_A for Every Policy as of `run_ts`

# COMMAND ----------

def refresh_group_a():
    raw = spark.table(RAW_EVENTS)

    fresh = (
        raw.groupBy("AUTO_POLICY_ID")
        .agg(
            F.sum(F.when(F.col("SRC_TRANS_TMSP") >= F.expr(f"TIMESTAMP '{run_ts}' - INTERVAL 1 DAY"), 1)
                   .otherwise(0)).alias("TXN_CNT_1D"),
            F.sum(F.when(F.col("SRC_TRANS_TMSP") >= F.expr(f"TIMESTAMP '{run_ts}' - INTERVAL 7 DAYS"), 1)
                   .otherwise(0)).alias("TXN_CNT_1W"),
            F.sum(F.when(F.col("SRC_TRANS_TMSP") >= F.expr(f"TIMESTAMP '{run_ts}' - INTERVAL 1 MONTH"), 1)
                   .otherwise(0)).alias("TXN_CNT_1M"),
            F.min("EFF_DT").alias("_inception_eff_dt"),
            F.max(F.struct("SRC_TRANS_TMSP", "EFF_DT")).alias("_latest"),
        )
        .withColumn("TENURE_YRS",
                    F.floor(F.months_between(F.lit(run_ts).cast("date"), F.col("_inception_eff_dt")) / 12))
        .withColumn("OUTSTANDING_TXN_IND",
                    (F.col("_latest.EFF_DT") > F.lit(run_ts).cast("date")).cast("int"))
        .select("AUTO_POLICY_ID", *GROUP_A_COLUMNS)
    )

    current = spark.table(ACTIVE).select("AUTO_POLICY_ID", *GROUP_A_COLUMNS)

    diff_expr = None
    for c in GROUP_A_COLUMNS:
        cond = ~F.col(f"f.{c}").eqNullSafe(F.col(f"c.{c}"))
        diff_expr = cond if diff_expr is None else (diff_expr | cond)

    changed = (
        fresh.alias("f")
        .join(current.alias("c"), "AUTO_POLICY_ID", "inner")
        .where(diff_expr)
        .select("f.*")
    )

    changed_count = changed.count()
    print(f"Policies with GROUP_A drift as of {run_ts}: {changed_count}")

    if changed_count == 0:
        print("Nothing to refresh.")
        return

    changed.createOrReplaceTempView("_group_a_refresh")

    # Step 1 — MERGE fresh GROUP_A values into ACTIVE
    set_clause = ", ".join(f"t.{c} = s.{c}" for c in GROUP_A_COLUMNS)
    spark.sql(f"""
        MERGE INTO {ACTIVE} AS t
        USING _group_a_refresh AS s
        ON t.AUTO_POLICY_ID = s.AUTO_POLICY_ID
        WHEN MATCHED THEN UPDATE SET
            {set_clause},
            t.GROUP_A_UPDATED_AT = TIMESTAMP '{run_ts}',
            t.FEATURE_UPDATED_AT = TIMESTAMP '{run_ts}'
    """)
    print(f"  Step 1: Merged GROUP_A for {changed_count} polic(y/ies) into AUTO_FEATURES_ACTIVE.")

    # Step 2 — Close existing IS_CURRENT history rows for changed policies
    spark.sql(f"""
        UPDATE {HISTORY}
        SET    IS_CURRENT           = false,
               VALID_TRANSACTION_TO = TIMESTAMP '{run_ts}' - INTERVAL 1 MILLISECOND
        WHERE  AUTO_POLICY_ID IN (SELECT AUTO_POLICY_ID FROM _group_a_refresh)
          AND  IS_CURRENT = true
    """)
    print("  Step 2: Closed IS_CURRENT history rows for changed policies.")

    # Step 3 — Snapshot updated ACTIVE → HISTORY (one IS_CURRENT=true row per changed policy)
    spark.sql(f"""
        INSERT INTO {HISTORY}
        SELECT
            a.*,
            TIMESTAMP '{run_ts}'    AS SNAPSHOT_AT,
            'group_a_daily_refresh' AS REASON,
            NULL                    AS EVENT_ID,
            'GROUP_A'               AS CHANGED_FEATURE_GROUP,
            TIMESTAMP '{run_ts}'    AS VALID_TRANSACTION_FROM,
            NULL                    AS VALID_TRANSACTION_TO,
            true                    AS IS_CURRENT
        FROM {ACTIVE} a
        WHERE a.AUTO_POLICY_ID IN (SELECT AUTO_POLICY_ID FROM _group_a_refresh)
    """)
    print(f"  Step 3: Snapshotted {changed_count} polic(y/ies) to AUTO_FEATURES_HISTORY (IS_CURRENT=true).")
    print(f"\nDone. {changed_count} polic(y/ies) refreshed.")


refresh_group_a()

# COMMAND ----------
# MAGIC %md
# MAGIC ## Verify

# COMMAND ----------

print("=== AUTO_FEATURES_ACTIVE (GROUP_A columns) ===")
display(spark.table(ACTIVE).select("AUTO_POLICY_ID", *GROUP_A_COLUMNS, "GROUP_A_UPDATED_AT").orderBy("AUTO_POLICY_ID"))

print("=== AUTO_FEATURES_HISTORY (group_a_daily_refresh rows) ===")
display(spark.sql(f"""
    SELECT * FROM {HISTORY}
    WHERE REASON = 'group_a_daily_refresh'
    ORDER BY AUTO_POLICY_ID, SNAPSHOT_AT DESC
"""))
