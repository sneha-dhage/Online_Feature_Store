# Databricks notebook source
# MAGIC %md
# MAGIC # 09 — Endpoint Warm Toggle
# MAGIC
# MAGIC Companion to `08_online_feature_store.py` — toggles `scale_to_zero_enabled` on the
# MAGIC feature serving endpoint it creates.
# MAGIC
# MAGIC - **Before a demo** → run with `scale_to_zero = false` (keeps the endpoint warm, no cold-start
# MAGIC   delay on the first query)
# MAGIC - **After a demo**  → run with `scale_to_zero = true` (scales to zero when idle, saves cost)
# MAGIC
# MAGIC `08` creates the endpoint with `scale_to_zero_enabled=True` by default — run this notebook
# MAGIC with `scale_to_zero=false` beforehand if you want it warm for a demo.
# MAGIC
# MAGIC **Unchanged in this redesign.**

# COMMAND ----------

import requests, time

dbutils.widgets.text("endpoint_name",  "auto-policy-feature-serving")
dbutils.widgets.text("feature_spec",   "main.final_database.AUTO_POLICY_FEATURE_SPEC")
dbutils.widgets.dropdown("scale_to_zero", "false", ["false", "true"])

ENDPOINT_NAME  = dbutils.widgets.get("endpoint_name")
FEATURE_SPEC   = dbutils.widgets.get("feature_spec")
SCALE_TO_ZERO  = dbutils.widgets.get("scale_to_zero") == "true"

HOST    = spark.conf.get("spark.databricks.workspaceUrl")
TOKEN   = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
HEADERS = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}

print(f"Endpoint      : {ENDPOINT_NAME}")
print(f"Feature spec  : {FEATURE_SPEC}")
print(f"scale_to_zero : {SCALE_TO_ZERO}")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Update endpoint config

# COMMAND ----------

body = {
    "served_entities": [
        {
            "name": "auto-policy-features",
            "entity_name": FEATURE_SPEC,
            "workload_size": "Small",
            "scale_to_zero_enabled": SCALE_TO_ZERO,
        }
    ]
}

resp = requests.put(
    f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}/config",
    headers=HEADERS,
    json=body,
)

if resp.status_code not in (200, 202):
    raise RuntimeError(f"Update failed {resp.status_code}: {resp.text[:400]}")

print(f"Config update submitted. Waiting for endpoint to be READY...")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Wait for READY

# COMMAND ----------

for i in range(30):
    poll = requests.get(
        f"https://{HOST}/api/2.0/serving-endpoints/{ENDPOINT_NAME}",
        headers=HEADERS
    )
    state  = poll.json().get("state", {})
    ready  = state.get("ready", "unknown")
    update = state.get("config_update", "")
    print(f"  [{i*10}s] ready={ready}  config_update={update}")

    if ready == "READY" and update in ("NOT_UPDATING", ""):
        action = "OFF (always warm)" if not SCALE_TO_ZERO else "ON (scales to zero when idle)"
        print(f"\nDone. scale_to_zero = {action}")
        break

    if update == "UPDATE_FAILED":
        print("\nUpdate FAILED. Check Databricks UI > Serving > Logs.")
        break

    time.sleep(10)
