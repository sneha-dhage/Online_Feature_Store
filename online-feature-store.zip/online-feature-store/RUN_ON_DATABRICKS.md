# Running This on Databricks with `sample_transactions.csv`

**Tested and confirmed working** on Databricks Free Edition (serverless compute,
Unity Catalog). Step-by-step for taking this from a brand-new workspace to a fully
verified run of the optimized pipeline, using the `sample_transactions.csv` in this
folder as test data — 82 transactions across 20 policies, every policy with 2–6
transactions, which is exactly the scenario worth testing (see `README.md`): a bulk
load lands many transactions per policy in the same micro-batch, exercising the
trickiest part of both `04` and `05`'s redesign.

## 0. Prerequisites

- A Unity Catalog-enabled workspace. On **Databricks Free Edition**, Unity Catalog
  is on by default and your catalog is very likely named **`workspace`** — check
  under **Catalog → My organization** to confirm.
- Compute: Free Edition uses **serverless** compute automatically — you generally
  don't need to create or configure a cluster. When you open a notebook and run a
  cell, it attaches to serverless compute on its own. A "Serverless Starter
  Warehouse" (visible under Compute) is a SQL warehouse for the SQL Editor — that's
  a *different* thing from the notebook compute `04`/`05` need for `foreachBatch`
  streaming; you don't need to touch it.
- Workspace permission to import notebooks and upload files to a Volume (default
  on your own Free Edition account).

## 1. Create a test schema

Don't reuse a schema you care about — `01` can drop and recreate tables in it.

In the **SQL Editor**, or via **Catalog → workspace → Create → Schema**:
```sql
CREATE SCHEMA workspace.featurestore_test;
```

## 2. Import the notebooks

Every `.py` file in this folder (except the `.md` files and the CSV) starts with
`# Databricks notebook source` — Databricks recognizes that as a notebook
automatically on import.

1. **Workspace** → your user folder → **Create → Folder** (e.g. `online-feature-store`).
2. Right-click that folder → **Import** → **File** → pick a `.py` file → **Import**.
3. Repeat for: `01_setup_tables.py`, `04_sp_compute_features.py`,
   `05_routing_pipeline.py`, `bulk_backfill_from_csv.py`.
   (`02_seed_data.py`, `03_autoloader_landing_zone.py`, `06`–`09`, and
   `bootstrap_snapshot_state.py` aren't needed for this CSV-based test run — see
   the run-order notes below for why.)

## 3. Run `01_setup_tables`

Open it, set the widgets at the top of the first code cell (either in the widget
boxes, or by editing the `dbutils.widgets.text(...)` default values directly and
re-running that cell):

- `catalog` = `workspace`
- `schema` = `featurestore_test`
- `reset` = `true`

**Run all.** Expect `RESULT: ✅ ALL CHECKS PASSED` or a single harmless warning on
**CHECK 1** (`Could not determine DBR version`) — on serverless/Spark Connect
compute, that specific internal config key is blocked from being read at all, so
the check throws instead of returning empty. This doesn't matter: **CHECK 8**
(Liquid Clustering) independently proves the thing that actually matters by
creating and dropping a real test table with `CLUSTER BY` — if that check passes,
you're fine. All 8 other checks should show ✅.

At the bottom, confirm **"Verify All Tables"** shows all 8 tables at `0 rows`
except `FEATURE_GROUP_REGISTRY` at `2 rows` (`GROUP_A`, `GROUP_B`).

## 4. Upload the CSV to the Volume

`01` just created `/Volumes/workspace/featurestore_test/incoming_json`.

**Catalog → workspace → featurestore_test → Volumes tab → `incoming_json` →
Upload to this volume** → select `sample_transactions.csv`.

Confirm the resulting path is:
```
/Volumes/workspace/featurestore_test/incoming_json/sample_transactions.csv
```

## 5. Run `bulk_backfill_from_csv`

This lands the CSV straight into `RAW_POLICY_EVENTS`, bypassing `03`
(Auto Loader) entirely — the standard shortcut for a bulk load, same as the
original design's `bulk_backfill_from_csv.py`.

Widgets:
- `catalog` = `workspace`
- `schema` = `featurestore_test`
- `csv_path` = `/Volumes/workspace/featurestore_test/incoming_json/sample_transactions.csv`

**Run all.** Expect:
```
Rows in CSV: 82
Parsed OK : 82
Failed    : 0
Inserted 82 new row(s) into workspace.featurestore_test.RAW_POLICY_EVENTS
```
and an empty "Recent DLQ entries" table.

## 6. Run `04_sp_compute_features`

⚠️ **Gotcha**: `checkpoint_path` defaults to a hardcoded
`/Volumes/main/final_database/...` string — it is **not** derived from your
`catalog`/`schema` widgets. You must override it to match your actual schema, or
Spark will try to read/write checkpoints in a Volume that doesn't exist.

Widgets:
- `catalog` = `workspace`
- `schema` = `featurestore_test`
- `checkpoint_path` = `/Volumes/workspace/featurestore_test/checkpoints/sp_compute`

**Run all.** This is the first real test of the redesign — 20 policies, most with
multiple transactions landing in the same micro-batch. Confirm with:
```sql
SELECT COUNT(*) FROM workspace.featurestore_test.COMPUTED_FEATURE_EVENTS;  -- expect 82
SELECT COUNT(*) FROM workspace.featurestore_test.AUTO_POLICY_SNAPSHOT_STATE; -- expect 20
```

## 7. Run `05_routing_pipeline`

Same checkpoint-path gotcha applies. Widgets:
- `catalog` = `workspace`
- `schema` = `featurestore_test`
- `checkpoint_path` = `/Volumes/workspace/featurestore_test/checkpoints/routing`
- `sim_date` = leave blank

**Run all.**

> **Note on a fix already applied**: this notebook's CDF read now uses
> `startingVersion="0"` (not `"latest"`). With `"latest"`, if `05` is started for
> the first time *after* `04` has already finished writing (exactly what happens
> in this backfill-then-compute-then-route sequence), it silently misses
> everything that already landed and produces empty `ACTIVE`/`HISTORY` tables with
> no error. `"0"` makes it catch up on any backlog on its first-ever run, matching
> what `04` already does for its own source table — this only affects the very
> first run before a checkpoint exists; every run after that uses the checkpoint's
> offset regardless.

## 8. Verify

```sql
SELECT 'RAW_POLICY_EVENTS' AS tbl, COUNT(*) AS n FROM workspace.featurestore_test.RAW_POLICY_EVENTS
UNION ALL SELECT 'COMPUTED_FEATURE_EVENTS', COUNT(*) FROM workspace.featurestore_test.COMPUTED_FEATURE_EVENTS
UNION ALL SELECT 'AUTO_FEATURES_ACTIVE', COUNT(*) FROM workspace.featurestore_test.AUTO_FEATURES_ACTIVE
UNION ALL SELECT 'AUTO_FEATURES_HISTORY', COUNT(*) FROM workspace.featurestore_test.AUTO_FEATURES_HISTORY
UNION ALL SELECT 'AUTO_POLICY_SNAPSHOT_STATE', COUNT(*) FROM workspace.featurestore_test.AUTO_POLICY_SNAPSHOT_STATE;
-- expect: 82, 82, 20, 82, 20
```

**The critical correctness check — exactly one `IS_CURRENT` row per policy:**
```sql
SELECT AUTO_POLICY_ID, COUNT(*) AS is_current_count
FROM workspace.featurestore_test.AUTO_FEATURES_HISTORY
WHERE IS_CURRENT = true
GROUP BY AUTO_POLICY_ID
HAVING COUNT(*) <> 1;
-- MUST return zero rows
```

**No overlapping validity windows:**
```sql
WITH ordered AS (
  SELECT AUTO_POLICY_ID, VALID_TRANSACTION_FROM, VALID_TRANSACTION_TO,
         LEAD(VALID_TRANSACTION_FROM) OVER (
           PARTITION BY AUTO_POLICY_ID ORDER BY VALID_TRANSACTION_FROM
         ) AS next_from
  FROM workspace.featurestore_test.AUTO_FEATURES_HISTORY
)
SELECT * FROM ordered
WHERE VALID_TRANSACTION_TO IS NOT NULL AND VALID_TRANSACTION_TO >= next_from;
-- MUST return zero rows
```

**Spot-check policy `600000016`** (5 transactions in the CSV — a good one to eyeball):
```sql
SELECT * FROM workspace.featurestore_test.AUTO_FEATURES_ACTIVE WHERE AUTO_POLICY_ID = '600000016';

SELECT TRANS_ID, VEH_CNT, VEH_ADDED_LATEST_TXN, DRVR_CNT, VALID_TRANSACTION_FROM,
       VALID_TRANSACTION_TO, IS_CURRENT
FROM workspace.featurestore_test.AUTO_FEATURES_HISTORY
WHERE AUTO_POLICY_ID = '600000016'
ORDER BY VALID_TRANSACTION_FROM;
-- expect exactly 5 rows, exactly one with IS_CURRENT=true (the last one)
```

## 9. Re-running from scratch

Re-running `01` with `reset=true` drops and recreates tables, but not checkpoint
contents. If you re-run `04`/`05` without clearing checkpoints, they'll think
they've already processed everything and do nothing. Either pick a fresh
`checkpoint_path` each time, or clear the old one:
```python
dbutils.fs.rm("/Volumes/workspace/featurestore_test/checkpoints/sp_compute", recurse=True)
dbutils.fs.rm("/Volumes/workspace/featurestore_test/checkpoints/routing", recurse=True)
```

## 10. Not needed for this test

- `02_seed_data` / `03_autoloader_landing_zone` — the CSV path via
  `bulk_backfill_from_csv` bypasses both.
- `bootstrap_snapshot_state` — only needed when adding this optimization to a
  schema that *already* has processed transaction history; this is a fresh
  schema, so every policy's state is built up naturally by `04`.
- `06`/`07` (daily jobs) — nothing in the sample CSV is future-dated, so there's
  nothing for them to do yet.
- `08`/`09` (online serving) — provision real cloud resources (Lakebase online
  store, a serving endpoint) with real cost; not required to validate the `04`/`05`
  optimization, and may not be available on Free Edition at all.
