# newly-designed-online-featurestore

Optimized version of the pipeline in `online-feature-databrics/` — fixes the two
compute/routing bottlenecks (`04`'s full-history recompute, `05`'s per-event driver
loop) while keeping ingestion as Auto Loader (no Kafka in this version) and keeping
`AUTO_FEATURES_HISTORY` at one row per individual transaction. See
[ARCHITECTURE.md](ARCHITECTURE.md) for the full design and diagrams.

## What's different from `online-feature-databrics/`

| File | Status |
|---|---|
| `01_setup_tables.py` | Extended — adds `AUTO_POLICY_SNAPSHOT_STATE` |
| `02_seed_data.py` | Extended — seeds the new table too |
| `03_autoloader_landing_zone.py` | Unchanged |
| `04_sp_compute_features.py` | **Redesigned** — state lookup instead of full-history re-read |
| `05_routing_pipeline.py` | **Redesigned** — batch-wide window functions instead of a per-event loop |
| `06`–`09` | Unchanged |
| `bootstrap_snapshot_state.py` | **New** — one-time migration job |
| `bulk_backfill_from_csv.py`, `publish_test_json.py` | Unchanged utilities |

## Run order

**Fresh deployment (no existing history):**
```
01_setup_tables → 02_seed_data → 03_autoloader_landing_zone
→ 04_sp_compute_features → 05_routing_pipeline → 06/07 (scheduled) → 08 → 09
```

**Migrating a schema that already has transaction history:**
```
01_setup_tables (adds the new table to the existing schema)
→ bootstrap_snapshot_state   ← run this ONCE, seeds AUTO_POLICY_SNAPSHOT_STATE
                                from full RAW_POLICY_EVENTS history
→ 04_sp_compute_features (now runs incrementally from here on)
→ 05_routing_pipeline
```

Skip `bootstrap_snapshot_state.py` entirely for a fresh deployment or a bulk CSV
backfill of brand-new policies — a policy with no prior state just gets one created
naturally on its first processed transaction.

## Important — this has not been run against a real Databricks workspace

Everything here was written and carefully hand-verified against the original
design (traced through the exact column flow, the union/window-function mechanics,
and edge cases like multiple transactions for the same policy landing in one
micro-batch) — but I don't have a Databricks workspace or a local Spark/Delta
environment to actually execute it, unlike the `Kafka-approach/` demo which was
fully run end-to-end. **Test this in a dev/test schema before trusting it against
production data**, especially:

- A batch where **one policy has two or more new transactions at once** (the
  trickiest correctness case in both `04` and `05` — verify the resulting
  `AUTO_FEATURES_HISTORY` rows chain correctly with no overlapping validity
  windows, the same check `Kafka-approach/verify_results.py` runs).
- A **brand-new policy's first transaction(s)** (no prior state, no prior `ACTIVE`
  row — verify untouched-group columns come back `NULL`, matching the original
  design's own first-insert behavior).
- Compare a handful of computed feature values directly against
  `online-feature-databrics/04_sp_compute_features.py`'s output for the same input
  data, to confirm the two designs agree.
